# -*- encoding=utf8 -*-


from airtest.core.api import *
import os,unittest,HTMLTestRunner,inspect
path = os.path.abspath('..\..')
using(path+'\common\web_picture.air')
from web_picture import *


class StatusError(Exception):
    pass

def hotgeng(name=None,picture=None):
    if name =="qipai" :
        touch(Template(r"tpl1550630954097.png", record_pos=(-0.348, -0.024), resolution=(1920, 1080)))
        sleep(1)
        for i in range(15):
            if exists(Template(r"tpl1550630978781.png", rgb=True, record_pos=(-0.094, -0.092), resolution=(1920, 1080))):
                touch(Template(r"tpl1550630978781.png", rgb=True, record_pos=(-0.094, -0.092), resolution=(1920, 1080)))
            else:
                
                swipe([1800,500],[800,500])   #划屏操作
    elif name =="jieji":
        touch(Template(r"tpl1550631033213.png", record_pos=(-0.348, 0.054), resolution=(1920, 1080)))
        sleep(1)
        for i in range(5):
            if exists(Template(r"tpl1550630978781.png", rgb=True, record_pos=(-0.094, -0.092), resolution=(1920, 1080))):
                touch(Template(r"tpl1550630978781.png", rgb=True, record_pos=(-0.094, -0.092), resolution=(1920, 1080)))
            else:
                
                swipe([1800,500],[800,500])   #划屏操作
    else:
        touch(Template(r"tpl1550631047595.png", record_pos=(-0.347, 0.131), resolution=(1920, 1080)))
        sleep(1)
        for i in range(5):
            if exists(Template(r"tpl1550630978781.png", rgb=True, record_pos=(-0.094, -0.092), resolution=(1920, 1080))):
                touch(Template(r"tpl1550630978781.png", rgb=True, record_pos=(-0.094, -0.092), resolution=(1920, 1080)))
            else:
                
                swipe([1800,500],[800,500])   #划屏操作
"""进游戏"""
def in_youxi(picture_1,picture_2):
    if exists(picture_1):
        touch(picture_1)
    sleep(1)
    for i in range(3):
            swipe([800,500],[1800,500])   #划屏操作
            sleep(1)
    for i in range(3):
        if exists(picture_2):
            touch(picture_2)
            if exists(Template(r"tpl1552009821620.png", rgb=True, record_pos=(-0.004, -0.004), resolution=(1920, 1080))):
                return 4
            elif exists(Template(r"tpl1551773933728.png", rgb=True, record_pos=(-0.001, -0.002), resolution=(1920, 1080))):
                return 2
            elif exists(Template(r"tpl1551774031989.png", rgb=True, record_pos=(0.003, -0.001), resolution=(1920, 1080))):
                return 3
            else:
                return True                    
        else:
            swipe([1800,500],[800,500])   #划屏操作
            sleep(1)
    return 1
def dianji(picture,timeout=None):  
    start_time = time.time()
    timeout = timeout or 120
    while True:
        if exists(picture):
            touch(picture)
            break       
        else:
            pass
        if (time.time() - start_time) > timeout:
            raise TargetNotFoundError
            return False
        else:
            time.sleep(1)
# 以出现历史记录弹框做为可以下注的判断          
def tktanchu(picture):  
    start_time = time.time()
    while True:
        if exists(picture):
            sleep(6)
            break
        else:
            if chaoshi(start_time) is False:
                raise TargetNotFoundError
#判断目标出现并返回布尔值
def pc_pd(picture,miaoshu):
    sleep(1)
    if exists(picture):
        assert_exists(picture,miaoshu)
        return True
    else:
        return False


#設置跨文件變量
class globalVar:
    web = "huihuang100"
    account = "test1113"
    password = "qwaszx12"
    def set_web(value):
        globalVar.web = value
    def get_web():
        return globalVar.web
    def set_account(value):
        globalVar.account = value
    def get_account():
        return globalVar.account
    def set_password(value):
        globalVar.password = value
    def get_password():
        return globalVar.password

def gb_tc(webside):
    for x in range(3):#防止弹窗位置重叠有误
        activity = exists(windows_p(webside,'activity'))
        if activity:
            touch(activity)
        checkIn = exists(windows_p(webside,'checkIn'))
        if checkIn:
            touch(checkIn)   
        signIn = exists(windows_p(webside,'signIn'))
        if signIn:
            touch(signIn)
        lobbyOrGame = exists(lobby_p(webside))#判断是否在大厅
        if lobbyOrGame:
            return True
    return False

def login(webside):
    wake() 
    for i in range(10):
        try:
            stop_app(app_package(webside))
            sleep(1)
            start_app(app_package(webside))
            wait(login_button_p(webside,'account'),30)
            touch(login_button_p(webside,'account'))
            wait(login_fill_p(webside,'login'))
            touch(login_fill_p(webside,'account'))
            text(globalVar.get_account())
            sleep(0.5)
            touch(login_fill_p(webside,'password'))
            text(globalVar.get_password())
            touch(login_fill_p(webside,'submit'))
            wait(lobby_p(webside),30)
            sleep(2)
            return gb_tc(webside)
        except Exception:
            pass    

def connectDevices():
    shebei = os.popen('adb devices').readlines()
    for i in range(len(shebei)):
        if shebei[i].find('\tdevice') != -1:
            temp = shebei[i].split('\t')
            DEV = temp[0]
    connect_device("Android://127.0.0.1:5037/" + DEV)
    

using(path+'\games\game001.air')
import game001
using(path+'\games\game002.air')
import game002
using(path+'\games\game003.air')
import game003
#游戏运行的函数
def test_youxi(game = None):
    suite = unittest.TestSuite()
    game_list = []
    if inspect.isclass(game):  
        methods = dir(game)
        for method in methods:
            if method.startswith("test_"):
                suite.addTest(game(method))            
    elif inspect.ismodule(game):
        for k in inspect.getmembers(game):
            if inspect.isclass(k[1]):
                if k[0].startswith("Game_"):
                    game_list.append(k[1])                   
        for i in game_list:
            methods = dir(i)
            for method in methods:
                if method.startswith("test_"):
                    suite.addTest(i(method))
    else:
        for k in inspect.getmembers(game001):
            if inspect.isclass(k[1]):
                if k[0].startswith("Game_"):
                    game_list.append(k[1])
        for k in inspect.getmembers(game002):
            if inspect.isclass(k[1]):
                if k[0].startswith("Game_"):
                    game_list.append(k[1])
        for k in inspect.getmembers(game003):
            if inspect.isclass(k[1]):
                if k[0].startswith("Game_"):
                    game_list.append(k[1])
        print(game_list)
        for i in game_list:
            methods = dir(i)
            for method in methods:
                if method.startswith("test_"):
                        suite.addTest(i(method))
    now = time.strftime("%Y-%m-%d %H-%M-%S")
    filename = path + "\games\%r.html"%now
    fp = open(filename, "wb+")
    runner = HTMLTestRunner.HTMLTestRunner(stream=fp, title="用例集合", description="用例执行情况:")
    runner.run(suite)
    fp.close()


# """连接设备"""        
# connectDevices()
# if not exists(lobby_p(globalVar.get_web())):
#     login(globalVar.get_web())

# list = device().list_app(third_only=True)
# result = []
# for i in list:
#     if i.startswith("org.cocos2d"):
#         result.append(i)
# print(result)    
   