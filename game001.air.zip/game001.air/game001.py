# -*- encoding=utf8 -*-
__author__ = "Admin"

import unittest,HTMLTestRunner,time
from airtest.core.api import *

path = os.path.abspath('..\..')
using(path+'\common\settings.air')
from settings import *

using(path+'\common\games_picture.air')
from games_picture import *

using(path+'\games\config.air')
from config import *



"""
游戏局数
number[2] 代表抢庄牌九游戏局数
number[1] 代表二八杠游戏局数
number[0] 代表其他游戏局数
"""
number = [1,1,1]


class Game_errenniuniu(unittest.TestCase):
    """二人牛牛"""  
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.num = number[0]   # 玩游戏的局数      
        cls.web = globalVar.get_web()
        cls.name = {"体验房":Template(r"tpl1550022195152.png", rgb=True, record_pos=(-0.027, -0.02), resolution=(1920, 1080)),"初级房":Template(r"tpl1550022254172.png", rgb=True, record_pos=(0.154, -0.02), resolution=(1920, 1080)),"中级房":Template(r"tpl1550022282161.png", rgb=True, record_pos=(0.353, -0.018), resolution=(1920, 1080)),"高级房":Template(r"tpl1550022314770.png", rgb=True, record_pos=(-0.044, 0.206), resolution=(1920, 1080)),"富豪房":Template(r"tpl1550022349353.png", rgb=True, record_pos=(0.161, 0.205), resolution=(1920, 1080))}

        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError  
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
    @classmethod
    def ingame(cls): #进入游戏
        list1 = leimu_P(cls.web)[0]
        list2 = dating(cls.web,"Game_errenniuniu")
        result = in_youxi(list1,list2)
        if result is True:
            return pc_wait(Template(r"tpl1550651132002.png", rgb=True, record_pos=(0.169, -0.247), resolution=(1920, 1080)),"***成功进入二人牛牛***",30)
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:            
            raise TargetNotFoundError("进入游戏失败")
    def inroom(self,name): #进入游戏房间 
        pc_wait(Template(r"tpl1550651132002.png", rgb=True, record_pos=(0.169, -0.247), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        touch(self.name[name])
        result = pc_pd(Template(r"tpl1550638755228.png", record_pos=(0.122, 0.078), resolution=(1920, 1080)), "金额不足进%s有充值提示"%name)
        if result is True:
            touch(Template(r"tpl1550638755228.png", record_pos=(0.122, 0.078), resolution=(1920, 1080)))
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])        
            return 1
        else:
            return pc_wait(Template(r"tpl1548497787283.png", rgb=True, record_pos=(0.005, 0.033), resolution=(1920, 1080)),"成功进入二人牛牛%s"%name,30)  
    def kaiwan(self): #玩游戏
        touch(Template(r"tpl1549518083877.png", rgb=True, record_pos=(-0.001, 0.031), resolution=(1920, 1080)))
        for i in range(self.num):
            pc_wait(Template(r"tpl1549518104269.png", rgb=True, record_pos=(-0.072, 0.033), resolution=(1920, 1080)),"成功匹配到玩家",60)
            dianji(Template(r"tpl1549518104269.png", rgb=True, record_pos=(-0.072, 0.033), resolution=(1920, 1080)))
            dianji(Template(r"tpl1549518395152.png", rgb=True, record_pos=(0.002, 0.031), resolution=(1920, 1080)))
            pc_wait(Template(r"tpl1549518083877.png", rgb=True, record_pos=(-0.001, 0.031), resolution=(1920, 1080)),"第%s局游戏结束"%(i+1))
            if i != self.num-1:
                dianji(Template(r"tpl1549518083877.png", rgb=True, record_pos=(-0.001, 0.031), resolution=(1920, 1080)))
        start_time = time.time()              
        while True:                
            if exists(Template(r"tpl1549263692604.png", rgb=True, record_pos=(0.001, 0.03), resolution=(1920, 1080))):
                touch(Template(r"tpl1549692026255.png", rgb=True, record_pos=(-0.401, -0.211), resolution=(2160, 1080))) #返回选房大厅 
                break               
            else:
                if chaoshi(start_time) is False:
                    break 
        pc_wait(Template(r"tpl1548825005321.png", rgb=True, record_pos=(0.332, -0.246), resolution=(1920, 1080)),"成功回到选场大厅")
    def more(self):   #语音
        sleep(1)
        touch(Template(r"tpl1549171123097.png", rgb=True, record_pos=(0.449, -0.241), resolution=(1920, 1080)))
        sleep(1)
        if exists(Template(r"tpl1550205953707.png", threshold=0.9, rgb=True, record_pos=(-0.258, -0.023), resolution=(1920, 1080))):
            touch(Template(r"tpl1550205364445.png", rgb=True, target_pos=9, record_pos=(-0.306, -0.109), resolution=(1920, 1080)))
            touch(Template(r"tpl1550205398007.png", rgb=True, target_pos=9, record_pos=(-0.31, -0.027), resolution=(1920, 1080)))
            
            bug_assert(Template(r"tpl1549443120748.png", rgb=True, record_pos=(-0.198, -0.02), resolution=(2280, 1080)),"成功取消音效","无法取消音效")                
        else:
            touch(Template(r"tpl1550205427271.png", rgb=True, target_pos=9, record_pos=(-0.305, -0.11), resolution=(1920, 1080)))
            touch(Template(r"tpl1550205447849.png", rgb=True, target_pos=9, record_pos=(-0.307, -0.029), resolution=(1920, 1080)))
            sleep(1)
            bug_assert(Template(r"tpl1550205953707.png", threshold=0.9, rgb=True, record_pos=(-0.258, -0.023), resolution=(1920, 1080)),"成功开启音效","无法开启音效")
        touch(coordinate([60,600]))
    @classmethod
    def record(cls):  #游戏记录
        touch(Template(r"tpl1549171458713.png", rgb=True, record_pos=(0.242, -0.245), resolution=(1920, 1080)))
        sleep(2)
        if exists(Template(r"tpl1549437671238.png", rgb=True, record_pos=(-0.001, 0.007), resolution=(1920, 1080))):
            print("暂无游戏记录")
        else:
            bug_assert(Template(r"tpl1549110041377.png", rgb=True, record_pos=(-0.004, -0.153), resolution=(1920, 1080)),"成功打开游戏记录","无法游戏记录")
            touch(Template(r"tpl1549936842444.png", rgb=True, record_pos=(0.331, -0.109), resolution=(1920, 1080)))#点击详情
            sleep(2)
            bug_assert(Template(r"tpl1549110451899.png", rgb=True, record_pos=(-0.005, -0.211), resolution=(1920, 1080)),"成功打开游戏记录详情页","无法打开游戏记录详情页")
            touch([60,600])
            sleep(2)            
        touch([60,600])
    @classmethod
    def exit(cls):  #退出
        start_time = time.time()
        while True:                
            if exists(Template(r"tpl1549263692604.png", rgb=True, record_pos=(0.001, 0.03), resolution=(1920, 1080))):
                touch(Template(r"tpl1549692026255.png", rgb=True, record_pos=(-0.401, -0.211), resolution=(2160, 1080))) #返回选房大厅 
                break
            elif exists(Template(r"tpl1548825005321.png", rgb=True, record_pos=(0.332, -0.246), resolution=(1920, 1080))):
                break                
            else:
                if chaoshi(start_time) is False:
                    break
        pc_wait(Template(r"tpl1548825005321.png", rgb=True, record_pos=(0.332, -0.246), resolution=(1920, 1080)),"成功回到选场大厅",30)
        touch(Template(r"tpl1549692101253.png", rgb=True, record_pos=(-0.444, -0.219), resolution=(2160, 1080))) # 回到游戏大厅
        pc_wait(leimu_P(cls.web)[0],"成功回到游戏大厅",30)
        sleep(5)
    def test_tiyan(self):
        if not exists(Template(r"tpl1550651132002.png", rgb=True, record_pos=(0.169, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("体验房")
        if result:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("体验房"))
    def test_chuji(self):
        if not exists(Template(r"tpl1550651132002.png", rgb=True, record_pos=(0.169, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.kaiwan()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))
    def test_zhongji(self):
        if not exists(Template(r"tpl1550651132002.png", rgb=True, record_pos=(0.169, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))
    def test_gaoji(self):
        if not exists(Template(r"tpl1550651132002.png", rgb=True, record_pos=(0.169, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))
    def test_fuhao(self):
        if not exists(Template(r"tpl1550651132002.png", rgb=True, record_pos=(0.169, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("富豪房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("富豪房"))
            
class Game_qiangzhuangniuniu(unittest.TestCase):
    """抢庄牛牛"""   
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.num = number[0]  # 玩游戏的局数
        cls.web = globalVar.get_web()
        cls.name = {"体验房":Template(r"tpl1550022195152.png", rgb=True, record_pos=(-0.027, -0.02), resolution=(1920, 1080)),"初级房":Template(r"tpl1550022254172.png", rgb=True, record_pos=(0.154, -0.02), resolution=(1920, 1080)),"中级房":Template(r"tpl1550022282161.png", rgb=True, record_pos=(0.353, -0.018), resolution=(1920, 1080)),"高级房":Template(r"tpl1550022314770.png", rgb=True, record_pos=(-0.044, 0.206), resolution=(1920, 1080)),"富豪房":Template(r"tpl1550022349353.png", rgb=True, record_pos=(0.161, 0.205), resolution=(1920, 1080))}

        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()        
    @classmethod
    def ingame(cls): #进入游戏
        list1 = leimu_P(cls.web)[0]
        list2 = dating(cls.web,"Game_qiangzhuangniuniu")
        result = in_youxi(list1,list2)
        if result is True:
            return pc_wait(Template(r"tpl1549003593218.png", rgb=True, record_pos=(0.357, -0.244), resolution=(1920, 1080)),"***成功进入抢庄牛牛***")
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:            
            raise TargetNotFoundError("进入游戏失败")
    def inroom(self,name): #进入游戏房间
        pc_wait(Template(r"tpl1549003593218.png", rgb=True, record_pos=(0.357, -0.244), resolution=(1920, 1080)),"马上进房间玩游戏了",30)
        touch(self.name[name])
        result = pc_pd(Template(r"tpl1550638755228.png", record_pos=(0.122, 0.078), resolution=(1920, 1080)), "金额不足进%s有充值提示"%name)
        if result is True:
            touch(Template(r"tpl1550638755228.png", record_pos=(0.122, 0.078), resolution=(1920, 1080)))
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])
            return 1
        else:
            return pc_wait(Template(r"tpl1548499991756.png", rgb=True, record_pos=(0.016, 0.14), resolution=(1920, 1080)),"成功进入抢庄牛牛%s"%name,30)
    def kaiwan(self): #玩游戏
        if exists(Template(r"tpl1549516525424.png", rgb=True, record_pos=(0.016, 0.14), resolution=(1920, 1080))):
            touch(Template(r"tpl1549516525424.png", rgb=True, record_pos=(0.016, 0.14), resolution=(1920, 1080)))
        for i in range(self.num):
            pc_wait(Template(r"tpl1549516554569.png", rgb=True, record_pos=(-0.09, 0.052), resolution=(1920, 1080)),"成功匹配到玩家",60)
            touch(Template(r"tpl1549516554569.png", rgb=True, record_pos=(-0.09, 0.052), resolution=(1920, 1080)))
            pc_wait(Template(r"tpl1549516688513.png", rgb=True, record_pos=(0.145, 0.203), resolution=(1920, 1080)),"第%s局游戏结束"%(i+1))
            if i !=self.num-1:
                dianji(Template(r"tpl1549516688513.png", rgb=True, record_pos=(0.145, 0.203), resolution=(1920, 1080)))
        start_time = time.time()
        while True:    
            if exists(Template(r"tpl1549517760110.png", rgb=True, record_pos=(-0.006, 0.14), resolution=(1920, 1080))):
                touch(Template(r"tpl1549517384694.png", rgb=True, record_pos=(-0.449, -0.221), resolution=(1920, 1080))) #返回选房大厅 
                break
            elif exists(Template(r"tpl1549516837294.png", threshold=0.8, rgb=True, record_pos=(0.143, 0.205), resolution=(1920, 1080))):
                touch(Template(r"tpl1549516859616.png", threshold=0.8, rgb=True, record_pos=(-0.139, 0.204), resolution=(1920, 1080)))  #返回选房大厅
                break
            elif exists(Template(r"tpl1548825140388.png", rgb=True, record_pos=(0.36, -0.241), resolution=(1920, 1080))):
                break
            else:
                if chaoshi(start_time) is False:
                    break
        pc_wait(Template(r"tpl1548825140388.png", rgb=True, record_pos=(0.36, -0.241), resolution=(1920, 1080)),"成功回到选场大厅")
    def more(self):  #语音
        sleep(1)
        touch(Template(r"tpl1550206467486.png", threshold=0.8, rgb=True, record_pos=(0.449, -0.22), resolution=(1920, 1080)))
        sleep(1)
        if exists(Template(r"tpl1550205953707.png", threshold=0.9, rgb=True, record_pos=(-0.258, -0.023), resolution=(1920, 1080))):
            touch(Template(r"tpl1550205364445.png", rgb=True, target_pos=9, record_pos=(-0.306, -0.109), resolution=(1920, 1080)))
            touch(Template(r"tpl1550205398007.png", rgb=True, target_pos=9, record_pos=(-0.31, -0.027), resolution=(1920, 1080)))
            
            bug_assert(Template(r"tpl1549443120748.png", rgb=True, record_pos=(-0.198, -0.02), resolution=(2280, 1080)),"成功取消音效","无法取消音效")                
        else:
            touch(Template(r"tpl1550205427271.png", rgb=True, target_pos=9, record_pos=(-0.305, -0.11), resolution=(1920, 1080)))
            touch(Template(r"tpl1550205447849.png", rgb=True, target_pos=9, record_pos=(-0.307, -0.029), resolution=(1920, 1080)))
            sleep(1)
            bug_assert(Template(r"tpl1550205953707.png", threshold=0.9, rgb=True, record_pos=(-0.258, -0.023), resolution=(1920, 1080)),"成功开启音效","无法开启音效")
        touch(Template(r"tpl1550483129172.png", rgb=True, target_pos=6, record_pos=(0.165, -0.215), resolution=(1920, 1080)))
    @classmethod
    def exit(cls):  #退出
        start_time = time.time()
        while True:
            if exists(Template(r"tpl1549517760110.png", rgb=True, record_pos=(-0.006, 0.14), resolution=(1920, 1080))):
                touch(Template(r"tpl1549517384694.png", rgb=True, record_pos=(-0.449, -0.221), resolution=(1920, 1080))) #返回选房大厅 
                break
            elif exists(Template(r"tpl1549516837294.png", rgb=True, record_pos=(0.143, 0.205), resolution=(1920, 1080))):
                touch(Template(r"tpl1549516859616.png", rgb=True, record_pos=(-0.139, 0.204), resolution=(1920, 1080)))  #返回选房大厅          
                break
            elif exists(Template(r"tpl1548825140388.png", rgb=True, record_pos=(0.36, -0.241), resolution=(1920, 1080))):
                break
            else:
                if chaoshi(start_time) is False:
                    break               
        pc_wait(Template(r"tpl1548825140388.png", rgb=True, record_pos=(0.36, -0.241), resolution=(1920, 1080)),"成功回到选场大厅")
        touch(Template(r"tpl1549692599184.png", rgb=True, record_pos=(-0.441, -0.219), resolution=(2160, 1080)))   # 回到游戏大厅
        pc_wait(leimu_P(cls.web)[0],"成功回到游戏大厅",30)
        sleep(5)
    @classmethod
    def record(cls):  #游戏记录
        touch(Template(r"tpl1549173765797.png", rgb=True, record_pos=(0.303, -0.239), resolution=(1920, 1080)))
        sleep(2)
        if exists(Template(r"tpl1549437671238.png", rgb=True, record_pos=(-0.001, 0.007), resolution=(1920, 1080))):
            print("暂无游戏记录")
        else:
            bug_assert(Template(r"tpl1549110041377.png", rgb=True, record_pos=(-0.004, -0.153), resolution=(1920, 1080)),"成功打开游戏记录","无法游戏记录")              
            touch(Template(r"tpl1549692692099.png", rgb=True, record_pos=(0.293, -0.098), resolution=(2160, 1080))) #点击详情
            sleep(2)
            bug_assert(Template(r"tpl1549110451899.png", rgb=True, record_pos=(-0.005, -0.211), resolution=(1920, 1080)),"成功打开游戏记录详情页","无法打开游戏记录详情页")
            touch([60,600])
#                 touch(Template(r"tpl1549171633091.png", rgb=True, record_pos=(0.38, -0.212), resolution=(1920, 1080)))
            sleep(1)                        
        touch([60,600])
#             touch(Template(r"tpl1549171646987.png", rgb=True, record_pos=(0.381, -0.215), resolution=(1920, 1080)))
        sleep(1)
    def test_tiyan(self):
        if not exists(Template(r"tpl1549003593218.png", rgb=True, record_pos=(0.357, -0.244), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("体验房")
        if result:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("体验房"))
    def test_chuji(self):
        if not exists(Template(r"tpl1549003593218.png", rgb=True, record_pos=(0.357, -0.244), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
        result = self.inroom("初级房")
        if result is True:
            self.kaiwan()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))
    def test_zhongji(self):
        if not exists(Template(r"tpl1549003593218.png", rgb=True, record_pos=(0.357, -0.244), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
        result = self.inroom("中级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))
    def test_gaoji(self):
        if not exists(Template(r"tpl1549003593218.png", rgb=True, record_pos=(0.357, -0.244), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
        result = self.inroom("高级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))
    def test_fuhao(self):
        if not exists(Template(r"tpl1549003593218.png", rgb=True, record_pos=(0.357, -0.244), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
        result = self.inroom("富豪房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("富豪房"))

class Game_shisanshui(unittest.TestCase):
    """十三水"""   
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.num = number[0]  # 玩游戏的局数
        cls.web = globalVar.get_web()
        cls.name = {"体验房":Template(r"tpl1550022195152.png", rgb=True, record_pos=(-0.027, -0.02), resolution=(1920, 1080)),"初级房":Template(r"tpl1550022254172.png", rgb=True, record_pos=(0.154, -0.02), resolution=(1920, 1080)),"中级房":Template(r"tpl1550022282161.png", rgb=True, record_pos=(0.353, -0.018), resolution=(1920, 1080)),"高级房":Template(r"tpl1550022314770.png", rgb=True, record_pos=(-0.044, 0.206), resolution=(1920, 1080)),"富豪房":Template(r"tpl1550022349353.png", rgb=True, record_pos=(0.161, 0.205), resolution=(1920, 1080))}

        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
    @classmethod
    def ingame(cls): #进入游戏
        list1 = leimu_P(cls.web)[0]
        list2 = dating(cls.web,"Game_shisanshui")
        result = in_youxi(list1,list2)
        if result is True:
            return pc_wait(Template(r"tpl1549004037289.png", rgb=True, record_pos=(0.33, -0.238), resolution=(1920, 1080)),"***成功进入十三水***",30)
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:            
            raise TargetNotFoundError("进入游戏失败")
    def inroom(self,name): #进入游戏房间
        pc_wait(Template(r"tpl1549004037289.png", rgb=True, record_pos=(0.33, -0.238), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        touch(self.name[name])
        result = pc_pd(Template(r"tpl1550638755228.png", record_pos=(0.122, 0.078), resolution=(1920, 1080)), "金额不足进%s有充值提示"%name)
        if result is True:
            touch(Template(r"tpl1550638755228.png", record_pos=(0.122, 0.078), resolution=(1920, 1080)))
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])
            return 1
        else:
            return pc_wait(Template(r"tpl1548636712841.png", record_pos=(-0.001, 0.032), resolution=(1920, 1080)),"成功进入十三水%s"%name,30)
    def kaiwan(self): #玩游戏
        touch(Template(r"tpl1549509937389.png", rgb=True, record_pos=(-0.003, 0.034), resolution=(1920, 1080)))
        for i in range(self.num):
            pc_wait(Template(r"tpl1549509994006.png", rgb=True, record_pos=(-0.002, 0.222), resolution=(1920, 1080)),"成功匹配到玩家")
            touch(Template(r"tpl1549509994006.png", rgb=True, record_pos=(-0.002, 0.222), resolution=(1920, 1080)))
            sleep(2)
            if exists(Template(r"tpl1549510048465.png", rgb=True, record_pos=(0.127, 0.221), resolution=(1920, 1080))):
                touch(Template(r"tpl1549510048465.png", rgb=True, record_pos=(0.127, 0.221), resolution=(1920, 1080)))
            pc_wait(Template(r"tpl1549509937389.png", rgb=True, record_pos=(-0.003, 0.034), resolution=(1920, 1080)),"第%s局游戏结束"%(i+1))
            if i != self.num-1:
                dianji(Template(r"tpl1549509937389.png", rgb=True, record_pos=(-0.003, 0.034), resolution=(1920, 1080)))
        start_time = time.time()
        while True:
            if exists(Template(r"tpl1551417819657.png", rgb=True, record_pos=(-0.003, 0.032), resolution=(1920, 1080))):
                touch(Template(r"tpl1551417804622.png", rgb=True, record_pos=(-0.444, -0.239), resolution=(1920, 1080)))  #返回选房大厅
                break
            elif exists(Template(r"tpl1548825548041.png", rgb=True, record_pos=(0.33, -0.243), resolution=(1920, 1080))):
                break
            else:
                if chaoshi(start_time) is False:
                    break
        pc_wait(Template(r"tpl1548825548041.png", rgb=True, record_pos=(0.33, -0.243), resolution=(1920, 1080)),"成功回到选场大厅")
    def more(self):  #语音
        sleep(1)
        touch(Template(r"tpl1549431454731.png", rgb=True, record_pos=(0.442, -0.238), resolution=(1920, 1080)))
        sleep(1)
        if exists(Template(r"tpl1550204223511.png", threshold=0.9, rgb=True, record_pos=(-0.289, -0.025), resolution=(1920, 1080))):
            touch(Template(r"tpl1550204245623.png", rgb=True, target_pos=9, record_pos=(-0.302, -0.11), resolution=(1920, 1080)))

            touch(Template(r"tpl1550204265060.png", rgb=True, target_pos=9, record_pos=(-0.31, -0.078), resolution=(1920, 1080)))
            bug_assert(Template(r"tpl1550204313554.png", threshold=0.9, rgb=True, record_pos=(-0.275, -0.024), resolution=(1920, 1080)),"成功取消音效","无法取消音效")                
        else:
            touch(Template(r"tpl1550204345495.png", rgb=True, target_pos=9, record_pos=(-0.304, -0.11), resolution=(1920, 1080)))
            touch(Template(r"tpl1550204369522.png", rgb=True, target_pos=9, record_pos=(-0.304, -0.027), resolution=(1920, 1080)))
            sleep(1)
            bug_assert(Template(r"tpl1549523212645.png", rgb=True, record_pos=(-0.258, -0.024), resolution=(1920, 1080)),"成功开启音效","无法开启音效")
        touch(Template(r"tpl1551417369214.png", rgb=True, record_pos=(0.391, -0.212), resolution=(1920, 1080))) 
    @classmethod
    def exit(cls):  #退出
        start_time = time.time()
        while True:                
            if exists(Template(r"tpl1548636712841.png", record_pos=(-0.001, 0.032), resolution=(1920, 1080))):
                touch(Template(r"tpl1549695785788.png", rgb=True, record_pos=(-0.447, -0.212), resolution=(2160, 1080))) #返回选房大厅
                break
            elif exists(Template(r"tpl1548825548041.png", rgb=True, record_pos=(0.33, -0.243), resolution=(1920, 1080))):
                break
            else:
                if chaoshi(start_time) is False:
                    break
        pc_wait(Template(r"tpl1548825548041.png", rgb=True, record_pos=(0.33, -0.243), resolution=(1920, 1080)),"成功回到选场大厅")
        touch(Template(r"tpl1549695711871.png", rgb=True, record_pos=(-0.453, -0.215), resolution=(2160, 1080))) # 回到游戏大厅
        pc_wait(leimu_P(cls.web)[0],"成功回到游戏大厅",30)
        sleep(5)
    @classmethod
    def record(cls):  #游戏记录
        touch(Template(r"tpl1549175718348.png", rgb=True, record_pos=(0.272, -0.24), resolution=(1920, 1080)))
        sleep(2)
        if exists(Template(r"tpl1549437671238.png", rgb=True, record_pos=(-0.001, 0.007), resolution=(1920, 1080))):
            print("暂无游戏记录")
        else:
            bug_assert(Template(r"tpl1549110041377.png", rgb=True, record_pos=(-0.004, -0.153), resolution=(1920, 1080)),"成功打开游戏记录","无法游戏记录")             
            touch(Template(r"tpl1550563081039.png", rgb=True, record_pos=(0.331, -0.112), resolution=(1920, 1080))) #点击详情
            sleep(2)
            bug_assert(Template(r"tpl1549110451899.png", rgb=True, record_pos=(-0.005, -0.211), resolution=(1920, 1080)),"成功打开游戏记录详情页","无法打开游戏记录详情页")
            touch(Template(r"tpl1550563114700.png", rgb=True, record_pos=(0.379, -0.215), resolution=(1920, 1080)))
            sleep(2)           
        touch(Template(r"tpl1550563166442.png", rgb=True, record_pos=(0.381, -0.214), resolution=(1920, 1080)))
        sleep(1)
    def test_tiyan(self):
        if not exists(Template(r"tpl1549004037289.png", rgb=True, record_pos=(0.33, -0.238), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                cls.exit()
            self.ingame()
        result = self.inroom("体验房")
        if result:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("体验房"))
    def test_chuji(self):
        if not exists(Template(r"tpl1549004037289.png", rgb=True, record_pos=(0.33, -0.238), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                cls.exit()
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.kaiwan()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))
    def test_zhongji(self):
        if not exists(Template(r"tpl1549004037289.png", rgb=True, record_pos=(0.33, -0.238), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                cls.exit()
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))        
    def test_gaoji(self):
        if not exists(Template(r"tpl1549004037289.png", rgb=True, record_pos=(0.33, -0.238), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                cls.exit()
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))
    def test_fuhao(self):
        if not exists(Template(r"tpl1549004037289.png", rgb=True, record_pos=(0.33, -0.238), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                cls.exit()
            self.ingame()
        result = self.inroom("富豪房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("富豪房"))

class Game_erbagang(unittest.TestCase):
    """二八杠"""           
    @classmethod
    def setUpClass(cls):
        cls.num = number[1]  # 玩游戏的局数
        cls.web = globalVar.get_web()
        cls.name = {"体验房":Template(r"tpl1550811529109.png", rgb=True, record_pos=(-0.095, -0.049), resolution=(1920, 1080)),"初级房":Template(r"tpl1550108702768.png", rgb=True, record_pos=(0.131, -0.05), resolution=(1920, 1080)),"中级房":   Template(r"tpl1550108727868.png", rgb=True, record_pos=(0.366, -0.053), resolution=(1920, 1080)),"高级房":Template(r"tpl1550108758630.png", rgb=True, record_pos=(-0.105, 0.176), resolution=(1920, 1080)),"富豪房":Template(r"tpl1550108781208.png", rgb=True, record_pos=(0.139, 0.171), resolution=(1920, 1080))}

        """前置条件"""
        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError 
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
    @classmethod
    def ingame(cls): #进入游戏
        list1 = leimu_P(cls.web)[0]
        list2 = dating(cls.web,"Game_erbagang")
        result = in_youxi(list1,list2)
        if result is True:
            return pc_wait(Template(r"tpl1548825740175.png", rgb=True, record_pos=(0.335, -0.239), resolution=(1920, 1080)),"***成功进入二八杠***",30)
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:            
            raise TargetNotFoundError("进入游戏失败")           
    def inroom(self,name): #进入游戏房间
        pc_wait(Template(r"tpl1548825740175.png", rgb=True, record_pos=(0.335, -0.239), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        touch(self.name[name])
        result = pc_pd(Template(r"tpl1550638755228.png", record_pos=(0.122, 0.078), resolution=(1920, 1080)), "金额不足进%s有充值提示"%name)
        if result is True:
            touch(Template(r"tpl1550638755228.png", record_pos=(0.122, 0.078), resolution=(1920, 1080)))
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])
            sleep(2)
            return 1
        else:

            return pc_wait(Template(r"tpl1548637252787.png", rgb=True, record_pos=(-0.002, 0.022), resolution=(1920, 1080)),"成功进入二八杠%s"%name,30) 
    def kaiwan(self): #玩游戏
        if exists(Template(r"tpl1548637252787.png", rgb=True, record_pos=(-0.002, 0.022), resolution=(1920, 1080))):
            touch(Template(r"tpl1548637252787.png", rgb=True, record_pos=(-0.002, 0.022), resolution=(1920, 1080)))          
        for i in range(5):
            pc_wait(Template(r"tpl1549621506178.png", rgb=True, record_pos=(-0.291, 0.073), resolution=(1920, 1080)),"成功匹配到家")
            touch(Template(r"tpl1551441162154.png", rgb=True, target_pos=6, record_pos=(-0.144, 0.072), resolution=(1920, 1080)))
            pc_wait(Template(r"tpl1551448517495.png", record_pos=(-0.267, -0.091), resolution=(1920, 1080)),"第%s局游戏结束"%(i+1))
            if exists(Template(r"tpl1551447128000.png", record_pos=(0.007, -0.102), resolution=(1920, 1080))):
                touch(Template(r"tpl1551447132636.png", rgb=True, record_pos=(0.002, 0.085), resolution=(1920, 1080)))
                pc_wait(Template(r"tpl1548825740175.png", rgb=True, record_pos=(0.335, -0.239), resolution=(1920, 1080)),"游戏提前结束回到选场大厅")
                break           
#             pc_wait(Template(r"tpl1551446696864.png", rgb=False, record_pos=(-0.052, 0.18), resolution=(1920, 1080)),"第%s局游戏结束"%(i+1))
        if exists(Template(r"tpl1551448683659.png", rgb=True, record_pos=(0.139, -0.235), resolution=(1920, 1080))):
            pass
        else:
            pc_wait(Template(r"tpl1549526510208.png", rgb=True, record_pos=(0.157, 0.195), resolution=(1920, 1080)),"5局游戏正常结束")
            start_time = time.time()
            while True:                
                if exists(Template(r"tpl1549526561589.png", rgb=True, record_pos=(-0.205, 0.196), resolution=(1920, 1080))):
                    touch(Template(r"tpl1549526584728.png", rgb=True, record_pos=(-0.206, 0.193), resolution=(1920, 1080)))
                    break  
                elif exists(Template(r"tpl1549526618765.png", rgb=True, record_pos=(-0.001, 0.022), resolution=(1920, 1080))):
                    touch(Template(r"tpl1549176899927.png", rgb=True, record_pos=(-0.434, -0.229), resolution=(1920, 1080)))
                    break
                elif exists(Template(r"tpl1548825740175.png", rgb=True, record_pos=(0.335, -0.239), resolution=(1920, 1080))):
                    break
                else:
                    chaoshi(start_time)                
            pc_wait(Template(r"tpl1548825740175.png", rgb=True, record_pos=(0.335, -0.239), resolution=(1920, 1080)),"成功回到选场大厅")
    def more(self):  #语音
        sleep(1)
        touch(Template(r"tpl1549176622729.png", rgb=True, record_pos=(0.433, -0.232), resolution=(1920, 1080)))
        sleep(1)
        if exists(Template(r"tpl1549523212645.png", rgb=True, record_pos=(-0.258, -0.024), resolution=(1920, 1080))):
            touch(Template(r"tpl1549523248168.png", rgb=True, record_pos=(-0.258, -0.056), resolution=(1920, 1080)))
            touch(Template(r"tpl1549523268490.png", rgb=True, record_pos=(-0.258, 0.008), resolution=(1920, 1080)))
            bug_assert(Template(r"tpl1549523303097.png", rgb=True, record_pos=(-0.258, -0.026), resolution=(1920, 1080)),"成功取消音效","无法取消音效")                
        else:
            touch(Template(r"tpl1549523350713.png", rgb=True, record_pos=(-0.258, -0.057), resolution=(1920, 1080)))
            touch(Template(r"tpl1549523350713.png", rgb=True, record_pos=(-0.258, -0.057), resolution=(1920, 1080)))
            sleep(1)
            bug_assert(Template(r"tpl1549523212645.png", rgb=True, record_pos=(-0.258, -0.024), resolution=(1920, 1080)),"成功开启音效","无法开启音效")
        touch(coordinate([60,600]),100)
    @classmethod
    def exit(cls,num = None):  #退出
        num = num or 0
        if num == 1:
            if exists(Template(r"tpl1548825740175.png", rgb=True, record_pos=(0.335, -0.239), resolution=(1920, 1080))):
                pass
            else:
                start_time = time.time()
                while True:
                    if exists(Template(r"tpl1549176753765.png", rgb=True, record_pos=(-0.172, 0.191), resolution=(1920, 1080))):
                        touch(Template(r"tpl1549176753765.png", rgb=True, record_pos=(-0.172, 0.191), resolution=(1920, 1080)))
                        break  
                    elif exists(Template(r"tpl1548637252787.png", rgb=True, record_pos=(-0.002, 0.022), resolution=(1920, 1080))):
                        touch(Template(r"tpl1549176899927.png", rgb=True, record_pos=(-0.434, -0.229), resolution=(1920, 1080)))
                        break
                    else:
                        if chaoshi(start_time) is False:
                            break
                pc_wait(Template(r"tpl1548825740175.png", rgb=True, record_pos=(0.335, -0.239), resolution=(1920, 1080)),"成功回到选场大厅")
        else:
            start_time = time.time()
            while True:
                if exists(Template(r"tpl1549176753765.png", rgb=True, record_pos=(-0.172, 0.191), resolution=(1920, 1080))):
                    touch(Template(r"tpl1549176753765.png", rgb=True, record_pos=(-0.172, 0.191), resolution=(1920, 1080)))
                    break  
                elif exists(Template(r"tpl1548637252787.png", rgb=True, record_pos=(-0.002, 0.022), resolution=(1920, 1080))):
                    touch(Template(r"tpl1549176899927.png", rgb=True, record_pos=(-0.434, -0.229), resolution=(1920, 1080)))
                    break
                elif exists(Template(r"tpl1548825740175.png", rgb=True, record_pos=(0.335, -0.239), resolution=(1920, 1080))):
                    break
                else:
                    if chaoshi(start_time) is False:
                        break
            pc_wait(Template(r"tpl1548825740175.png", rgb=True, record_pos=(0.335, -0.239), resolution=(1920, 1080)),"成功回到选场大厅")   
        touch(Template(r"tpl1549694075609.png", rgb=True, record_pos=(-0.45, -0.212), resolution=(2160, 1080)))            
        pc_wait(leimu_P(cls.web)[0],"成功回到游戏大厅",30)
        sleep(5)
    @classmethod
    def record(cls):
        touch(Template(r"tpl1549437620045.png", record_pos=(0.284, -0.237), resolution=(1920, 1080)))
        sleep(1)

        if exists(Template(r"tpl1549437671238.png", rgb=True, record_pos=(-0.001, 0.007), resolution=(1920, 1080))):
            assert_exists(Template(r"tpl1549437671238.png", rgb=True, record_pos=(-0.001, 0.007), resolution=(1920, 1080)),"暂无游戏记录")
        else:
            pc_wait(Template(r"tpl1549438003419.png", record_pos=(-0.003, -0.153), resolution=(1920, 1080)),"成功打开游戏记录")
            touch(Template(r"tpl1549694111274.png", rgb=True, record_pos=(0.293, -0.098), resolution=(2160, 1080))) #点击详情
            sleep(1)
            pc_wait(Template(r"tpl1549438104722.png", rgb=True, record_pos=(-0.002, -0.216), resolution=(1920, 1080)),"成功打开游戏记录详情页")
            touch(Template(r"tpl1549439011717.png", rgb=True, record_pos=(0.381, -0.217), resolution=(1920, 1080)))
            sleep(1)
        touch(Template(r"tpl1549439029994.png", rgb=True, record_pos=(0.383, -0.214), resolution=(1920, 1080)))
        sleep(1)
    def test_tiyan(self):
        if not exists(Template(r"tpl1548825740175.png", rgb=True, record_pos=(0.335, -0.239), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("体验房")
        if result:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("体验房"))
    def test_chuji(self):
        if not exists(Template(r"tpl1548825740175.png", rgb=True, record_pos=(0.335, -0.239), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.kaiwan()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))                      
    def test_zhongji(self):
        if not exists(Template(r"tpl1548825740175.png", rgb=True, record_pos=(0.335, -0.239), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))
    def test_gaoji(self):
        if not exists(Template(r"tpl1548825740175.png", rgb=True, record_pos=(0.335, -0.239), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))
    def test_fuhao(self):
        if not exists(Template(r"tpl1548825740175.png", rgb=True, record_pos=(0.335, -0.239), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("富豪房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("富豪房"))
            
class Game_ershiyidian(unittest.TestCase):
    """21点"""
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.num = number[0]  # 玩游戏的局数
        cls.web = globalVar.get_web()
        cls.name = {"体验房":Template(r"tpl1550811587745.png", rgb=True, record_pos=(-0.013, -0.021), resolution=(1920, 1080)),"初级房":Template(r"tpl1550022254172.png", rgb=True, record_pos=(0.154, -0.02), resolution=(1920, 1080)),"中级房":Template(r"tpl1550022282161.png", rgb=True, record_pos=(0.353, -0.018), resolution=(1920, 1080)),"高级房":Template(r"tpl1550022314770.png", rgb=True, record_pos=(-0.044, 0.206), resolution=(1920, 1080)),"富豪房":Template(r"tpl1550022349353.png", rgb=True, record_pos=(0.161, 0.205), resolution=(1920, 1080))}
        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
    @classmethod
    def ingame(cls): #进入游戏
        list1 = leimu_P(cls.web)[0]
        list2 = dating(cls.web,"Game_ershiyidian")
        result = in_youxi(list1,list2)
        if result is True:
            return pc_wait(Template(r"tpl1549005152475.png", rgb=True, record_pos=(0.358, -0.239), resolution=(1920, 1080)),"***成功进入21点***",30)
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:            
            raise TargetNotFoundError("进入游戏失败")           
    def inroom(self,name): #进入游戏房间
        pc_wait(Template(r"tpl1549005152475.png", rgb=True, record_pos=(0.358, -0.239), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        touch(self.name[name])
        sleep(1)
        if exists(Template(r"tpl1550648950387.png", rgb=True, record_pos=(-0.002, -0.002), resolution=(1920, 1080))):
            assert_exists(Template(r"tpl1550648950387.png", rgb=True, record_pos=(-0.002, -0.002), resolution=(1920, 1080)),"金额不足进%s有提示"%name)
            return 1
        else:
            return pc_wait(Template(r"tpl1548640619666.png", rgb=True, record_pos=(-0.003, 0.235), resolution=(1920, 1080)),"成功进入21点%s"%name,30)
    def kaiwan(self): #玩游戏
        if exists(Template(r"tpl1549508512828.png", rgb=True, record_pos=(-0.003, 0.233), resolution=(1920, 1080))):
            touch(Template(r"tpl1549508512828.png", rgb=True, record_pos=(-0.003, 0.233), resolution=(1920, 1080)))
        if exists(Template(r"tpl1549508630577.png", rgb=True, record_pos=(-0.011, 0.232), resolution=(1920, 1080))):
            touch(Template(r"tpl1549508630577.png", rgb=True, record_pos=(-0.011, 0.232), resolution=(1920, 1080)))
        for i in range(self.num):
            pc_wait(Template(r"tpl1550649812789.png", rgb=True, record_pos=(-0.287, 0.247), resolution=(1920, 1080)),"成功匹配到玩家")
            if i == self.num-1:
                dianji(Template(r"tpl1550650024228.png", threshold=0.8, rgb=True, record_pos=(-0.161, 0.247), resolution=(1920, 1080)))
#                 touch(Template(r"tpl1550208307749.png", rgb=True, record_pos=(-0.138, 0.246), resolution=(1920, 1080)))
#                 touch(Template(r"tpl1550208371968.png", record_pos=(0.133, 0.245), resolution=(1920, 1080)))
            else:
                dianji(Template(r"tpl1550649812789.png", rgb=True, record_pos=(-0.287, 0.247), resolution=(1920, 1080)))            
#                 dianji(Template(r"tpl1549508691927.png", rgb=True, record_pos=(0.266, 0.244), resolution=(1920, 1080)))
            pc_wait(Template(r"tpl1549508630577.png", rgb=True, record_pos=(-0.011, 0.232), resolution=(1920, 1080)),"第%s局游戏结束"%(i+1))
            if i != self.num-1:
                dianji(Template(r"tpl1549508630577.png", rgb=True, record_pos=(-0.011, 0.232), resolution=(1920, 1080)),120)                   
#                 dianji(Template(r"tpl1549180544608.png", record_pos=(0.268, 0.247), resolution=(1920, 1080)))
        start_time = time.time()
        while True:                
            if exists(Template(r"tpl1549187967739.png", rgb=True, record_pos=(-0.003, 0.231), resolution=(1920, 1080))):
                touch(Template(r"tpl1549693638630.png", rgb=True, record_pos=(-0.457, -0.213), resolution=(2160, 1080)))  #返回选房大厅 
                break
            elif exists(Template(r"tpl1549180572254.png", rgb=True, record_pos=(-0.011, 0.228), resolution=(1920, 1080))):
                touch(Template(r"tpl1549693638630.png", rgb=True, record_pos=(-0.457, -0.213), resolution=(2160, 1080)))  #返回选房大厅
                pc_wait(Template(r"tpl1548825945936.png", rgb=True, record_pos=(0.354, -0.24), resolution=(1920, 1080)),"成功回到选场大厅") 
                break
            elif exists(Template(r"tpl1549005152475.png", rgb=True, record_pos=(0.358, -0.239), resolution=(1920, 1080))):
                break
            else:
                if chaoshi(start_time) is False:
                    break                
        pc_wait(Template(r"tpl1548825945936.png", rgb=True, record_pos=(0.354, -0.24), resolution=(1920, 1080)),"成功回到选场大厅")
    def more(self):  #语音
        touch(Template(r"tpl1550207490090.png", rgb=True, record_pos=(0.441, -0.242), resolution=(1920, 1080)))
        sleep(1)
        if exists(Template(r"tpl1549524133121.png", rgb=True, record_pos=(-0.228, -0.018), resolution=(1920, 1080))):
            touch(Template(r"tpl1550207368656.png", rgb=True, target_pos=9, record_pos=(-0.284, -0.108), resolution=(1920, 1080)))

            sleep(1)
            touch(Template(r"tpl1550207391082.png", rgb=True, target_pos=9, record_pos=(-0.297, -0.023), resolution=(1920, 1080)))
            sleep(1)
            bug_assert(Template(r"tpl1549524177438.png", rgb=True, record_pos=(-0.228, -0.017), resolution=(1920, 1080)),"成功取消音效","无法取消音效")

        else:
            touch(Template(r"tpl1550207424101.png", rgb=True, target_pos=9, record_pos=(-0.293, -0.108), resolution=(1920, 1080)))
            touch(Template(r"tpl1550207457218.png", rgb=True, target_pos=9, record_pos=(-0.298, -0.022), resolution=(1920, 1080)))
            bug_assert(Template(r"tpl1549524133121.png", rgb=True, record_pos=(-0.228, -0.018), resolution=(1920, 1080)),"成功开启音效","无法开启音效")
        touch(coordinate([60,600]),100)
    @classmethod
    def exit(cls):  #退出
        start_time = time.time()
        while True:
            if exists(Template(r"tpl1549187967739.png", rgb=True, record_pos=(-0.003, 0.231), resolution=(1920, 1080))):
                touch(Template(r"tpl1549693638630.png", rgb=True, record_pos=(-0.457, -0.213), resolution=(2160, 1080))) #返回选房大厅 
                break
            elif exists(Template(r"tpl1549180572254.png", rgb=True, record_pos=(-0.011, 0.228), resolution=(1920, 1080))):
                touch(Template(r"tpl1549693638630.png", rgb=True, record_pos=(-0.457, -0.213), resolution=(2160, 1080))) #返回选房大厅
                pc_wait(Template(r"tpl1548825945936.png", rgb=True, record_pos=(0.354, -0.24), resolution=(1920, 1080)),"成功回到选场大厅") 
                break
            elif exists(Template(r"tpl1549005152475.png", rgb=True, record_pos=(0.358, -0.239), resolution=(1920, 1080))):
                break
            else:
                if chaoshi(start_time) is False:
                    break
        pc_wait(Template(r"tpl1548825945936.png", rgb=True, record_pos=(0.354, -0.24), resolution=(1920, 1080)),"成功回到选场大厅",30)
        touch(Template(r"tpl1549693692782.png", rgb=True, record_pos=(-0.444, -0.218), resolution=(2160, 1080))) # 回到游戏大厅
        pc_wait(leimu_P(cls.web)[0],"成功回到游戏大厅",30)
        sleep(5)
    @classmethod
    def record(cls):  #游戏记录
        touch(Template(r"tpl1549180688153.png", rgb=True, record_pos=(0.253, -0.241), resolution=(1920, 1080)))
        sleep(2)
        if exists(Template(r"tpl1550650415033.png", threshold=0.9, rgb=True, record_pos=(0.004, 0.024), resolution=(1920, 1080))):
            assert_exists(Template(r"tpl1550650415033.png", threshold=0.9, rgb=True, record_pos=(0.004, 0.024), resolution=(1920, 1080)),"无游戏记录")
        else:
            bug_assert(Template(r"tpl1549180821583.png", rgb=True, record_pos=(-0.006, -0.142), resolution=(1920, 1080)),"成功打开游戏记录","无法游戏记录")              
            touch(Template(r"tpl1549693757727.png", rgb=True, record_pos=(0.294, -0.087), resolution=(2160, 1080))) #点击详情
            sleep(2)
            bug_assert(Template(r"tpl1549180874537.png", rgb=True, record_pos=(-0.013, -0.208), resolution=(1920, 1080)),"成功打开游戏记录详情页","无法打开游戏记录详情页")
            touch([70,600])
            sleep(1)
        touch([70,600])
        sleep(1)
    def test_tiyan(self):
        if not exists(Template(r"tpl1549005152475.png", rgb=True, record_pos=(0.358, -0.239), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("体验房")
        if result:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("体验房"))
    def test_chuji(self):
        if not exists(Template(r"tpl1549005152475.png", rgb=True, record_pos=(0.358, -0.239), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.kaiwan()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))
    def test_zhongji(self):
        if not exists(Template(r"tpl1549005152475.png", rgb=True, record_pos=(0.358, -0.239), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))        
    def test_gaoji(self):
        if not exists(Template(r"tpl1549005152475.png", rgb=True, record_pos=(0.358, -0.239), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))
    def test_fuhao(self):
        if not exists(Template(r"tpl1549005152475.png", rgb=True, record_pos=(0.358, -0.239), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("富豪房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("富豪房"))

class Game_fuguisangong(unittest.TestCase):
    """富贵三公"""        
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.num = number[0]  # 玩游戏的局数
        cls.web = globalVar.get_web()
        cls.name = {"体验房":Template(r"tpl1550805195746.png", rgb=True, record_pos=(-0.031, -0.034), resolution=(1920, 1080)),"初级房":Template(r"tpl1550022254172.png", rgb=True, record_pos=(0.154, -0.02), resolution=(1920, 1080)),"中级房":Template(r"tpl1550022282161.png", rgb=True, record_pos=(0.353, -0.018), resolution=(1920, 1080)),"高级房":Template(r"tpl1550022314770.png", rgb=True, record_pos=(-0.044, 0.206), resolution=(1920, 1080)),"富豪房":Template(r"tpl1550022349353.png", rgb=True, record_pos=(0.161, 0.205), resolution=(1920, 1080))}

        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
    @classmethod
    def ingame(cls): #进入游戏
        list1 = leimu_P(cls.web)[0]
        list2 = dating(cls.web,"Game_fuguisangong")
        result = in_youxi(list1,list2)
        if result is True:    
            return pc_wait(Template(r"tpl1549005819761.png", rgb=True, record_pos=(0.344, -0.247), resolution=(1920, 1080)),"***成功进入富贵三公***",30)
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:            
            raise TargetNotFoundError("进入游戏失败")
    def inroom(self,name): #进入游戏房间
        pc_wait(Template(r"tpl1549005819761.png", rgb=True, record_pos=(0.344, -0.247), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        touch(self.name[name])
        sleep(2)
        result = pc_pd(Template(r"tpl1550638755228.png", record_pos=(0.122, 0.078), resolution=(1920, 1080)), "金额不足进%s有充值提示"%name)
        if result is True:
            touch(Template(r"tpl1550638755228.png", record_pos=(0.122, 0.078), resolution=(1920, 1080)))
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])
            return 1
        else:
            return pc_wait(Template(r"tpl1548565455404.png", rgb=True, record_pos=(-0.002, 0.119), resolution=(1920, 1080)),"成功进入富贵三公%s"%name,30)
    def kaiwan(self): #玩游戏
        if exists(Template(r"tpl1549507688066.png", rgb=True, record_pos=(0.002, 0.12), resolution=(1920, 1080))):
            touch(Template(r"tpl1549507688066.png", rgb=True, record_pos=(0.002, 0.12), resolution=(1920, 1080)))
        if exists(Template(r"tpl1549422328697.png", rgb=True, record_pos=(-0.028, 0.085), resolution=(1920, 1080))):
            touch(Template(r"tpl1549422328697.png", rgb=True, record_pos=(-0.028, 0.085), resolution=(1920, 1080)))
        for i in range(self.num):
            pc_wait(Template(r"tpl1549507771347.png", rgb=True, record_pos=(0.108, 0.081), resolution=(1920, 1080)),"成功匹配到玩家")
            dianji(Template(r"tpl1549507771347.png", rgb=True, record_pos=(0.108, 0.081), resolution=(1920, 1080)))
            for j in range(2):
                if exists(Template(r"tpl1549507583678.png", rgb=True, record_pos=(-0.164, 0.083), resolution=(1920, 1080))):
                    touch(Template(r"tpl1549507583678.png", rgb=True, record_pos=(-0.164, 0.083), resolution=(1920, 1080)))
                    break
            dianji(Template(r"tpl1549191715899.png", rgb=True, record_pos=(0.236, 0.176), resolution=(1920, 1080)))
            pc_wait(Template(r"tpl1549422328697.png", rgb=True, record_pos=(-0.028, 0.085), resolution=(1920, 1080)),"第%s局游戏结束"%(i+1))
            if i != self.num-1:
                dianji(Template(r"tpl1549422328697.png", rgb=True, record_pos=(-0.028, 0.085), resolution=(1920, 1080)))            
        start_time = time.time()
        while True:
            if exists(Template(r"tpl1548565455404.png", rgb=True, record_pos=(-0.002, 0.119), resolution=(1920, 1080))):
                touch(Template(r"tpl1549191181327.png", rgb=True, record_pos=(-0.452, -0.229), resolution=(1920, 1080)))
                break   
            elif exists(Template(r"tpl1549191135585.png", rgb=True, record_pos=(-0.002, 0.082), resolution=(1920, 1080))):
                touch(Template(r"tpl1549191181327.png", rgb=True, record_pos=(-0.452, -0.229), resolution=(1920, 1080)))
                break

            elif exists(Template(r"tpl1549005819761.png", rgb=True, record_pos=(0.344, -0.247), resolution=(1920, 1080))):
                break
            else:
                if chaoshi(start_time) is False:
                    break
        pc_wait(Template(r"tpl1548826035880.png", rgb=True, record_pos=(0.339, -0.249), resolution=(1920, 1080)),"成功回到选场大厅")
    def more(self):  #语音
        sleep(1)
        touch(Template(r"tpl1550206467486.png", threshold=0.8, rgb=True, record_pos=(0.449, -0.22), resolution=(1920, 1080)))
        sleep(1)
        if exists(Template(r"tpl1550205953707.png", threshold=0.9, rgb=True, record_pos=(-0.258, -0.023), resolution=(1920, 1080))):
            touch(Template(r"tpl1550205364445.png", rgb=True, target_pos=9, record_pos=(-0.306, -0.109), resolution=(1920, 1080)))
            touch(Template(r"tpl1550205398007.png", rgb=True, target_pos=9, record_pos=(-0.31, -0.027), resolution=(1920, 1080)))
            
            bug_assert(Template(r"tpl1549443120748.png", rgb=True, record_pos=(-0.198, -0.02), resolution=(2280, 1080)),"成功取消音效","无法取消音效")                
        else:
            touch(Template(r"tpl1550205427271.png", rgb=True, target_pos=9, record_pos=(-0.305, -0.11), resolution=(1920, 1080)))
            touch(Template(r"tpl1550205447849.png", rgb=True, target_pos=9, record_pos=(-0.307, -0.029), resolution=(1920, 1080)))
            sleep(1)
            bug_assert(Template(r"tpl1550205953707.png", threshold=0.9, rgb=True, record_pos=(-0.258, -0.023), resolution=(1920, 1080)),"成功开启音效","无法开启音效")
        touch(coordinate([60,600]))
        sleep(1)        
    @classmethod
    def exit(cls):  #退出
        start_time = time.time()
        while True:
            if exists(Template(r"tpl1548565455404.png", rgb=True, record_pos=(-0.002, 0.119), resolution=(1920, 1080))):
                touch(Template(r"tpl1549191181327.png", rgb=True, record_pos=(-0.452, -0.229), resolution=(1920, 1080)))
                break   
            elif exists(Template(r"tpl1549191135585.png", rgb=True, record_pos=(-0.002, 0.082), resolution=(1920, 1080))):
                touch(Template(r"tpl1549191181327.png", rgb=True, record_pos=(-0.452, -0.229), resolution=(1920, 1080)))
                break                
            elif exists(Template(r"tpl1549005819761.png", rgb=True, record_pos=(0.344, -0.247), resolution=(1920, 1080))):
                break
            else:
                if chaoshi(start_time) is False:
                    break
        pc_wait(Template(r"tpl1548826035880.png", rgb=True, record_pos=(0.339, -0.249), resolution=(1920, 1080)),"成功回到选场大厅")
        touch(Template(r"tpl1549700484493.png", rgb=True, record_pos=(-0.457, -0.245), resolution=(1920, 1080)))  # 回到游戏大厅
        pc_wait(leimu_P(cls.web)[0],"成功回到游戏大厅",30)
        sleep(5)
    @classmethod
    def record(cls):  #游戏记录
        touch(Template(r"tpl1549191902420.png", rgb=True, record_pos=(0.274, -0.245), resolution=(1920, 1080)))
        sleep(2)
        if exists(Template(r"tpl1549437671238.png", rgb=True, record_pos=(-0.001, 0.007), resolution=(1920, 1080))):
            print("暂无游戏记录")
        else:
            bug_assert(Template(r"tpl1549192039334.png", rgb=True, record_pos=(-0.006, -0.153), resolution=(1920, 1080)),"成功打开游戏记录","无法游戏记录")              
            touch(Template(r"tpl1549936563750.png", rgb=True, record_pos=(0.329, -0.114), resolution=(1920, 1080))) #点击详情
            sleep(2)
            bug_assert(Template(r"tpl1549936607021.png", record_pos=(-0.328, -0.082), resolution=(1920, 1080)),"成功打开游戏记录详情页","无法打开游戏记录详情页")
            touch(Template(r"tpl1549192119367.png", rgb=True, record_pos=(0.377, -0.215), resolution=(1920, 1080)))
            sleep(2)
        touch(Template(r"tpl1549192131345.png", rgb=True, record_pos=(0.377, -0.212), resolution=(1920, 1080)))
        sleep(1)
    def test_tiyan(self):
        if not exists(Template(r"tpl1549005819761.png", rgb=True, record_pos=(0.344, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("体验房")
        if result:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("体验房"))
    def test_chuji(self):
        if not exists(Template(r"tpl1549005819761.png", rgb=True, record_pos=(0.344, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.kaiwan()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))
    def test_zhongji(self):
        if not exists(Template(r"tpl1549005819761.png", rgb=True, record_pos=(0.344, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))        
    def test_gaoji(self):
        if not exists(Template(r"tpl1549005819761.png", rgb=True, record_pos=(0.344, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))
    def test_fuhao(self):
        if not exists(Template(r"tpl1549005819761.png", rgb=True, record_pos=(0.344, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("富豪房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("富豪房"))

class Game_tongbiniuniu(unittest.TestCase):
    """通比牛牛"""       
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.num = number[0]  # 玩游戏的局数
        cls.web = globalVar.get_web()
        cls.name = {"体验房":Template(r"tpl1550805398388.png", rgb=True, record_pos=(-0.018, -0.021), resolution=(1920, 1080)),"初级房":Template(r"tpl1550022254172.png", rgb=True, record_pos=(0.154, -0.02), resolution=(1920, 1080)),"中级房":Template(r"tpl1550022282161.png", rgb=True, record_pos=(0.353, -0.018), resolution=(1920, 1080)),"高级房":Template(r"tpl1550022314770.png", rgb=True, record_pos=(-0.044, 0.206), resolution=(1920, 1080)),"富豪房":Template(r"tpl1550022349353.png", rgb=True, record_pos=(0.161, 0.205), resolution=(1920, 1080))}
        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
    @classmethod
    def ingame(cls): #进入游戏
        list1 = leimu_P(cls.web)[0]
        list2 = dating(cls.web,"Game_tongbiniuniu")
        result = in_youxi(list1,list2)
        if result is True:        
            return pc_wait(Template(r"tpl1549006775927.png", record_pos=(0.357, -0.249), resolution=(1920, 1080)),"***成功进入通比牛牛***",30)
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:            
            raise TargetNotFoundError("进入游戏失败")
    def inroom(self,name): #进入游戏房间
        pc_wait(Template(r"tpl1549006775927.png", record_pos=(0.357, -0.249), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        touch(self.name[name])    
        result = pc_pd(Template(r"tpl1550638755228.png", record_pos=(0.122, 0.078), resolution=(1920, 1080)), "金额不足进%s有充值提示"%name)
        if result is True:
            touch(Template(r"tpl1550638755228.png", record_pos=(0.122, 0.078), resolution=(1920, 1080)))
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])
            return 1
        else:
            return pc_wait(Template(r"tpl1548563245933.png", rgb=True, record_pos=(0.001, 0.08), resolution=(1920, 1080)),"成功进入通比牛牛%s"%name,30)           
    def kaiwan(self): #玩游戏
        if exists(Template(r"tpl1549506672729.png", rgb=True, record_pos=(0.001, 0.08), resolution=(1920, 1080))):
            touch(Template(r"tpl1549506672729.png", rgb=True, record_pos=(0.001, 0.08), resolution=(1920, 1080)))
        if exists(Template(r"tpl1549243983021.png", rgb=True, record_pos=(-0.003, 0.081), resolution=(1920, 1080))):
            touch(Template(r"tpl1549243983021.png", rgb=True, record_pos=(-0.003, 0.081), resolution=(1920, 1080)))
        for i in range(self.num):
            dianji(Template(r"tpl1549244001408.png", rgb=True, record_pos=(-0.002, 0.052), resolution=(1920, 1080)))
            dianji(Template(r"tpl1549244039570.png", rgb=True, record_pos=(0.248, 0.189), resolution=(1920, 1080)))
            pc_wait(Template(r"tpl1549243983021.png", rgb=True, record_pos=(-0.003, 0.081), resolution=(1920, 1080)),"第%s轮游戏结束"%(i+1))
            
            if i!=self.num-1:
                dianji(Template(r"tpl1549243983021.png", rgb=True, record_pos=(-0.003, 0.081), resolution=(1920, 1080)))            
        start_time = time.time()
        while True:
            if exists(Template(r"tpl1549506672729.png", rgb=True, record_pos=(0.001, 0.08), resolution=(1920, 1080))):
                touch(Template(r"tpl1549244392208.png", rgb=True, record_pos=(-0.454, -0.224), resolution=(1920, 1080)))
                break
            elif exists(Template(r"tpl1549243983021.png", rgb=True, record_pos=(-0.003, 0.081), resolution=(1920, 1080))):
                touch(Template(r"tpl1549244392208.png", rgb=True, record_pos=(-0.454, -0.224), resolution=(1920, 1080)))
                break
            elif exists(Template(r"tpl1548826361895.png", rgb=True, record_pos=(0.357, -0.248), resolution=(1920, 1080))):
                break                
            else:
                if chaoshi(start_time) is False:
                    break
        pc_wait(Template(r"tpl1548826361895.png", rgb=True, record_pos=(0.357, -0.248), resolution=(1920, 1080)),"成功回到选场大厅")
    def more(self):  #语音
        sleep(1)
        touch(Template(r"tpl1550206467486.png", threshold=0.8, rgb=True, record_pos=(0.449, -0.22), resolution=(1920, 1080)))
        sleep(1)
        if exists(Template(r"tpl1550205953707.png", threshold=0.9, rgb=True, record_pos=(-0.258, -0.023), resolution=(1920, 1080))):
            touch(Template(r"tpl1550205364445.png", rgb=True, target_pos=9, record_pos=(-0.306, -0.109), resolution=(1920, 1080)))
            touch(Template(r"tpl1550205398007.png", rgb=True, target_pos=9, record_pos=(-0.31, -0.027), resolution=(1920, 1080)))
            
            bug_assert(Template(r"tpl1549443120748.png", rgb=True, record_pos=(-0.198, -0.02), resolution=(2280, 1080)),"成功取消音效","无法取消音效")                
        else:
            touch(Template(r"tpl1550205427271.png", rgb=True, target_pos=9, record_pos=(-0.305, -0.11), resolution=(1920, 1080)))
            touch(Template(r"tpl1550205447849.png", rgb=True, target_pos=9, record_pos=(-0.307, -0.029), resolution=(1920, 1080)))
            sleep(1)
            bug_assert(Template(r"tpl1550205953707.png", threshold=0.9, rgb=True, record_pos=(-0.258, -0.023), resolution=(1920, 1080)),"成功开启音效","无法开启音效")
        touch([60,600])
    @classmethod
    def exit(cls):  #退出
        start_time = time.time()
        while True:
            if exists(Template(r"tpl1549244376325.png", rgb=True, record_pos=(-0.001, 0.08), resolution=(1920, 1080))):
                touch(Template(r"tpl1549244392208.png", rgb=True, record_pos=(-0.454, -0.224), resolution=(1920, 1080)))
                break
            elif exists(Template(r"tpl1549243983021.png", rgb=True, record_pos=(-0.003, 0.081), resolution=(1920, 1080))):
                touch(Template(r"tpl1549244392208.png", rgb=True, record_pos=(-0.454, -0.224), resolution=(1920, 1080)))
                break
            elif exists(Template(r"tpl1548826361895.png", rgb=True, record_pos=(0.357, -0.248), resolution=(1920, 1080))):
                break                
            else:
                if chaoshi(start_time) is False:
                    break
        pc_wait(Template(r"tpl1548826361895.png", rgb=True, record_pos=(0.357, -0.248), resolution=(1920, 1080)),"成功回到选场大厅")
        sleep(2)
        touch(Template(r"tpl1549619413263.png", rgb=True, record_pos=(-0.458, -0.248), resolution=(1920, 1080))) # 回到游戏大厅
        pc_wait(leimu_P(cls.web)[0],"成功回到游戏大厅")
        sleep(5)
    @classmethod
    def record(cls):  #游戏记录
        touch(Template(r"tpl1549244630934.png", rgb=True, record_pos=(0.299, -0.246), resolution=(1920, 1080)))
        sleep(2)
        if exists(Template(r"tpl1549437671238.png", rgb=True, record_pos=(-0.001, 0.007), resolution=(1920, 1080))):
            print("暂无游戏记录")
        else:
            bug_assert(Template(r"tpl1549192039334.png", rgb=True, record_pos=(-0.006, -0.153), resolution=(1920, 1080)),"成功打开游戏记录","无法打开游戏记录")
            touch(Template(r"tpl1550563845470.png", rgb=True, record_pos=(0.332, -0.115), resolution=(1920, 1080)))   #点击详情
            sleep(2)
            bug_assert(Template(r"tpl1549244846923.png", rgb=True, record_pos=(-0.002, -0.215), resolution=(1920, 1080)),"成功打开详情页","无法打开详情页")
            touch(Template(r"tpl1550563985153.png", rgb=True, record_pos=(0.381, -0.212), resolution=(1920, 1080)))
            sleep(1)
        touch(Template(r"tpl1550563966553.png", rgb=True, record_pos=(0.382, -0.213), resolution=(1920, 1080)))
        sleep(1)
    def test_tiyan(self):
        if not exists(Template(r"tpl1549006775927.png", record_pos=(0.357, -0.249), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("体验房")
        if result:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("体验房"))
    def test_chuji(self):
        if not exists(Template(r"tpl1549006775927.png", record_pos=(0.357, -0.249), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.kaiwan()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))
    def test_zhongji(self):
        if not exists(Template(r"tpl1549006775927.png", record_pos=(0.357, -0.249), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))        
    def test_gaoji(self):
        if not exists(Template(r"tpl1549006775927.png", record_pos=(0.357, -0.249), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))
    def test_fuhao(self):
        if not exists(Template(r"tpl1549006775927.png", record_pos=(0.357, -0.249), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("富豪房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("富豪房"))

class Game_qiangzhuangpaijiu(unittest.TestCase):
    """抢庄牌九"""
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.num = number[2]  # 玩游戏的局数
        cls.web = globalVar.get_web()
        cls.name = {"体验房":Template(r"tpl1551421210902.png", rgb=True, record_pos=(-0.164, -0.028), resolution=(1920, 1080)),"初级房":Template(r"tpl1551421233612.png", rgb=True, record_pos=(0.084, -0.029), resolution=(1920, 1080)),"中级房":Template(r"tpl1551421285924.png", rgb=True, record_pos=(0.338, -0.029), resolution=(1920, 1080)),"高级房":Template(r"tpl1551421307179.png", rgb=True, record_pos=(-0.181, 0.188), resolution=(1920, 1080)),"富豪房":Template(r"tpl1551421323680.png", rgb=True, record_pos=(0.091, 0.188), resolution=(1920, 1080))}

        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
    @classmethod
    def ingame(cls): #进入游戏
        list1 = leimu_P(cls.web)[0]
        list2 = dating(cls.web,"Game_qiangzhuangpaijiu")
        result = in_youxi(list1,list2)
        if result is True:
            return pc_wait(Template(r"tpl1549102930246.png", rgb=True, record_pos=(0.335, -0.242), resolution=(1920, 1080)),"***成功进入抢庄牌九***")
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:            
            raise TargetNotFoundError("进入游戏失败")
    def inroom(self,name): #进入游戏房间
        pc_wait(Template(r"tpl1549102930246.png", rgb=True, record_pos=(0.335, -0.242), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        touch(self.name[name])
        sleep(2)
        result = pc_pd(Template(r"tpl1550638755228.png", record_pos=(0.122, 0.078), resolution=(1920, 1080)), "进入%s金额不足提示充值"%name)
        if result is True:    
            touch(Template(r"tpl1550638755228.png", record_pos=(0.122, 0.078), resolution=(1920, 1080)))                        
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])
            return 1
        else:   
            return pc_wait(Template(r"tpl1549105021789.png", rgb=True, record_pos=(0.086, 0.173), resolution=(1920, 1080)),"成功进入抢庄牌九%s"%name,30)     
    def kaiwan(self): #玩游戏 
        touch(Template(r"tpl1549105021789.png", rgb=True, record_pos=(0.086, 0.173), resolution=(1920, 1080)))
        for i in range(self.num):
            try:
                pc_wait(Template(r"tpl1551855165477.png", rgb=True, record_pos=(-0.286, 0.052), resolution=(1920, 1080)),"第一轮匹配到玩家",35)
                if exists(Template(r"tpl1551855211710.png", rgb=True, target_pos=6, record_pos=(-0.097, 0.053), resolution=(1920, 1080))):
                    touch(Template(r"tpl1551855211710.png", rgb=True, target_pos=6, record_pos=(-0.097, 0.053), resolution=(1920, 1080)))
                sleep(6)
                if exists(Template(r"tpl1551855211710.png", rgb=True, target_pos=6, record_pos=(-0.097, 0.053), resolution=(1920, 1080))):
                    touch(Template(r"tpl1551855211710.png", rgb=True, target_pos=6, record_pos=(-0.097, 0.053), resolution=(1920, 1080)))
                sleep(8)
                pc_wait(Template(r"tpl1551855165477.png", rgb=True, record_pos=(-0.286, 0.052), resolution=(1920, 1080)),"第二轮匹配到玩家",30)
                if exists(Template(r"tpl1551855165477.png", rgb=True, record_pos=(-0.286, 0.052), resolution=(1920, 1080))):
                    touch(Template(r"tpl1551855165477.png", rgb=True, record_pos=(-0.286, 0.052), resolution=(1920, 1080)))
                sleep(6)
                if exists(Template(r"tpl1551855211710.png", rgb=True, target_pos=6, record_pos=(-0.097, 0.053), resolution=(1920, 1080))):
                    touch(Template(r"tpl1551855211710.png", rgb=True, target_pos=6, record_pos=(-0.097, 0.053), resolution=(1920, 1080)))
                sleep(8)
                pc_wait(Template(r"tpl1551857679931.png", rgb=True, record_pos=(0.17, 0.168), resolution=(1920, 1080)),"第%s局游戏结束"%(i+1),30)
            except TargetNotFoundError:
                assert_exists(Template(r"tpl1549418324437.png", rgb=True, record_pos=(0.0, 0.073), resolution=(1920, 1080)),"游戏提前結束")
                break
        start_time = time.time()
        while True:
            if exists(Template(r"tpl1548564539785.png", record_pos=(-0.175, 0.171), resolution=(1920, 1080))):
                touch(Template(r"tpl1548564539785.png", rgb=True, record_pos=(-0.175, 0.171), resolution=(1920, 1080)))
                break
            elif exists(Template(r"tpl1549418324437.png", rgb=True, record_pos=(0.0, 0.073), resolution=(1920, 1080))):
                touch(Template(r"tpl1549418581571.png", rgb=True, record_pos=(0.382, -0.214), resolution=(1920, 1080)))
                sleep(1)
                touch(Template(r"tpl1549269360207.png", rgb=True, record_pos=(-0.458, -0.238), resolution=(1920, 1080)))                    
                break
            elif exists(Template(r"tpl1549269326477.png", rgb=True, record_pos=(0.094, 0.198), resolution=(1920, 1080))):
                touch(Template(r"tpl1549269360207.png", rgb=True, record_pos=(-0.458, -0.238), resolution=(1920, 1080)))
                pc_wait(Template(r"tpl1549102930246.png", rgb=True, record_pos=(0.335, -0.242), resolution=(1920, 1080)),"成功回到选场大厅",30)
                break
            elif exists(Template(r"tpl1549102930246.png", rgb=True, record_pos=(0.335, -0.242), resolution=(1920, 1080))):
                break
            else:
                if chaoshi(start_time) is False:
                    break
        print(333333)
        pc_wait(Template(r"tpl1549102930246.png", rgb=True, record_pos=(0.335, -0.242), resolution=(1920, 1080)),"成功回到选场大厅",30)
    def more(self):  #语音
        touch(Template(r"tpl1549106079500.png", rgb=True, record_pos=(0.459, -0.241), resolution=(1920, 1080)))
        sleep(1)
        if exists(Template(r"tpl1550199693657.png", threshold=0.9, rgb=True, record_pos=(-0.289, -0.024), resolution=(1920, 1080))):
            
            touch(Template(r"tpl1550199720799.png", rgb=True, target_pos=9, record_pos=(-0.303, -0.106), resolution=(1920, 1080)))
            touch(Template(r"tpl1550199759788.png", rgb=True, target_pos=9, record_pos=(-0.308, -0.026), resolution=(1920, 1080)))
            bug_assert(Template(r"tpl1550199784633.png", threshold=0.9, rgb=True, record_pos=(-0.29, -0.022), resolution=(1920, 1080)),"成功取消音效","无法取消音效")                
        else:
            touch(Template(r"tpl1550199822809.png", rgb=True, target_pos=9, record_pos=(-0.306, -0.107), resolution=(1920, 1080)))

            touch(Template(r"tpl1550199759788.png", rgb=True, target_pos=9, record_pos=(-0.308, -0.026), resolution=(1920, 1080)))
            sleep(1)
            bug_assert(Template(r"tpl1549523212645.png", rgb=True, record_pos=(-0.258, -0.024), resolution=(1920, 1080)),"成功开启音效","无法开启音效")
        touch(Template(r"tpl1550199932293.png", rgb=True, target_pos=6, record_pos=(0.154, -0.209), resolution=(1920, 1080)))          
    @classmethod
    def record(cls):  #游戏记录
        touch(Template(r"tpl1549110011230.png", rgb=True, record_pos=(0.285, -0.231), resolution=(1920, 1080)))
        sleep(3)
        if exists(Template(r"tpl1549437671238.png", rgb=True, record_pos=(-0.001, 0.007), resolution=(1920, 1080))):
            print("暂无游戏记录")
        else:
            bug_assert(Template(r"tpl1549110041377.png", rgb=True, record_pos=(-0.004, -0.153), resolution=(1920, 1080)),"成功打开游戏记录","无法游戏记录")
            touch(Template(r"tpl1549698044161.png", rgb=True, record_pos=(0.293, -0.1), resolution=(2160, 1080))) #点击详情
            sleep(2)
            bug_assert(Template(r"tpl1549110451899.png", rgb=True, record_pos=(-0.005, -0.211), resolution=(1920, 1080)),"成功打开游戏记录详情页","无法打开游戏记录详情页")
            touch(Template(r"tpl1549111531265.png", rgb=True, record_pos=(0.38, -0.213), resolution=(1920, 1080)))
        sleep(2)
        touch(Template(r"tpl1549111565653.png", rgb=True, record_pos=(0.385, -0.213), resolution=(1920, 1080)))
        sleep(1)             
    @classmethod
    def exit(cls):  #退出
        start_time = time.time()
        while True:
            if exists(Template(r"tpl1548564539785.png", record_pos=(-0.175, 0.171), resolution=(1920, 1080))):
                touch(Template(r"tpl1548564539785.png", rgb=True, record_pos=(-0.175, 0.171), resolution=(1920, 1080)))
                pc_wait(Template(r"tpl1549102930246.png", rgb=True, record_pos=(0.335, -0.242), resolution=(1920, 1080)),"成功回到选场大厅")
                break
            elif exists(Template(r"tpl1549418324437.png", rgb=True, record_pos=(0.0, 0.073), resolution=(1920, 1080))):

                touch(Template(r"tpl1549418581571.png", rgb=True, record_pos=(0.382, -0.214), resolution=(1920, 1080)))
                touch(Template(r"tpl1549269360207.png", rgb=True, record_pos=(-0.458, -0.238), resolution=(1920, 1080)))
                pc_wait(Template(r"tpl1549102930246.png", rgb=True, record_pos=(0.335, -0.242), resolution=(1920, 1080)),"成功回到选场大厅")
                break
            elif exists(Template(r"tpl1549269326477.png", rgb=True, record_pos=(0.094, 0.198), resolution=(1920, 1080))):
                touch(Template(r"tpl1549269360207.png", rgb=True, record_pos=(-0.458, -0.238), resolution=(1920, 1080)))
                pc_wait(Template(r"tpl1549102930246.png", rgb=True, record_pos=(0.335, -0.242), resolution=(1920, 1080)),"成功回到选场大厅")
                break
            elif exists(Template(r"tpl1549418936168.png", rgb=True, record_pos=(-0.467, -0.242), resolution=(1920, 1080))):
                break
            elif exists(Template(r"tpl1549102930246.png", rgb=True, record_pos=(0.335, -0.242), resolution=(1920, 1080))):
                break
            else:
                if chaoshi(start_time) is False:
                    break
        touch(Template(r"tpl1549619691535.png", rgb=True, record_pos=(-0.469, -0.243), resolution=(1920, 1080)))
        pc_wait(leimu_P(cls.web)[0],"成功回到游戏大厅")
        sleep(5)
    def test_tiyan(self):
        if not exists(Template(r"tpl1549102930246.png", rgb=True, record_pos=(0.335, -0.242), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("体验房")
        if result:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("体验房"))
    def test_chuji(self):
        if not exists(Template(r"tpl1549102930246.png", rgb=True, record_pos=(0.335, -0.242), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.kaiwan()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))
    def test_zhongji(self):
        if not exists(Template(r"tpl1549102930246.png", rgb=True, record_pos=(0.335, -0.242), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))        
    def test_gaoji(self):
        if not exists(Template(r"tpl1549102930246.png", rgb=True, record_pos=(0.335, -0.242), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))
    def test_fuhao(self):
        if not exists(Template(r"tpl1549102930246.png", rgb=True, record_pos=(0.335, -0.242), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("富豪房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("富豪房"))

class Game_texasholdem(unittest.TestCase):
    """德州扑克"""
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.num = number[0]  # 玩游戏的局数 
        cls.web = globalVar.get_web()
        cls.name = {"体验房":Template(r"tpl1550131240097.png", rgb=True, record_pos=(-0.082, -0.022), resolution=(1920, 1080)),"初级房":Template(r"tpl1550131296465.png", rgb=True, record_pos=(0.138, -0.02), resolution=(1920, 1080)),"中级房":Template(r"tpl1550131324195.png", rgb=True, record_pos=(0.369, -0.024), resolution=(1920, 1080)),"高级房":Template(r"tpl1550022314770.png", rgb=True, record_pos=(-0.044, 0.206), resolution=(1920, 1080)),"富豪房":Template(r"tpl1550140973480.png", rgb=True, record_pos=(0.136, 0.202), resolution=(1920, 1080))}

        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
    @classmethod
    def ingame(cls):
        wait(leimu_P(cls.web)[0])
        list1 = leimu_P(cls.web)[0]
        list2 = dating(cls.web,"Game_texasholdem")
        result = in_youxi(list1,list2)
        if result is True:         
            return pc_wait(Template(r"tpl1550131965332.png", rgb=True, record_pos=(0.172, -0.251), resolution=(1920, 1080)),"***成功进入德州扑克***")
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:
            raise TargetNotFoundError("进入游戏失败")
    def inroom(self,name):
        pc_wait(Template(r"tpl1550131965332.png", rgb=True, record_pos=(0.172, -0.251), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        touch(self.name[name])
        if name != '体验房':
            self.setup()
        else:
            pass
        result = pc_pd(Template(r"tpl1550810239330.png", rgb=True, record_pos=(0.121, 0.08), resolution=(1920, 1080)), "进%s金额不足有充值提示"%name)
        if result is True:
            touch(Template(r"tpl1550810239330.png", rgb=True, record_pos=(0.121, 0.08), resolution=(1920, 1080)))
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])           
            return 1
        else:
            return pc_wait(Template(r"tpl1550132510563.png", rgb=True, record_pos=(0.005, 0.248), resolution=(1920, 1080)),'进入德州扑克房间%s'%name,30)           
#         设置带入筹码
    def setup(self):
        wait(Template(r"tpl1549264862938.png", record_pos=(-0.138, -0.138), resolution=(2280, 1080)))
        touch(Template(r"tpl1550139130812.png", rgb=True, record_pos=(0.173, 0.056), resolution=(1920, 1080)))
        pc_wait(Template(r"tpl1549265106008.png", rgb=True, record_pos=(0.057, -0.014), resolution=(2280, 1080)),'最大金额按钮')
#         touch(coordinate([700,625]))
        touch(Template(r"tpl1550139245849.png", rgb=True, target_pos=3, record_pos=(-0.333, 0.082), resolution=(1920, 1080)))
        pc_wait(Template(r"tpl1549265199244.png", record_pos=(0.046, -0.026), resolution=(2280, 1080)),'最小金额按钮')
#         touch(coordinate([1520,625]))
        if exists(Template(r"tpl1549265360124.png", rgb=True, record_pos=(-0.033, 0.091), resolution=(2280, 1080))):
            touch(Template(r"tpl1549265360124.png", rgb=True, record_pos=(-0.033, 0.091), resolution=(2280, 1080)))
            pc_wait(Template(r"tpl1549265402136.png", rgb=True, record_pos=(-0.033, 0.088), resolution=(2280, 1080)),'自动买入金额设置')
        if exists(Template(r"tpl1549265402136.png", rgb=True, record_pos=(-0.033, 0.088), resolution=(2280, 1080))):
            touch(Template(r"tpl1549265402136.png", rgb=True, record_pos=(-0.033, 0.088), resolution=(2280, 1080)))
            pc_wait(Template(r"tpl1549265360124.png", rgb=True, record_pos=(-0.033, 0.091), resolution=(2280, 1080)),'自动买入金额设置')
        touch(Template(r"tpl1549265487416.png", rgb=True, record_pos=(0.227, 0.09), resolution=(2280, 1080)))
                               
#         主要辅助打牌的函数
    def myturn(self,button_picture):
        while True:
            if not exists(Template(r"tpl1549595224986.png", record_pos=(-0.006, -0.003), resolution=(2160, 1080))):
                if not exists(Template(r"tpl1549265684276.png", rgb=True, record_pos=(0.022, 0.208), resolution=(2280, 1080))):
                    touch(button_picture)
                    if not exists(Template(r"tpl1549265981039.png", record_pos=(0.001, -0.0), resolution=(2280, 1080))):
                        break
                else:
                    touch(Template(r"tpl1549265684276.png", rgb=True, record_pos=(0.022, 0.208), resolution=(2280, 1080)))
            sleep(5)               
#         下注    
    def pour(self):
#         第一局
        wait(Template(r"tpl1549265737978.png", record_pos=(0.012, -0.16), resolution=(2280, 1080)),60)                        
        self.myturn(Template(r"tpl1549266850470.png", record_pos=(-0.125, 0.205), resolution=(2280, 1080)))

#             第二局
        self.myturn(Template(r"tpl1549266395759.png", rgb=True, record_pos=(0.198, 0.205), resolution=(2280, 1080)))
        for x in range(10):#做个判断，是否结束游戏
            if exists(Template(r"tpl1549265684276.png", rgb=True, record_pos=(0.022, 0.208), resolution=(2280, 1080))):                    
                touch(Template(r"tpl1549267584417.png", record_pos=(-0.425, -0.193), resolution=(2280, 1080)))#返回选房大厅
                break
            else:
                if exists(Template(r"tpl1549266850470.png", record_pos=(-0.125, 0.205), resolution=(2280, 1080))):
                    touch(Template(r"tpl1549266850470.png", record_pos=(-0.125, 0.205), resolution=(2280, 1080)))
                sleep(5)
        pc_wait(Template(r"tpl1550131965332.png", rgb=True, record_pos=(0.172, -0.251), resolution=(1920, 1080)),"返回德州扑克选场大厅",30)
#           加注，有点难判断
#         self.myturn(Template(r"tpl1549265830946.png", rgb=True, record_pos=(0.035, 0.205), resolution=(2280, 1080)))
#         更多
    def more(self):
        touch(Template(r"tpl1549267400552.png", record_pos=(0.464, -0.2), resolution=(2280, 1080)))
        wait(Template(r"tpl1549267419612.png", record_pos=(0.023, -0.208), resolution=(2280, 1080)))
        if exists(Template(r"tpl1549596012789.png", rgb=True, record_pos=(-0.193, -0.054), resolution=(2160, 1080))):
            touch(Template(r"tpl1549595991251.png", rgb=True, record_pos=(-0.194, -0.082), resolution=(2160, 1080)))
            sleep(1)
            touch(Template(r"tpl1549595991251.png", rgb=True, record_pos=(-0.194, -0.082), resolution=(2160, 1080)))
            pc_wait(Template(r"tpl1549267462837.png", rgb=True, record_pos=(-0.164, -0.051), resolution=(2280, 1080)),'关音乐和音效')
        if exists(Template(r"tpl1549267462837.png", rgb=True, record_pos=(-0.164, -0.051), resolution=(2280, 1080))):
            touch(Template(r"tpl1549596065693.png", rgb=True, record_pos=(-0.194, -0.081), resolution=(2160, 1080)))
            sleep(1)
            touch(Template(r"tpl1549596065693.png", rgb=True, record_pos=(-0.194, -0.081), resolution=(2160, 1080)))
            pc_wait(Template(r"tpl1549596012789.png", rgb=True, record_pos=(-0.193, -0.054), resolution=(2160, 1080)),'开音乐和音效')
        touch(Template(r"tpl1549110931833.png", record_pos=(0.31, -0.175), resolution=(2280, 1080)))    
        sleep(3)
#         记录
    def record(self):
        
        wait(Template(r"tpl1549264728299.png", rgb=True, record_pos=(-0.282, -0.021), resolution=(2280, 1080)))    
        touch(Template(r"tpl1549179934150.png", record_pos=(0.236, -0.207), resolution=(2280, 1080)))
        pc_wait(Template(r"tpl1549866456508.png", rgb=True, record_pos=(0.001, -0.173), resolution=(1920, 1080)),'进入对局记录')
        touch(Template(r"tpl1549690195398.png", threshold=0.9, record_pos=(0.3, -0.096), resolution=(2160, 1080)))#点击详情
        sleep(1)
        if exists(Template(r"tpl1549267690469.png", rgb=True, record_pos=(0.365, -0.15), resolution=(2280, 1080))):
            touch(Template(r"tpl1549267690469.png", rgb=True, record_pos=(0.365, -0.15), resolution=(2280, 1080)))
        sleep(1)
        if exists(Template(r"tpl1549267690469.png", rgb=True, record_pos=(0.365, -0.15), resolution=(2280, 1080))):
            touch(Template(r"tpl1549267690469.png", rgb=True, record_pos=(0.365, -0.15), resolution=(2280, 1080)))
#          退出
    @classmethod
    def exit(cls):
        if not exists(Template(r"tpl1549264728299.png", rgb=True, record_pos=(-0.282, -0.021), resolution=(2280, 1080))):
            for x in range(10):#做个判断，是否结束游戏
                if exists(Template(r"tpl1549265684276.png", rgb=True, record_pos=(0.022, 0.208), resolution=(2280, 1080))):                    
                    touch(Template(r"tpl1549267584417.png", record_pos=(-0.425, -0.193), resolution=(2280, 1080)))#返回选房大厅
                    break
                else:
                    if exists(Template(r"tpl1549266850470.png", record_pos=(-0.125, 0.205), resolution=(2280, 1080))):
                        touch(Template(r"tpl1549266850470.png", record_pos=(-0.125, 0.205), resolution=(2280, 1080)))
        touch(Template(r"tpl1550141018077.png", rgb=True, record_pos=(-0.465, -0.248), resolution=(1920, 1080)))
        pc_wait(leimu_P(cls.web)[0],'德州扑克退回游戏大厅',30)     
    def test_chuji(self):
        if not exists(Template(r"tpl1550131965332.png", rgb=True, record_pos=(0.172, -0.251), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.more()
            self.pour()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))                
    def test_zhongji(self):
        if not exists(Template(r"tpl1550131965332.png", rgb=True, record_pos=(0.172, -0.251), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))
    def test_gaoji(self):
        if not exists(Template(r"tpl1550131965332.png", rgb=True, record_pos=(0.172, -0.251), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))
    def test_fuhao(self):
        if not exists(Template(r"tpl1550131965332.png", rgb=True, record_pos=(0.172, -0.251), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("富豪房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("富豪房"))
    def test_tiyan(self):
        if not exists(Template(r"tpl1550131965332.png", rgb=True, record_pos=(0.172, -0.251), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("体验房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("体验房"))

class Game_FriedGoldenFlower(unittest.TestCase):
    """炸金花"""
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.num = number[0]  # 玩游戏的局数 
        cls.web = globalVar.get_web()
        cls.name = {"体验房":Template(r"tpl1550131240097.png", rgb=True, record_pos=(-0.082, -0.022), resolution=(1920, 1080)),"初级房":Template(r"tpl1550131296465.png", rgb=True, record_pos=(0.138, -0.02), resolution=(1920, 1080)),"中级房":Template(r"tpl1550131324195.png", rgb=True, record_pos=(0.369, -0.024), resolution=(1920, 1080)),"高级房":Template(r"tpl1550022314770.png", rgb=True, record_pos=(-0.044, 0.206), resolution=(1920, 1080)),"富豪房":Template(r"tpl1550022349353.png", rgb=True, record_pos=(0.161, 0.205), resolution=(1920, 1080))}
        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
    @classmethod
    def ingame(cls):
        wait(leimu_P(cls.web)[0])
        list1 = leimu_P(cls.web)[0]
        list2 = dating(cls.web,"Game_FriedGoldenFlower")
        result = in_youxi(list1,list2)
        if result is True:
            return pc_wait(Template(r"tpl1550806079627.png", rgb=True, record_pos=(0.167, -0.248), resolution=(1920, 1080)),"***成功进入炸金花***",30)
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:
            raise TargetNotFoundError("进入游戏失败")          
    # 进入房间
    def inroom(self,name):
        pc_wait(Template(r"tpl1550806079627.png", rgb=True, record_pos=(0.167, -0.248), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        touch(self.name[name])#进入初级房
        sleep(2)
        result = pc_pd(Template(r"tpl1550806007236.png", rgb=True, record_pos=(0.12, 0.08), resolution=(1920, 1080)), "进%s金额不足有充值提示"%name)
        if result is True:
            touch(Template(r"tpl1550806007236.png", rgb=True, record_pos=(0.12, 0.08), resolution=(1920, 1080)))
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])           
            return 1
        else:
            return pc_wait(Template(r"tpl1550133097383.png", rgb=True, record_pos=(0.455, -0.244), resolution=(1920, 1080)),'进入炸金花%s'%name,30)
#         判断是否结束这一局，此函数主要用于辅助playCards函数    
    def judge(self):
        sleep(5)
        if exists(Template(r"tpl1549248520668.png", rgb=True, record_pos=(-0.019, 0.185), resolution=(2280, 1080))):                
            touch(Template(r"tpl1549248520668.png", rgb=True, record_pos=(-0.019, 0.185), resolution=(2280, 1080)))
            pc_wait(Template(r"tpl1549248561944.png", rgb=True, record_pos=(-0.334, 0.181), resolution=(2280, 1080)),"匹配到玩家",40)
            return True
        else:
            return False
#         打牌    
    def playCards(self):
        wait(Template(r"tpl1549244581573.png", rgb=True, record_pos=(0.022, -0.154), resolution=(2280, 1080)))
        result = self.judge()            
        touch(Template(r"tpl1549248561944.png", rgb=True, record_pos=(-0.334, 0.181), resolution=(2280, 1080)))
        wait(Template(r"tpl1549245058038.png", rgb=True, record_pos=(0.074, 0.086), resolution=(2280, 1080)))
        touch(Template(r"tpl1549245058038.png", rgb=True, record_pos=(0.074, 0.086), resolution=(2280, 1080)))

        if not result:
            touch(Template(r"tpl1549248478337.png", rgb=True, record_pos=(-0.204, 0.182), resolution=(2280, 1080)))
        for x in range(10):#做个判断，是否结束游戏
            if exists(Template(r"tpl1549248520668.png", rgb=True, record_pos=(-0.019, 0.185), resolution=(2280, 1080))):                    
                touch(Template(r"tpl1549249155468.png", record_pos=(-0.429, -0.204), resolution=(2280, 1080)))#返回选房大厅
                break
            else:
                if exists(Template(r"tpl1549248478337.png", rgb=True, record_pos=(-0.204, 0.182), resolution=(2280, 1080))):
                    touch(Template(r"tpl1549248478337.png", rgb=True, record_pos=(-0.204, 0.182), resolution=(2280, 1080)))
                sleep(5)
        pc_wait(Template(r"tpl1550806079627.png", rgb=True, record_pos=(0.167, -0.248), resolution=(1920, 1080)),"返回炸金花选场大厅")      
#         上庄
    def beBanker(self):
        pass
#         更多
    def more(self):
        touch(Template(r"tpl1549249026873.png", record_pos=(0.395, -0.206), resolution=(2280, 1080)))

        wait(Template(r"tpl1549249052909.png", record_pos=(-0.016, -0.182), resolution=(2280, 1080)))

        if exists(Template(r"tpl1549442986964.png", record_pos=(-0.198, -0.018), resolution=(2280, 1080))):
            touch(Template(r"tpl1549523248168.png", rgb=True, record_pos=(-0.258, -0.056), resolution=(1920, 1080)))
            sleep(1)
            touch(Template(r"tpl1549523268490.png", rgb=True, record_pos=(-0.258, 0.008), resolution=(1920, 1080)))

            bug_assert(Template(r"tpl1549443120748.png", record_pos=(-0.198, -0.02), resolution=(2280, 1080)),'关音乐和音效','无法关闭音乐和音效')
        if exists(Template(r"tpl1549443120748.png", record_pos=(-0.198, -0.02), resolution=(2280, 1080))):
            touch(Template(r"tpl1549523350713.png", rgb=True, record_pos=(-0.258, -0.057), resolution=(1920, 1080)))
            sleep(1)
            touch(Template(r"tpl1549523350713.png", rgb=True, record_pos=(-0.258, -0.057), resolution=(1920, 1080)))

            bug_assert(Template(r"tpl1549442986964.png", record_pos=(-0.198, -0.018), resolution=(2280, 1080)),'开音乐和音效','开音乐和音效失败')
        touch(Template(r"tpl1549110931833.png", record_pos=(0.31, -0.175), resolution=(2280, 1080)))    
        sleep(3)
#         记录
    def record(self):
        
        wait(Template(r"tpl1549244500566.png", rgb=True, record_pos=(-0.242, -0.054), resolution=(2280, 1080)))    
        touch(Template(r"tpl1549179934150.png", record_pos=(0.236, -0.207), resolution=(2280, 1080)))
        sleep(1)
        if exists(Template(r"tpl1550806156121.png", rgb=True, record_pos=(-0.002, -0.109), resolution=(1920, 1080))):
            print("无游戏记录")
        else:
            assert_exists(Template(r"tpl1550810058140.png", rgb=True, record_pos=(0.331, -0.134), resolution=(1920, 1080)), "成功打开游戏记录")       
            touch(Template(r"tpl1549865364810.png", rgb=True, record_pos=(0.334, -0.111), resolution=(1920, 1080)))#点击详情
            pc_wait(Template(r"tpl1549866167622.png", rgb=True, record_pos=(-0.149, -0.186), resolution=(1920, 1080)), "进入记录详情")
            if exists(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080))):
                touch(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080)))
        sleep(1)
        if exists(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080))):
            touch(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080)))     
    @classmethod
    def exit(cls):
        start_time = time.time()
        while True:
            if exists(Template(r"tpl1551752199479.png", rgb=True, record_pos=(-0.01, 0.192), resolution=(2160, 1080))):
                touch(Template(r"tpl1551752216470.png", rgb=True, record_pos=(-0.401, -0.218), resolution=(2160, 1080)))
                break
            elif exists(Template(r"tpl1551752243912.png", rgb=True, record_pos=(-0.18, 0.19), resolution=(2160, 1080))):
                touch(Template(r"tpl1551752243912.png", rgb=True, record_pos=(-0.18, 0.19), resolution=(2160, 1080)))
                sleep(1)
                touch(Template(r"tpl1551752216470.png", rgb=True, record_pos=(-0.401, -0.218), resolution=(2160, 1080)))
                break
            elif exists(Template(r"tpl1548826361895.png", rgb=True, record_pos=(0.357, -0.248), resolution=(1920, 1080))):
                break                
            else:
                if chaoshi(start_time) is False:
                    break
        pc_wait(Template(r"tpl1548826361895.png", rgb=True, record_pos=(0.357, -0.248), resolution=(1920, 1080)),"成功回到选场大厅")
        sleep(2)
        touch(Template(r"tpl1549180040853.png", record_pos=(-0.441, -0.206), resolution=(2280, 1080)))
        pc_wait(leimu_P(cls.web)[0],'退回游戏大厅')
    def test_chuji(self):
        if not exists(Template(r"tpl1550806079627.png", rgb=True, record_pos=(0.167, -0.248), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.more()
            self.playCards()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))                
    def test_zhongji(self):
        if not exists(Template(r"tpl1550806079627.png", rgb=True, record_pos=(0.167, -0.248), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.playCards()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))
    def test_gaoji(self):
        if not exists(Template(r"tpl1550806079627.png", rgb=True, record_pos=(0.167, -0.248), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.playCards()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))
    def test_fuhao(self):
        if not exists(Template(r"tpl1550806079627.png", rgb=True, record_pos=(0.167, -0.248), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("富豪房")
        if result is True:
            self.playCards()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("富豪房"))
    def test_tiyan(self):
        if not exists(Template(r"tpl1550806079627.png", rgb=True, record_pos=(0.167, -0.248), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("体验房")
        if result is True:
            self.playCards()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("体验房"))
            
class Game_landlord(unittest.TestCase):
    """斗地主"""
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.num = number[0]  # 玩游戏的局数 
        cls.web = globalVar.get_web()
        cls.name = {"体验房":Template(r"tpl1550131240097.png", rgb=True, record_pos=(-0.082, -0.022), resolution=(1920, 1080)),"初级房":Template(r"tpl1550131296465.png", rgb=True, record_pos=(0.138, -0.02), resolution=(1920, 1080)),"中级房":Template(r"tpl1550131324195.png", rgb=True, record_pos=(0.369, -0.024), resolution=(1920, 1080)),"高级房":Template(r"tpl1550022314770.png", rgb=True, record_pos=(-0.044, 0.206), resolution=(1920, 1080)),"富豪房":Template(r"tpl1550022349353.png", rgb=True, record_pos=(0.161, 0.205), resolution=(1920, 1080))}

        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
    @classmethod
    def ingame(cls):
        wait(leimu_P(cls.web)[2])
        list1 = leimu_P(cls.web)[0]
        list2 = dating(cls.web,"Game_landlord")
        result = in_youxi(list1,list2)
        if result is True:
            return pc_wait(Template(r"tpl1550810604561.png", rgb=True, record_pos=(0.204, -0.247), resolution=(1920, 1080)),"***成功进入斗地主***")
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:
            raise TargetNotFoundError("进入游戏失败")  
    def inroom(self,name): 
        pc_wait(Template(r"tpl1550810604561.png", rgb=True, record_pos=(0.204, -0.247), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        touch(self.name[name])#进入初级房
        sleep(2)
        result = pc_pd(Template(r"tpl1550810628678.png", rgb=True, record_pos=(0.118, 0.078), resolution=(1920, 1080)), "进%s金额不足有充值提示"%name)
        if result is True:
            touch(Template(r"tpl1550810628678.png", rgb=True, record_pos=(0.118, 0.078), resolution=(1920, 1080)))
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])           
            return 1
        else:
            return pc_wait(Template(r"tpl1549261388689.png", rgb=True, record_pos=(0.393, -0.207), resolution=(2280, 1080)),'进入斗地主%s'%name,30)        
#         打牌    
    def playCards(self): 
#             第一局
        while True:
            wait(Template(r"tpl1549263527665.png", rgb=True, record_pos=(0.014, 0.019), resolution=(2280, 1080)),60)
            touch(Template(r"tpl1549263527665.png", rgb=True, record_pos=(0.014, 0.019), resolution=(2280, 1080)))
            for i in range(3):
                if exists(Template(r"tpl1549259667463.png", rgb=True, record_pos=(-0.179, 0.019), resolution=(2280, 1080))):
                    touch(Template(r"tpl1549259667463.png", rgb=True, record_pos=(-0.179, 0.019), resolution=(2280, 1080)))
                    break
                    sleep(2)
            sleep(1)
            if not exists(Template(r"tpl1549263527665.png", rgb=True, record_pos=(0.014, 0.019), resolution=(2280, 1080))):
                break                    
#         wait(Template(r"tpl1549260226245.png", rgb=True, record_pos=(-0.061, 0.019), resolution=(2280, 1080)))
#         touch(Template(r"tpl1549260226245.png", rgb=True, record_pos=(-0.061, 0.019), resolution=(2280, 1080)))
#         dianji(Template(r"tpl1549259711504.png", rgb=True, record_pos=(-0.16, 0.019), resolution=(2280, 1080)),40)
#         touch(Template(r"tpl1549259711504.png", rgb=True, record_pos=(-0.16, 0.019), resolution=(2280, 1080)))
#         wait(Template(r"tpl1549263465666.png", rgb=True, record_pos=(0.018, 0.166), resolution=(2280, 1080)),50)
#         touch(Template(r"tpl1549263465666.png", rgb=True, record_pos=(0.018, 0.166), resolution=(2280, 1080)))
        sleep(1)
        
#         bug_assert(Template(r"tpl1549261573014.png", rgb=True, record_pos=(0.32, -0.204), resolution=(2280, 1080)),'托管按钮')
        wait(Template(r"tpl1549259815855.png", rgb=True, record_pos=(-0.079, 0.141), resolution=(2280, 1080)),400)
        touch(Template(r"tpl1549259815855.png", rgb=True, record_pos=(-0.079, 0.141), resolution=(2280, 1080)))
        sleep(1)
        touch(Template(r"tpl1549259854490.png", rgb=True, record_pos=(-0.063, 0.023), resolution=(2280, 1080)))
        sleep(1)



#             第二局
        touch(Template(r"tpl1549259878733.png", rgb=True, record_pos=(0.121, 0.14), resolution=(2280, 1080)))
#         dianji(Template(r"tpl1549260046724.png", rgb=True, record_pos=(0.214, 0.019), resolution=(2280, 1080)),20)
#         wait(Template(r"tpl1549260222086.png", rgb=True, record_pos=(0.098, 0.017), resolution=(2280, 1080)))
#         touch(Template(r"tpl1549260222086.png", rgb=True, record_pos=(0.098, 0.017), resolution=(2280, 1080)))
        while True:
            if exists(Template(r"tpl1549259940537.png", rgb=True, record_pos=(0.019, 0.019), resolution=(2280, 1080))):
                touch(Template(r"tpl1549259940537.png", rgb=True, record_pos=(0.019, 0.019), resolution=(2280, 1080)))
                break
            elif exists(Template(r"tpl1549259958429.png", rgb=True, record_pos=(0.018, 0.019), resolution=(2280, 1080))):
                touch(Template(r"tpl1549259958429.png", rgb=True, record_pos=(0.018, 0.019), resolution=(2280, 1080)))
                sleep(1)
                touch(Template(r"tpl1549260533837.png", rgb=True, record_pos=(0.2, 0.017), resolution=(2280, 1080)))
                break
            elif exists(Template(r"tpl1549259815855.png", rgb=True, record_pos=(-0.079, 0.141), resolution=(2280, 1080))):
                break
            else:
                pass
        wait(Template(r"tpl1549259815855.png", rgb=True, record_pos=(-0.079, 0.141), resolution=(2280, 1080)),500)
        touch(Template(r"tpl1549261681537.png", record_pos=(-0.359, -0.207), resolution=(2280, 1080)))#返回选房大厅
        wait(Template(r"tpl1549259241733.png", rgb=True, record_pos=(-0.277, -0.036), resolution=(2280, 1080))) 
           
#         更多
    def more(self):
        touch(Template(r"tpl1549261388689.png", record_pos=(0.393, -0.207), resolution=(2280, 1080)))
        wait(Template(r"tpl1549261409036.png", record_pos=(0.025, -0.18), resolution=(2280, 1080)))
        if exists(Template(r"tpl1549442986964.png", record_pos=(-0.198, -0.018), resolution=(2280, 1080))):
            touch(Template(r"tpl1549523248168.png", rgb=True, record_pos=(-0.258, -0.056), resolution=(1920, 1080)))
            sleep(1)
            touch(Template(r"tpl1549523268490.png", rgb=True, record_pos=(-0.258, 0.008), resolution=(1920, 1080)))

            pc_wait(Template(r"tpl1549443120748.png", record_pos=(-0.198, -0.02), resolution=(2280, 1080)),'关音乐和音效')
        if exists(Template(r"tpl1549443120748.png", record_pos=(-0.198, -0.02), resolution=(2280, 1080))):
            touch(Template(r"tpl1549523350713.png", rgb=True, record_pos=(-0.258, -0.057), resolution=(1920, 1080)))
            sleep(1)
            touch(Template(r"tpl1549523350713.png", rgb=True, record_pos=(-0.258, -0.057), resolution=(1920, 1080)))

            pc_wait(Template(r"tpl1549442986964.png", record_pos=(-0.198, -0.018), resolution=(2280, 1080)),'开音乐和音效')
        touch(Template(r"tpl1549110931833.png", record_pos=(0.31, -0.175), resolution=(2280, 1080)))    
        sleep(3)

#         记录
    def record(self):
        wait(Template(r"tpl1549259241733.png", rgb=True, record_pos=(-0.277, -0.036), resolution=(2280, 1080)))    
        touch(Template(r"tpl1549261732687.png", record_pos=(0.277, -0.205), resolution=(2280, 1080)))
        pc_wait(Template(r"tpl1549865133113.png", rgb=True, record_pos=(-0.024, -0.186), resolution=(1920, 1080)),'进入对局记录')
        touch(Template(r"tpl1549865364810.png", rgb=True, record_pos=(0.334, -0.111), resolution=(1920, 1080)))#点击详情
        pc_wait(Template(r"tpl1549866167622.png", rgb=True, record_pos=(-0.149, -0.186), resolution=(1920, 1080)), "进入记录详情")

        if exists(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080))):
            touch(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080)))       
        if exists(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080))):
            touch(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080)))     

#         退出
    @classmethod
    def exit(cls):
        if not exists(Template(r"tpl1549259241733.png", rgb=True, record_pos=(-0.277, -0.036), resolution=(2280, 1080))):
            wait(Template(r"tpl1549259815855.png", rgb=True, record_pos=(-0.079, 0.141), resolution=(2280, 1080)),500)
            touch(Template(r"tpl1549261681537.png", record_pos=(-0.359, -0.207), resolution=(2280, 1080)))#返回选房大厅
        sleep(5)
        touch(Template(r"tpl1549180040853.png", record_pos=(-0.441, -0.206), resolution=(2280, 1080)))
        pc_wait(leimu_P(cls.web)[2],'斗地主退回游戏大厅')

    def test_tiyan(self):
        if not exists(Template(r"tpl1550810604561.png", rgb=True, record_pos=(0.204, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("体验房")
        if result:
            self.playCards()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("体验房"))
    def test_chuji(self):
        if not exists(Template(r"tpl1550810604561.png", rgb=True, record_pos=(0.204, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.playCards()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))
    def test_zhongji(self):
        if not exists(Template(r"tpl1550810604561.png", rgb=True, record_pos=(0.204, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.playCards()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))        
    def test_gaoji(self):
        if not exists(Template(r"tpl1550810604561.png", rgb=True, record_pos=(0.204, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.playCards()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))
    def test_fuhao(self):
        if not exists(Template(r"tpl1550810604561.png", rgb=True, record_pos=(0.204, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("富豪房")
        if result is True:
            self.playCards()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("富豪房"))






