# -*- encoding=utf8 -*-
__author__ = "panda"

import time,os,unittest,HTMLTestRunner
from airtest.core.api import *


path = os.path.abspath('..\..')
print(path)
using(path+'\common\settings.air')
from settings import *

using(path+'\common\games_picture.air')
from games_picture import *

using(path+'\games\config.air')
from config import *


"""
游戏局数
number[2] 代表抢庄牌九游戏局数
number[1] 代表二八杠游戏局数
number[0] 代表其他游戏局数
"""
number = [1,1,1]

class Game_goldcarp(unittest.TestCase):
    """金蟾捕鱼"""
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.web = globalVar.get_web()
        cls.name = {"体验房":Template(r"tpl1550124419774.png", rgb=True, record_pos=(-0.245, 0.077), resolution=(1920, 1080)),"初级房":Template(r"tpl1550124442111.png", rgb=True, record_pos=(-0.023, 0.078), resolution=(1920, 1080)),"中级房":Template(r"tpl1550124460821.png", rgb=True, record_pos=(0.217, 0.077), resolution=(1920, 1080)),"高级房":Template(r"tpl1550124490610.png", rgb=True, record_pos=(-0.062, 0.077), resolution=(1920, 1080)),"富豪房":Template(r"tpl1550124548075.png", rgb=True, record_pos=(0.193, 0.079), resolution=(1920, 1080))}

        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
    @classmethod
    def ingame(cls):
        wait(leimu_P(cls.web)[2])
        list1 = leimu_P(cls.web)[2]
        list2 = dating(cls.web,"Game_goldcarp")
        result = in_youxi(list1,list2)
        if result is True:
            return pc_wait(Template(r"tpl1550124910143.png", rgb=True, record_pos=(0.259, -0.247), resolution=(1920, 1080)),"***成功进入金蟾捕鱼***")
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:
            raise TargetNotFoundError("进入游戏失败")
    def inroom(self,name):
        pc_wait(Template(r"tpl1550124910143.png", rgb=True, record_pos=(0.259, -0.247), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        if name == "高级房":
            swipe([1500,800],[400,800])  #划屏操作
            sleep(1)
            touch(self.name[name])
        else:
            swipe([400,800],[1500,800])  #划屏操作
            sleep(1)
            touch(self.name[name])
        sleep(1)
        result = pc_pd(Template(r"tpl1550805756952.png", rgb=True, record_pos=(0.147, 0.08), resolution=(1920, 1080)), "进入%s金额不足有充值提示"%name)    
        if result is True:
            touch(Template(r"tpl1550805756952.png", rgb=True, record_pos=(0.147, 0.08), resolution=(1920, 1080)))
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])
            return 1
        else:
            return pc_wait(Template(r"tpl1549537964798.png", rgb=True, record_pos=(0.416, 0.107), resolution=(2280, 1080)),'进入金蟾捕鱼%s'%name,30)
#         打鱼
    def fishing(self):
        for x in range(10):
            touch(Template(r"tpl1549191138252.png", record_pos=(0.225, 0.212), resolution=(2280, 1080)))
            sleep(0.2)
        touch(Template(r"tpl1551523978069.png", rgb=True, record_pos=(0.414, -0.098), resolution=(1920, 1080)))
        touch(Template(r"tpl1551524382031.png", rgb=True, record_pos=(0.411, 0.117), resolution=(1920, 1080)))
        for x in range(10):
            touch(Template(r"tpl1550198478768.png", threshold=0.9, rgb=True, record_pos=(0.071, 0.256), resolution=(1920, 1080)))
            sleep(0.2)
        touch(Template(r"tpl1549191361811.png", record_pos=(-0.365, -0.202), resolution=(2280, 1080)))
        touch(Template(r"tpl1549192066471.png", record_pos=(-0.362, -0.121), resolution=(2280, 1080)))
        pc_wait(Template(r"tpl1550124910143.png", rgb=True, record_pos=(0.259, -0.247), resolution=(1920, 1080)),"回到选场大厅",30)
        sleep(3)
#         更多
    def more(self):
        touch(Template(r"tpl1549191361811.png", record_pos=(-0.365, -0.202), resolution=(2280, 1080)))
        touch(Template(r"tpl1549191383066.png", record_pos=(-0.365, -0.045), resolution=(2280, 1080)))
        if exists(Template(r"tpl1549191421531.png", rgb=True, record_pos=(-0.203, -0.047), resolution=(2280, 1080))):
            touch(Template(r"tpl1550198331179.png", rgb=True, target_pos=3, record_pos=(-0.295, -0.081), resolution=(1920, 1080)))
            touch(Template(r"tpl1550198331179.png", rgb=True, target_pos=9, record_pos=(-0.295, -0.081), resolution=(1920, 1080)))
            pc_wait(Template(r"tpl1549191524436.png", rgb=True, record_pos=(-0.206, -0.046), resolution=(2280, 1080)),'关闭音效和音乐')

        if exists(Template(r"tpl1549191524436.png", rgb=True, record_pos=(-0.206, -0.046), resolution=(2280, 1080))):
            touch(Template(r"tpl1550198370599.png", rgb=True, target_pos=3, record_pos=(-0.284, -0.081), resolution=(1920, 1080)))
            touch(Template(r"tpl1550198370599.png", rgb=True, target_pos=9, record_pos=(-0.284, -0.081), resolution=(1920, 1080)))

            pc_wait(Template(r"tpl1549191421531.png", rgb=True, record_pos=(-0.203, -0.047), resolution=(2280, 1080)),'打开音效和音乐')
        touch(Template(r"tpl1549191664907.png", record_pos=(-0.364, 0.033), resolution=(2280, 1080)))
        wait(Template(r"tpl1549191695195.png", record_pos=(0.017, -0.171), resolution=(2280, 1080)))
        for x in range(5):
            swipe(coordinate([1200,750]),coordinate([1200,370]))
            sleep(0.5)
        touch(Template(r"tpl1549191859327.png", record_pos=(0.018, -0.112), resolution=(2280, 1080)))
        sleep(1)
        touch(Template(r"tpl1549191914980.png", record_pos=(0.177, -0.113), resolution=(2280, 1080)))
        sleep(1.0)
        touch(coordinate([150,50]))
        sleep(1)
#          游戏记录   
    def record(self):
        wait(Template(r"tpl1549190053375.png", record_pos=(-0.225, 0.067), resolution=(2280, 1080)))
        touch(Template(r"tpl1549192166406.png", record_pos=(0.332, -0.207), resolution=(2280, 1080)))
        pc_wait(Template(r"tpl1549867702196.png", threshold=0.9, rgb=True, record_pos=(-0.001, -0.187), resolution=(1920, 1080)),'进入对局记录')
        touch(Template(r"tpl1549690195398.png", threshold=0.9, record_pos=(0.3, -0.096), resolution=(2160, 1080)))#点击详情
        pc_wait(Template(r"tpl1549867733294.png", threshold=0.9, rgb=True, record_pos=(-0.002, -0.189), resolution=(1920, 1080)), "进入记录详情")

        if exists(Template(r"tpl1549192188715.png", record_pos=(0.34, -0.175), resolution=(2280, 1080))):
            touch(Template(r"tpl1549192188715.png", record_pos=(0.34, -0.175), resolution=(2280, 1080)))
        sleep(1)
        if exists(Template(r"tpl1549192188715.png", record_pos=(0.34, -0.175), resolution=(2280, 1080))):
            touch(Template(r"tpl1549192188715.png", record_pos=(0.34, -0.175), resolution=(2280, 1080)))
#         退出
    @classmethod
    def exit(cls):
        if not exists(Template(r"tpl1549190053375.png", record_pos=(-0.225, 0.067), resolution=(2280, 1080))):
            touch(Template(r"tpl1549191361811.png", record_pos=(-0.365, -0.202), resolution=(2280, 1080)))
            touch(Template(r"tpl1549192066471.png", record_pos=(-0.362, -0.121), resolution=(2280, 1080)))

        sleep(5) 
        touch(Template(r"tpl1549192253818.png", record_pos=(-0.413, -0.207), resolution=(2280, 1080)))
        pc_wait(leimu_P(cls.web)[2],'金蟾捕鱼退回游戏大厅',30)
        sleep(5)
    def test_tiyan(self):
        if not exists(Template(r"tpl1550124910143.png", rgb=True, record_pos=(0.259, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("体验房")
        if result:
            self.fishing()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("体验房"))
    def test_chuji(self):
        if not exists(Template(r"tpl1550124910143.png", rgb=True, record_pos=(0.259, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.fishing()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))
    def test_zhongji(self):
        if not exists(Template(r"tpl1550124910143.png", rgb=True, record_pos=(0.259, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.fishing()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))        
    def test_gaoji(self):
        if not exists(Template(r"tpl1550124910143.png", rgb=True, record_pos=(0.259, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.fishing()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))

class Game_splitfish(unittest.TestCase):
    """李逵劈鱼"""        
# 进入房间
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.web = globalVar.get_web()
        cls.name = {"体验房":Template(r"tpl1550125343391.png", rgb=True, record_pos=(-0.252, 0.098), resolution=(1920, 1080)),"初级房":Template(r"tpl1550125361827.png", rgb=True, record_pos=(-0.058, 0.094), resolution=(1920, 1080)),"中级房":Template(r"tpl1550125380106.png", rgb=True, record_pos=(0.141, 0.093), resolution=(1920, 1080)),"高级房":Template(r"tpl1550125409773.png", rgb=True, record_pos=(0.219, 0.094), resolution=(1920, 1080))}

        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
    @classmethod
    def ingame(cls):
        wait(leimu_P(cls.web)[2])
        list1 = leimu_P(cls.web)[2]
        list2 = dating(cls.web,"Game_splitfish")
        result = in_youxi(list1,list2)
        if result is True:
            return pc_wait(Template(r"tpl1550805723808.png", rgb=True, record_pos=(0.27, -0.246), resolution=(1920, 1080)),"***成功进入李逵劈鱼***")
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:
            raise TargetNotFoundError("进入游戏失败") 
    def inroom(self,name):
        pc_wait(Template(r"tpl1550125656687.png", record_pos=(0.277, -0.246), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        if name == "高级房":
            swipe([1500,800],[400,800])  #划屏操作
            sleep(1)
            touch(self.name[name])
        else:
            swipe([400,800],[1500,800])  #划屏操作
            sleep(1)
            touch(self.name[name])
            sleep(1)
        result = pc_pd(Template(r"tpl1550805756952.png", rgb=True, record_pos=(0.147, 0.08), resolution=(1920, 1080)), "进%s金额不足有充值提示"%name)    
        if result is True:
            touch(Template(r"tpl1550805756952.png", rgb=True, record_pos=(0.147, 0.08), resolution=(1920, 1080)))
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])
            return 1
        else:
            return pc_wait(Template(r"tpl1550196660103.png", rgb=True, record_pos=(0.415, -0.099), resolution=(1920, 1080)),'进入李逵劈鱼房间%s'%name)
# 打鱼
    def fishing(self):
        for x in range(10):
            touch(Template(r"tpl1549193148604.png", record_pos=(-0.211, 0.193), resolution=(2280, 1080)))
            sleep(0.2)
        touch(Template(r"tpl1550196714785.png", rgb=True, record_pos=(0.413, -0.096), resolution=(1920, 1080)))
        touch(Template(r"tpl1550196700358.png", rgb=True, record_pos=(0.413, 0.122), resolution=(1920, 1080)))
        for x in range(10):
            touch(Template(r"tpl1550196736744.png", threshold=0.8, rgb=True, record_pos=(0.068, 0.234), resolution=(1920, 1080)))
            sleep(0.2)
        touch(Template(r"tpl1549193230474.png", record_pos=(-0.369, -0.203), resolution=(2280, 1080)))
        touch(Template(r"tpl1549193435189.png", record_pos=(-0.368, -0.123), resolution=(2280, 1080)))
        pc_wait(Template(r"tpl1550125656687.png", record_pos=(0.277, -0.246), resolution=(1920, 1080)),'回到李逵劈鱼选场大厅')
#更多
        sleep(3)
    def more(self):
        touch(Template(r"tpl1549193230474.png", record_pos=(-0.369, -0.203), resolution=(2280, 1080)))
        touch(Template(r"tpl1549193242681.png", record_pos=(-0.37, -0.043), resolution=(2280, 1080)))
        sleep(1)
        if exists(Template(r"tpl1549191421531.png", rgb=True, record_pos=(-0.203, -0.047), resolution=(2280, 1080))):
            touch(Template(r"tpl1550196825278.png", rgb=True, target_pos=3, record_pos=(-0.297, -0.083), resolution=(1920, 1080)))
            touch(Template(r"tpl1550196825278.png", rgb=True, target_pos=9, record_pos=(-0.297, -0.083), resolution=(1920, 1080))) 
            pc_wait(Template(r"tpl1549191524436.png", rgb=True, record_pos=(-0.206, -0.046), resolution=(2280, 1080)),'打开音效和音乐')

        if exists(Template(r"tpl1549191524436.png", rgb=True, record_pos=(-0.206, -0.046), resolution=(2280, 1080))):
            touch(Template(r"tpl1550196888338.png", rgb=True, target_pos=3, record_pos=(-0.29, -0.084), resolution=(1920, 1080)))
            touch(Template(r"tpl1550196888338.png", rgb=True, target_pos=9, record_pos=(-0.29, -0.084), resolution=(1920, 1080)))
            pc_wait(Template(r"tpl1549191421531.png", rgb=True, record_pos=(-0.203, -0.047), resolution=(2280, 1080)),'关闭音效和音乐')
        touch(Template(r"tpl1549193264278.png", record_pos=(-0.369, 0.031), resolution=(2280, 1080)))
        wait(Template(r"tpl1549191695195.png", record_pos=(0.017, -0.171), resolution=(2280, 1080)))
        for x in range(5):
            swipe(coordinate([1200,750]),coordinate([1200,370]))
            sleep(0.5)
        touch(Template(r"tpl1549191859327.png", record_pos=(0.018, -0.112), resolution=(2280, 1080)))
        sleep(1)
        touch(Template(r"tpl1549191914980.png", record_pos=(0.177, -0.113), resolution=(2280, 1080)))
        sleep(1.0)
        touch(Template(r"tpl1549590237773.png", record_pos=(0.361, -0.16), resolution=(2160, 1080)))
        sleep(1)

#游戏记录   
    def record(self):
        

        wait(Template(r"tpl1549590029048.png", record_pos=(-0.087, 0.083), resolution=(2160, 1080)))
        touch(Template(r"tpl1549193480246.png", record_pos=(0.348, -0.205), resolution=(2280, 1080)))            
        pc_wait(Template(r"tpl1549867702196.png", threshold=0.9, rgb=True, record_pos=(-0.001, -0.187), resolution=(1920, 1080)),'进入对局记录')
        touch(Template(r"tpl1549690195398.png", threshold=0.9, record_pos=(0.3, -0.096), resolution=(2160, 1080)))#点击详情
        pc_wait(Template(r"tpl1549867733294.png", threshold=0.9, rgb=True, record_pos=(-0.002, -0.189), resolution=(1920, 1080)), "进入记录详情")

        if exists(Template(r"tpl1549192188715.png", record_pos=(0.34, -0.175), resolution=(2280, 1080))):
            touch(Template(r"tpl1549192188715.png", record_pos=(0.34, -0.175), resolution=(2280, 1080)))
        sleep(1)
        if exists(Template(r"tpl1549192188715.png", record_pos=(0.34, -0.175), resolution=(2280, 1080))):
            touch(Template(r"tpl1549192188715.png", record_pos=(0.34, -0.175), resolution=(2280, 1080)))
    @classmethod
    def exit(cls):
        if not exists(Template(r"tpl1549590029048.png", record_pos=(-0.087, 0.083), resolution=(2160, 1080))):
            touch(Template(r"tpl1549193230474.png", record_pos=(-0.369, -0.203), resolution=(2280, 1080)))
            touch(Template(r"tpl1549193435189.png", record_pos=(-0.368, -0.123), resolution=(2280, 1080)))

        sleep(5)
        touch(Template(r"tpl1549193511508.png", record_pos=(-0.411, -0.204), resolution=(2280, 1080)))
        pc_wait(leimu_P(cls.web)[2],'李逵劈鱼退回游戏大厅',30)
        sleep(5)
    def test_tiyan(self):
        if not exists(Template(r"tpl1550805723808.png", rgb=True, record_pos=(0.27, -0.246), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("体验房")
        if result:
            self.fishing()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("体验房"))
    def test_chuji(self):
        if not exists(Template(r"tpl1550805723808.png", rgb=True, record_pos=(0.27, -0.246), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.fishing()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))
    def test_zhongji(self):
        if not exists(Template(r"tpl1550805723808.png", rgb=True, record_pos=(0.27, -0.246), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.fishing()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))        
    def test_gaoji(self):
        if not exists(Template(r"tpl1550805723808.png", rgb=True, record_pos=(0.27, -0.246), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.fishing()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))

class Game_nazhanaohai(unittest.TestCase):
    """哪吒闹海"""
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.web = 'huihuang100'
        cls.name = {"体验房":Template(r"tpl1550126060665.png", rgb=True, record_pos=(-0.288, 0.073), resolution=(1920, 1080)),"初级房":Template(r"tpl1550126081425.png", rgb=True, record_pos=(-0.062, 0.072), resolution=(1920, 1080)),"中级房":Template(r"tpl1550126099305.png", rgb=True, record_pos=(0.177, 0.07), resolution=(1920, 1080)),"高级房":Template(r"tpl1550126121770.png", rgb=True, record_pos=(-0.007, 0.073), resolution=(1920, 1080)),"富豪房":Template(r"tpl1550126140067.png", rgb=True, record_pos=(0.246, 0.072), resolution=(1920, 1080))}

        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
# 进入房间
    @classmethod
    def ingame(cls):
        wait(leimu_P(cls.web)[2])
        list1 = leimu_P(cls.web)[2]
        list2 = dating(cls.web,"Game_nazhanaohai")
        result = in_youxi(list1,list2)
        if result is True:
            return pc_wait(Template(r"tpl1550126319143.png", rgb=True, record_pos=(0.253, -0.242), resolution=(1920, 1080)),"***成功进入哪吒闹海***")
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:
            raise TargetNotFoundError("进入哪吒闹海失败") 
    def inroom(self,name):
        pc_wait(Template(r"tpl1550126319143.png", rgb=True, record_pos=(0.253, -0.242), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        swipe([400,800],[1500,800])
        if name == "高级房":
            swipe([1500,800],[400,800])  #划屏操作
            sleep(1)
            touch(self.name[name])
        elif name == "富豪房":
            swipe([1500,800],[400,800])  #划屏操作
            sleep(1)
            touch(self.name[name])
        else:
            swipe([400,800],[1500,800])  #划屏操作
            sleep(1)
            touch(self.name[name])
        result = pc_pd(Template(r"tpl1550805756952.png", rgb=True, record_pos=(0.147, 0.08), resolution=(1920, 1080)), "进%s金额不足有充值提示"%name)
        if result is True:
            touch(Template(r"tpl1550805756952.png", rgb=True, record_pos=(0.147, 0.08), resolution=(1920, 1080)))
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])
            return 1
        else:
            return pc_wait(Template(r"tpl1549193865962.png", record_pos=(0.451, -0.097), resolution=(2280, 1080)),'进入哪吒闹海房间%s'%name,30)
#         打鱼
    def fishing(self):
        for x in range(10):
            touch(Template(r"tpl1549193852006.png", rgb=True, record_pos=(-0.211, 0.192), resolution=(2280, 1080)))
            sleep(0.2)
        touch(Template(r"tpl1551524500938.png", rgb=True, record_pos=(0.448, -0.097), resolution=(1920, 1080)))
        touch(Template(r"tpl1551524509832.png", rgb=True, record_pos=(0.447, 0.118), resolution=(1920, 1080)))
        for x in range(10):           
            touch(Template(r"tpl1550145728268.png", rgb=True, record_pos=(0.066, 0.233), resolution=(1920, 1080)))
            sleep(1)
        touch(Template(r"tpl1549590571555.png", record_pos=(-0.447, -0.219), resolution=(2160, 1080)))
        pc_wait(Template(r"tpl1550126319143.png", rgb=True, record_pos=(0.253, -0.242), resolution=(1920, 1080)),"成功返回哪吒闹海选场大厅")
        sleep(3)
#         更多
    def more(self):
        touch(Template(r"tpl1549193921193.png", record_pos=(0.448, -0.197), resolution=(2280, 1080)))
        wait(Template(r"tpl1549193981678.png", record_pos=(-0.18, -0.188), resolution=(2280, 1080)))
        touch(Template(r"tpl1549193958181.png", record_pos=(0.341, 0.05), resolution=(2280, 1080)))
        if exists(Template(r"tpl1549194002226.png", rgb=True, record_pos=(0.133, -0.006), resolution=(2280, 1080))):
            touch(Template(r"tpl1550192321445.png", rgb=True, target_pos=3, record_pos=(0.071, -0.005), resolution=(1920, 1080)))
            touch(Template(r"tpl1550192321445.png", rgb=True, target_pos=9, record_pos=(0.071, -0.005), resolution=(1920, 1080)))
            bug_assert(Template(r"tpl1549194093056.png", rgb=True, record_pos=(0.135, -0.007), resolution=(2280, 1080)),'打开音效和音乐','无法打开音效和音乐')

        if exists(Template(r"tpl1549194093056.png", rgb=True, record_pos=(0.135, -0.007), resolution=(2280, 1080))):
            touch(Template(r"tpl1550191842427.png", rgb=True, target_pos=3, record_pos=(0.101, -0.006), resolution=(1920, 1080)))
            touch(Template(r"tpl1550191842427.png", rgb=True, target_pos=9, record_pos=(0.101, -0.006), resolution=(1920, 1080)))
            bug_assert(Template(r"tpl1549194002226.png", rgb=True, record_pos=(0.133, -0.006), resolution=(2280, 1080)),'关闭音效和音乐','无法关闭音效和音乐')


        touch(Template(r"tpl1549194177639.png", record_pos=(0.299, -0.046), resolution=(2280, 1080)))
        sleep(1)
        for x in range(5):
            swipe(coordinate([1200,750]),coordinate([1200,370]))
            sleep(0.5)
        touch(Template(r"tpl1549194210125.png", record_pos=(0.048, -0.125), resolution=(2280, 1080)))
        sleep(1)
        touch(Template(r"tpl1549194225788.png", record_pos=(0.187, -0.124), resolution=(2280, 1080)))
        sleep(1.0)
        touch(Template(r"tpl1549194241885.png", record_pos=(0.274, -0.152), resolution=(2280, 1080)))
        sleep(1)
#          游戏记录   
    def record(self):
        wait(Template(r"tpl1549506781262.png", rgb=True, record_pos=(0.014, 0.063), resolution=(2280, 1080)))
        touch(Template(r"tpl1549194345083.png", record_pos=(0.31, -0.207), resolution=(2280, 1080)))
        pc_wait(Template(r"tpl1549867702196.png", threshold=0.9, rgb=True, record_pos=(-0.001, -0.187), resolution=(1920, 1080)),'进入对局记录')
        touch(Template(r"tpl1549690195398.png", threshold=0.9, record_pos=(0.3, -0.096), resolution=(2160, 1080)))#点击详情
        pc_wait(Template(r"tpl1549867733294.png", threshold=0.9, rgb=True, record_pos=(-0.002, -0.189), resolution=(1920, 1080)), "进入记录详情")

        sleep(2)
        if exists(Template(r"tpl1549192188715.png", record_pos=(0.34, -0.175), resolution=(2280, 1080))):
            touch(Template(r"tpl1549192188715.png", record_pos=(0.34, -0.175), resolution=(2280, 1080)))                
        sleep(1)
        if exists(Template(r"tpl1549192188715.png", record_pos=(0.34, -0.175), resolution=(2280, 1080))):
            touch(Template(r"tpl1549192188715.png", record_pos=(0.34, -0.175), resolution=(2280, 1080)))
#         退出
    @classmethod
    def exit(cls):
        if not exists(Template(r"tpl1549506781262.png", rgb=True, record_pos=(0.014, 0.063), resolution=(2280, 1080))):
            touch(Template(r"tpl1549590571555.png", record_pos=(-0.447, -0.219), resolution=(2160, 1080)))

        sleep(5)
        touch(Template(r"tpl1549590571555.png", record_pos=(-0.447, -0.219), resolution=(2160, 1080)))
        pc_wait(leimu_P(cls.web)[2],'哪吒闹海退回游戏大厅',30)
        sleep(5)
    def test_tiyan(self):
        if not exists(Template(r"tpl1550126319143.png", rgb=True, record_pos=(0.253, -0.242), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("体验房")
        if result:
            self.fishing()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("体验房"))
    def test_chuji(self):
        if not exists(Template(r"tpl1550126319143.png", rgb=True, record_pos=(0.253, -0.242), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.fishing()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))
    def test_zhongji(self):
        if not exists(Template(r"tpl1550126319143.png", rgb=True, record_pos=(0.253, -0.242), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.fishing()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))        
    def test_gaoji(self):
        if not exists(Template(r"tpl1550126319143.png", rgb=True, record_pos=(0.253, -0.242), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.fishing()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))
    def test_fuhao(self):
        if not exists(Template(r"tpl1550126319143.png", rgb=True, record_pos=(0.253, -0.242), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("富豪房")
        if result is True:
            self.fishing()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("富豪房"))

  

