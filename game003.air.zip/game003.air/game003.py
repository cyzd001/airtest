# -*- encoding=utf8 -*-
#__author__ = "Admin"

from airtest.core.api import *
import os,unittest

path = os.path.abspath('..\..')
using(path+'\common\settings.air')
from settings import *

using(path+'\common\games_picture.air')
from games_picture import *

using(path+'\games\config.air')
from config import *

"""
游戏局数
number[2] 代表抢庄牌九游戏局数
number[1] 代表二八杠游戏局数
number[0] 代表其他游戏局数
"""
number = [1,1,1]


class Game_yazhuanglonghu(unittest.TestCase):
    """押庄龙虎"""
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.num = number[0]  # 玩游戏的局数        
        cls.web = globalVar.get_web()
        cls.name = {"初级房":Template(r"tpl1550483873320.png", rgb=True, record_pos=(0.396, 0.031), resolution=(1920, 1080)),"中级房":1,"高级房":2,"富豪房":3,"至尊房":Template(r"tpl1550484540506.png", rgb=False, target_pos=8, record_pos=(0.399, 0.092), resolution=(1920, 1080))}

        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
    @classmethod
    def ingame(cls): #进入游戏
        list1 = leimu_P(cls.web)[0]
        list2 = dating(cls.web,"Game_yazhuanglonghu")
        result = in_youxi(list1,list2)
        if result is True:
            return pc_wait(Template(r"tpl1549006287521.png", record_pos=(0.329, -0.246), resolution=(1920, 1080)),"***成功进入押庄龙虎***",30)
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:            
            raise TargetNotFoundError("进入游戏失败")            
    def inroom(self,name): #进入游戏房间
        pc_wait(Template(r"tpl1549006287521.png", record_pos=(0.329, -0.246), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        swipe([1400,400],[1400,800])   #划屏操作
        sleep(1)
        if name =="初级房":
            for i in range(3):
                if exists(Template(r"tpl1550483924953.png", rgb=True, record_pos=(-0.21, -0.15), resolution=(1920, 1080))):
                    touch(self.name[name])
                    break
                else:
                    swipe([1400,400],[1400,800])
                    sleep(1)        
        elif name == "至尊房":
            for i in range(3):
                if exists(Template(r"tpl1550484511837.png", rgb=True, record_pos=(-0.208, 0.029), resolution=(1920, 1080))) and not exists(Template(r"tpl1550484659304.png", record_pos=(-0.211, -0.149), resolution=(1920, 1080))):
                    touch(self.name[name])
                    break
                else:
                    swipe([1400,800],[1400,450])
                    sleep(1)
        else:
            for i in range(self.name[name]):
                swipe([1400,640],[1400,300])
                sleep(1)
                if exists(Template(r"tpl1550484951842.png", record_pos=(0.397, 0.035), resolution=(1920, 1080))):
                    touch(Template(r"tpl1550485514041.png", threshold=0.5, rgb=False, target_pos=9, record_pos=(0.297, -0.123), resolution=(1920, 1080)))
                    break
        result = pc_pd(Template(r"tpl1550718214996.png", record_pos=(-0.094, 0.061), resolution=(1920, 1080)), "金额不足进%s有提示充值"%name)
        if result is True:
            touch(Template(r"tpl1550718214996.png", record_pos=(-0.094, 0.061), resolution=(1920, 1080)))
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])
            pc_wait(Template(r"tpl1550718514097.png", rgb=True, record_pos=(0.003, 0.204), resolution=(1920, 1080)),"观战状态中")
            if exists(Template(r"tpl1549193369661.png", rgb=True, record_pos=(0.44, -0.236), resolution=(1920, 1080))):
                touch(Template(r"tpl1549193369661.png", rgb=True, record_pos=(0.44, -0.236), resolution=(1920, 1080)))
            touch(Template(r"tpl1549613330007.png", rgb=True, record_pos=(-0.434, -0.245), resolution=(1920, 1080)))
            return 1
        else:
            return pc_wait(Template(r"tpl1549193282058.png", rgb=True, record_pos=(0.388, -0.243), resolution=(1920, 1080)),"成功进入押庄龙虎%s"%name)   
    def kaiwan(self): #玩游戏
        if exists(Template(r"tpl1550718683241.png", rgb=True, record_pos=(0.002, 0.206), resolution=(1920, 1080))):
            pass
        else:
            for i in range(self.num):
                start_time = time.time()
                while True:
                    if exists(Template(r"tpl1549193369661.png", rgb=True, record_pos=(0.44, -0.236), resolution=(1920, 1080))):
                        sleep(8)
                        touch(Template(r"tpl1550210613125.png", threshold=0.9, rgb=True, record_pos=(-0.201, 0.236), resolution=(1920, 1080))) #选一元注码
                        sleep(1)
                        touch(Template(r"tpl1550210529625.png", rgb=True, target_pos=8, record_pos=(-0.27, -0.217), resolution=(1920, 1080))) #选龙
                        touch(Template(r"tpl1550210666155.png", rgb=True, target_pos=7, record_pos=(0.341, -0.199), resolution=(1920, 1080)))  #选虎
                        touch(Template(r"tpl1550210613125.png", threshold=0.9, rgb=True, record_pos=(-0.201, 0.236), resolution=(1920, 1080))) #收起一元注码
                        pc_wait(Template(r"tpl1549193369661.png", rgb=True, record_pos=(0.44, -0.236), resolution=(1920, 1080)),"第%s局游戏结束"%(i+1),30)
                        break
                    else:
                        if chaoshi(start_time) is False:
                            break
        start_time = time.time()
        while True:
            if exists(Template(r"tpl1549193369661.png", rgb=True, record_pos=(0.44, -0.236), resolution=(1920, 1080))):
                touch(Template(r"tpl1549193369661.png", rgb=True, record_pos=(0.44, -0.236), resolution=(1920, 1080)))
                sleep(2)
                touch(Template(r"tpl1549611857453.png", rgb=True, record_pos=(-0.434, -0.244), resolution=(1920, 1080)))
                break
            elif exists(Template(r"tpl1549006287521.png", record_pos=(0.329, -0.246), resolution=(1920, 1080))):
                break                    
            else:
                if chaoshi(start_time) is False:
                    break
        pc_wait(Template(r"tpl1548826361895.png", record_pos=(0.357, -0.248), resolution=(1920, 1080)),"成功回到选场大厅")
    def shangzhuang(self):
        if exists(Template(r"tpl1550718683241.png", rgb=True, record_pos=(0.002, 0.206), resolution=(1920, 1080))):
            pass
        else:
            dianji(Template(r"tpl1549193369661.png", rgb=True, record_pos=(0.44, -0.236), resolution=(1920, 1080)))
            sleep(1)
            if exists(Template(r"tpl1550213042637.png", rgb=True, record_pos=(-0.106, -0.249), resolution=(1920, 1080))):
                touch(Template(r"tpl1550210302508.png", rgb=True, record_pos=(0.053, -0.247), resolution=(1920, 1080)))
                sleep(1)
                assert_exists(Template(r"tpl1550210835660.png", record_pos=(0.054, -0.251), resolution=(1920, 1080)), "玩家上庄排队中")
                dianji(Template(r"tpl1549193369661.png", rgb=True, record_pos=(0.44, -0.236), resolution=(1920, 1080)))
                while True:
                    if exists(Template(r"tpl1550214664381.png", threshold=0.8, rgb=True, record_pos=(0.053, -0.252), resolution=(1920, 1080))):
                        assert_exists(Template(r"tpl1550214664381.png", threshold=0.8, rgb=True, record_pos=(0.053, -0.252), resolution=(1920, 1080)), "玩家上庄中")
                        dianji(Template(r"tpl1549193369661.png", rgb=True, record_pos=(0.44, -0.236), resolution=(1920, 1080)))
                        sleep(5)
                        touch(Template(r"tpl1550214664381.png", threshold=0.8, rgb=True, record_pos=(0.053, -0.252), resolution=(1920, 1080)))
                        sleep(2)
                        assert_exists(Template(r"tpl1550210302508.png", rgb=True, record_pos=(0.053, -0.247), resolution=(1920, 1080)), "玩家下庄成功")
                        break
                    else:
                        assert_exists(Template(r"tpl1550210835660.png", record_pos=(0.054, -0.251), resolution=(1920, 1080)), "玩家上庄排队中")       
            else:
                assert_exists(Template(r"tpl1550215257724.png", threshold=0.9, rgb=True, record_pos=(-0.113, -0.246), resolution=(1920, 1080)), "玩家上庄中")
    def more(self):  #语音
        dianji(Template(r"tpl1549193369661.png", rgb=True, record_pos=(0.44, -0.236), resolution=(1920, 1080)))
        sleep(1)
        touch(Template(r"tpl1549249586675.png", rgb=True, record_pos=(0.439, -0.244), resolution=(1920, 1080)))
        sleep(0.5)
        if exists(Template(r"tpl1549524133121.png", rgb=True, record_pos=(-0.228, -0.018), resolution=(1920, 1080))):
            touch(Template(r"tpl1550209687555.png", rgb=True, target_pos=9, record_pos=(-0.279, -0.134), resolution=(1920, 1080)))
            sleep(1)
            touch(Template(r"tpl1550209711528.png", rgb=True, target_pos=9, record_pos=(-0.302, -0.032), resolution=(1920, 1080)))
            sleep(1)
            bug_assert(Template(r"tpl1549524177438.png", rgb=True, record_pos=(-0.228, -0.017), resolution=(1920, 1080)),"成功取消音效","无法取消音效")
        else:
            sleep(1)
            touch(Template(r"tpl1550209735745.png", target_pos=9, record_pos=(-0.283, -0.134), resolution=(1920, 1080)))                        
            sleep(1)
            touch(Template(r"tpl1550209791904.png", rgb=True, target_pos=9, record_pos=(-0.306, -0.03), resolution=(1920, 1080)))
            bug_assert(Template(r"tpl1549524133121.png", rgb=True, record_pos=(-0.228, -0.018), resolution=(1920, 1080)),"成功开启音效","无法开启音效")

        touch(coordinate([60,600]),100)
    @classmethod
    def exit(cls):  #退出
        start_time = time.time()
        while True:
            if exists(Template(r"tpl1549193369661.png", rgb=True, record_pos=(0.44, -0.236), resolution=(1920, 1080))):
                touch(Template(r"tpl1549193369661.png", rgb=True, record_pos=(0.44, -0.236), resolution=(1920, 1080)))
                sleep(2)
                touch(Template(r"tpl1549613330007.png", rgb=True, record_pos=(-0.434, -0.245), resolution=(1920, 1080)))
                break
            elif exists(Template(r"tpl1549006287521.png", record_pos=(0.329, -0.246), resolution=(1920, 1080))):
                break                    
            else:
                if chaoshi(start_time) is False:
                    break
        pc_wait(Template(r"tpl1548826361895.png", record_pos=(0.357, -0.248), resolution=(1920, 1080)),"成功回到选场大厅")
        touch(Template(r"tpl1549613399544.png", rgb=True, record_pos=(-0.444, -0.248), resolution=(1920, 1080)))
        pc_wait(leimu_P(self.web)[0],"成功回到游戏大厅")
        sleep(5)
    def record(self):  #游戏记录
        touch(Template(r"tpl1549193983551.png", rgb=True, record_pos=(0.239, -0.245), resolution=(1920, 1080)))
        sleep(2)
        if exists(Template(r"tpl1549437671238.png", rgb=True, record_pos=(-0.001, 0.007), resolution=(1920, 1080))):
            print("暂无游戏记录")
        else:
            bug_assert(Template(r"tpl1549612232744.png", rgb=True, record_pos=(0.006, -0.241), resolution=(1920, 1080)),"成功打开游戏记录","无法打开游戏记录")              
            touch(Template(r"tpl1549697121931.png", rgb=True, record_pos=(0.303, -0.069), resolution=(2160, 1080))) #点击详情
            sleep(2)
            bug_assert(Template(r"tpl1549180874537.png", rgb=True, record_pos=(-0.013, -0.208), resolution=(1920, 1080)),"成功打开游戏记录详情页","无法打开游戏记录详情页")
            touch(Template(r"tpl1549180911522.png", rgb=True, record_pos=(0.406, -0.185), resolution=(1920, 1080)))
        sleep(2)
        touch(Template(r"tpl1549180911522.png", rgb=True, record_pos=(0.406, -0.185), resolution=(1920, 1080)))
        sleep(1)
    def test_chuji(self):
        if not exists(Template(r"tpl1549006287521.png", record_pos=(0.329, -0.246), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.kaiwan()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))
    def test_zhongji(self):
        if not exists(Template(r"tpl1549006287521.png", record_pos=(0.329, -0.246), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))        
    def test_gaoji(self):
        if not exists(Template(r"tpl1549006287521.png", record_pos=(0.329, -0.246), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))
    def test_fuhao(self):
        if not exists(Template(r"tpl1549006287521.png", record_pos=(0.329, -0.246), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("富豪房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("富豪房"))
    def test_zhizun(self):
        if not exists(Template(r"tpl1549006287521.png", record_pos=(0.329, -0.246), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("至尊房")
        if result is True:
            self.shangzhuang()
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("至尊房"))
            
class Game_huanlesanshimiao(unittest.TestCase):
    """欢乐三十秒"""
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.num = number[0]  # 玩游戏的局数
        cls.web = globalVar.get_web()
        cls.name = {"初级房":0,"中级房":1,"高级房":2,"富豪房":3,"至尊房":4}
        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
    @classmethod
    def ingame(cls): #进入游戏
        list1 = leimu_P(cls.web)[0]
        list2 = dating(cls.web,"Game_huanlesanshimiao")
        result = in_youxi(list1,list2)
        if result is True:        
            return pc_wait(Template(r"tpl1549529645011.png", rgb=True, record_pos=(0.351, -0.246), resolution=(1920, 1080)),"***成功进入欢乐30秒***",30)
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:            
            raise TargetNotFoundError("进入游戏失败")        
    def inroom(self,name): #进入游戏房间
        pc_wait(Template(r"tpl1549529645011.png", rgb=True, record_pos=(0.351, -0.246), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        swipe([1400,400],[1400,800])   #划屏操作
        sleep(1)
        if self.name[name] >0:
            for i in range(self.name[name]):
                swipe([1400,519],[1400,219])   #划屏操作
                sleep(1)
        if name == "至尊房":
            touch(Template(r"tpl1550570468369.png", rgb=False, target_pos=8, record_pos=(0.417, 0.134), resolution=(1920, 1080)))
        else:
            touch(Template(r"tpl1550570575185.png", rgb=False, target_pos=2, record_pos=(0.417, 0.101), resolution=(1920, 1080)))
        sleep(2)
        result = pc_pd(Template(r"tpl1550719878583.png", record_pos=(-0.097, 0.062), resolution=(1920, 1080)), "进%s金额不足有充值提示"%name)
        if result is True:    
            touch(Template(r"tpl1550719878583.png", record_pos=(-0.097, 0.062), resolution=(1920, 1080)))                        
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])
            pc_wait(Template(r"tpl1550723036912.png", rgb=True, record_pos=(0.001, 0.205), resolution=(1920, 1080)),"观战状态中")
            if exists(Template(r"tpl1549248359378.png", rgb=True, record_pos=(0.462, -0.221), resolution=(1920, 1080))):
                touch(Template(r"tpl1549248359378.png", rgb=True, record_pos=(0.462, -0.221), resolution=(1920, 1080)))
            touch(Template(r"tpl1549248959636.png", rgb=True, record_pos=(-0.455, -0.223), resolution=(1920, 1080)))
            pc_wait(Template(r"tpl1549529645011.png", rgb=True, record_pos=(0.351, -0.246), resolution=(1920, 1080)),"返回欢乐30秒选场大厅",30)
            return 1
        else:
            return pc_wait(Template(r"tpl1549529698302.png", record_pos=(0.384, -0.236), resolution=(1920, 1080)),"成功进入欢乐30秒%s"%name,30)
    def kaiwan(self): #玩游戏
        if exists(Template(r"tpl1550723036912.png", rgb=True, record_pos=(0.001, 0.205), resolution=(1920, 1080))):
            pass
        else:
            dianji(Template(r"tpl1549248359378.png", rgb=True, record_pos=(0.462, -0.221), resolution=(1920, 1080)))
            sleep(8)
            touch(Template(r"tpl1550210613125.png", threshold=0.9, rgb=True, record_pos=(-0.201, 0.236), resolution=(1920, 1080)))  #选一元注码
            for i in range(self.num):
                for j in range(2):
                    touch(Template(r"tpl1550217766122.png", threshold=0.9, rgb=True, target_pos=9, record_pos=(-0.283, -0.189), resolution=(1920, 1080)))  #闲对子
                    touch(Template(r"tpl1550217808156.png", threshold=0.9, target_pos=7, record_pos=(0.314, -0.182), resolution=(1920, 1080)))  #庄对子
                pc_wait(Template(r"tpl1549248359378.png", rgb=True, record_pos=(0.462, -0.221), resolution=(1920, 1080)),"第%s局游戏结束"%(i+1))
                touch(Template(r"tpl1549248359378.png", rgb=True, record_pos=(0.462, -0.221), resolution=(1920, 1080)))
                sleep(8)
        start_time = time.time()
        while True:
            if exists(Template(r"tpl1550562532828.png", rgb=True, record_pos=(-0.389, -0.232), resolution=(1920, 1080))):
                touch(Template(r"tpl1549248959636.png", rgb=True, record_pos=(-0.455, -0.223), resolution=(1920, 1080)))
                pc_wait(Template(r"tpl1549249126610.png", rgb=True, record_pos=(0.353, -0.245), resolution=(1920, 1080)),"成功回到选场大厅")
                break
            elif exists(Template(r"tpl1549249126610.png", rgb=True, record_pos=(0.353, -0.245), resolution=(1920, 1080))):
                break
            else:
                if chaoshi(start_time) is False:
                    break            
        pc_wait(Template(r"tpl1549249126610.png", rgb=True, record_pos=(0.353, -0.245), resolution=(1920, 1080)),"成功回到选场大厅")
    def shangzhuang(self):
        if exists(Template(r"tpl1550723036912.png", rgb=True, record_pos=(0.001, 0.205), resolution=(1920, 1080))):
            pass
        else:
            dianji(Template(r"tpl1549193369661.png", rgb=True, record_pos=(0.44, -0.236), resolution=(1920, 1080)))
            sleep(1)
            if exists(Template(r"tpl1550217423749.png", rgb=True, record_pos=(-0.089, -0.242), resolution=(1920, 1080))):
                touch(Template(r"tpl1550217462506.png", rgb=True, record_pos=(0.062, -0.248), resolution=(1920, 1080)))
                sleep(1)
                assert_exists(Template(r"tpl1550217497678.png", rgb=True, record_pos=(0.062, -0.248), resolution=(1920, 1080)), "玩家上庄排队中")
                dianji(Template(r"tpl1550217589539.png", rgb=True, record_pos=(0.46, -0.217), resolution=(1920, 1080)))
                sleep(5)
                while True:
                    if exists(Template(r"tpl1550218159235.png", rgb=True, record_pos=(0.064, -0.245), resolution=(1920, 1080))):
                        assert_exists(Template(r"tpl1550218159235.png", rgb=True, record_pos=(0.064, -0.245), resolution=(1920, 1080)), "玩家上庄中")
                        dianji(Template(r"tpl1549193369661.png", rgb=True, record_pos=(0.44, -0.236), resolution=(1920, 1080)))
                        sleep(3)
                        touch(Template(r"tpl1550218159235.png", rgb=True, record_pos=(0.064, -0.245), resolution=(1920, 1080)))                    
                        sleep(1)
                        assert_exists(Template(r"tpl1550210302508.png", rgb=True, record_pos=(0.053, -0.247), resolution=(1920, 1080)), "玩家下庄成功")
                        break
            else:
                assert_exists(Template(r"tpl1550218070005.png", rgb=True, record_pos=(-0.092, -0.243), resolution=(1920, 1080)), "玩家上庄中")
    def more(self):  #语音
        dianji(Template(r"tpl1549248359378.png", rgb=True, record_pos=(0.462, -0.221), resolution=(1920, 1080)))
        sleep(1)
        touch(Template(r"tpl1549248405826.png", rgb=True, record_pos=(0.451, -0.235), resolution=(1920, 1080)))
        sleep(1)
        if exists(Template(r"tpl1549533662301.png", record_pos=(-0.228, -0.033), resolution=(1920, 1080))):                
            touch(Template(r"tpl1550565308752.png", rgb=True, target_pos=9, record_pos=(-0.292, -0.118), resolution=(1920, 1080)))
            touch(Template(r"tpl1550565444995.png", rgb=True, target_pos=9, record_pos=(-0.291, -0.039), resolution=(1920, 1080)))            
            bug_assert(Template(r"tpl1549533679401.png", record_pos=(-0.227, -0.032), resolution=(1920, 1080)),"成功取消音效","无法取消音效")
        else:
            touch(Template(r"tpl1550565381528.png", rgb=True, target_pos=9, record_pos=(-0.285, -0.118), resolution=(1920, 1080)))
            touch(Template(r"tpl1550565405597.png", rgb=True, target_pos=9, record_pos=(-0.291, -0.04), resolution=(1920, 1080)))
            bug_assert(Template(r"tpl1549533662301.png", record_pos=(-0.228, -0.033), resolution=(1920, 1080)),"成功开启音效","无法开启音效")
        touch(Template(r"tpl1550565636506.png", rgb=True, target_pos=9, record_pos=(0.165, -0.224), resolution=(1920, 1080)))
        sleep(0.5)
    @classmethod
    def exit(cls):  #退出
        start_time = time.time()
        while True:
            if exists(Template(r"tpl1549248359378.png", rgb=True, record_pos=(0.462, -0.221), resolution=(1920, 1080))):
                touch(Template(r"tpl1549248359378.png", rgb=True, record_pos=(0.462, -0.221), resolution=(1920, 1080)))
                sleep(2)
                touch(Template(r"tpl1549619560703.png", rgb=True, record_pos=(-0.458, -0.236), resolution=(1920, 1080)))
                pc_wait(Template(r"tpl1549249126610.png", rgb=True, record_pos=(0.353, -0.245), resolution=(1920, 1080)),"成功回到选场大厅")
                break
            elif exists(Template(r"tpl1549249126610.png", rgb=True, record_pos=(0.353, -0.245), resolution=(1920, 1080))):
                break
            else:
                if chaoshi(start_time) is False:
                    break
        touch(Template(r"tpl1549619608082.png", rgb=True, record_pos=(-0.461, -0.246), resolution=(1920, 1080)))
        pc_wait(leimu_P(cls.web)[0],"成功回到游戏大厅")
        sleep(5)
    def record(self):  #游戏记录
        touch(Template(r"tpl1549249261172.png", rgb=True, record_pos=(0.277, -0.247), resolution=(1920, 1080)))
        sleep(1)
        if exists(Template(r"tpl1549437671238.png", rgb=True, record_pos=(-0.001, 0.007), resolution=(1920, 1080))):
            print("暂无游戏记录")
        else:
            bug_assert(Template(r"tpl1549249358360.png", rgb=True, record_pos=(-0.003, -0.145), resolution=(1920, 1080)),"成功打开游戏记录","无法打开游戏记录")
            touch(Template(r"tpl1549697854901.png", rgb=True, record_pos=(0.293, -0.084), resolution=(2160, 1080))) #点击详情
            sleep(1)         
            bug_assert(Template(r"tpl1549249408523.png", record_pos=(-0.001, -0.21), resolution=(1920, 1080)),"成功打开详情页","无法打开详情页")
            touch(Template(r"tpl1549249430549.png", rgb=True, record_pos=(0.398, -0.188), resolution=(1920, 1080)))
        sleep(1)
        touch(Template(r"tpl1549249448714.png", rgb=True, record_pos=(0.399, -0.191), resolution=(1920, 1080)))
        sleep(1)     
    def test_chuji(self):
        if not exists(Template(r"tpl1549529645011.png", rgb=True, record_pos=(0.351, -0.246), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.kaiwan()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))
    def test_zhongji(self):
        if not exists(Template(r"tpl1549529645011.png", rgb=True, record_pos=(0.351, -0.246), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))        
    def test_gaoji(self):
        if not exists(Template(r"tpl1549529645011.png", rgb=True, record_pos=(0.351, -0.246), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))
    def test_fuhao(self):
        if not exists(Template(r"tpl1549529645011.png", rgb=True, record_pos=(0.351, -0.246), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("富豪房")
        if result is True:
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("富豪房"))
    def test_zhizun(self):
        if not exists(Template(r"tpl1549529645011.png", rgb=True, record_pos=(0.351, -0.246), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("至尊房")
        if result is True:
            self.shangzhuang()
            self.kaiwan()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("至尊房"))
    
class Game_hongheibigwar(unittest.TestCase):
    """紅黑大戰"""
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.num = number[0]  # 玩游戏的局数 
        cls.web = globalVar.get_web()
        cls.name = {"体验房":Template(r"tpl1550471966008.png", threshold=0.9, rgb=True, target_pos=6, record_pos=(0.142, -0.143), resolution=(1920, 1080)),"初级房":Template(r"tpl1550472000333.png", threshold=0.9, rgb=True, target_pos=6, record_pos=(0.149, 0.081), resolution=(1920, 1080)),"中级房":Template(r"tpl1550472127479.png", threshold=0.9, rgb=True, target_pos=6, record_pos=(0.134, 0.107), resolution=(1920, 1080)),"高级房":Template(r"tpl1550472207002.png", threshold=0.9, rgb=True, target_pos=6, record_pos=(0.151, 0.042), resolution=(1920, 1080)),"至尊房":Template(r"tpl1550472237142.png", threshold=0.9, rgb=True, target_pos=6, record_pos=(0.151, 0.078), resolution=(1920, 1080))}

        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
    @classmethod
    def ingame(cls):  #进入游戏
        list1 = leimu_P(cls.web)[0]
        list2 = dating(cls.web,"Game_hongheibigwar")
        result = in_youxi(list1,list2)
        if result is True:        
            return pc_wait(Template(r"tpl1549594154582.png", rgb=True, record_pos=(0.359, -0.248), resolution=(1920, 1080)),"***成功进入红黑大战***")
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:
            raise TargetNotFoundError("进入游戏失败") 
    def inroom(self,name):  #进入游戏房间
        pc_wait(Template(r"tpl1549594154582.png", rgb=True, record_pos=(0.359, -0.248), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        swipe([1400,400],[1400,800])  #划屏操作
        for i in range(3):
            result = exists(self.name[name])
            if result:
                touch(self.name[name])
                break
            else:
                swipe([1400,800],[1400,400])
        if not result:
            for i in range(3):
                swipe([1400,400],[1400,800])
                sleep(1)
                if exists(self.name[name]):
                    touch(self.name[name])
                    break                                    
        pc_wait(Template(r"tpl1549594354760.png", rgb=True, record_pos=(0.368, -0.237), resolution=(1920, 1080)),"成功进入初级房",30)        
    def shangzhuang(self):
        dianji(Template(r"tpl1549193369661.png", rgb=True, record_pos=(0.44, -0.236), resolution=(1920, 1080)))
        if exists(Template(r"tpl1550217423749.png", rgb=True, record_pos=(-0.089, -0.242), resolution=(1920, 1080))):
            touch(Template(r"tpl1550476447095.png", rgb=True, target_pos=6, record_pos=(-0.06, -0.242), resolution=(1920, 1080)))
            sleep(1)
            assert_exists(Template(r"tpl1550476492890.png", record_pos=(0.057, -0.241), resolution=(1920, 1080)), "玩家上庄排队中")
            dianji(Template(r"tpl1550217589539.png", rgb=True, record_pos=(0.46, -0.217), resolution=(1920, 1080)))
            sleep(6)
            while True:
                if exists(Template(r"tpl1550218159235.png", rgb=True, record_pos=(0.064, -0.245), resolution=(1920, 1080))):
                    assert_exists(Template(r"tpl1550218159235.png", rgb=True, record_pos=(0.064, -0.245), resolution=(1920, 1080)), "玩家上庄中")
                    sleep(3)
                    touch(Template(r"tpl1550476808105.png", rgb=True, record_pos=(0.054, -0.243), resolution=(1920, 1080)))

                    dianji(Template(r"tpl1549193369661.png", rgb=True, record_pos=(0.44, -0.236), resolution=(1920, 1080)))
                    sleep(5)
                    assert_exists(Template(r"tpl1550210302508.png", rgb=True, record_pos=(0.053, -0.247), resolution=(1920, 1080)), "玩家下庄成功")
                    break
        else:
            assert_exists(Template(r"tpl1550218070005.png", rgb=True, record_pos=(-0.092, -0.243), resolution=(1920, 1080)), "其他玩家上庄中")                    
    def kaiwan(self):  #玩游戏
        pc_wait(Template(r"tpl1549594657802.png", rgb=True, record_pos=(0.012, 0.035), resolution=(1920, 1080)),"马上可以下注了。。。。")
        sleep(13)
        touch(coordinate([534,981])) #选一元注码
        for i in range(self.num):
            touch(coordinate([600,370])) #选黑
            touch(coordinate([1250,370])) #选红
            touch(coordinate([950,650])) #选特殊
            pc_wait(Template(r"tpl1549594657802.png", rgb=True, record_pos=(0.012, 0.035), resolution=(1920, 1080)),"第%s局游戏结束"%(i+1))
            if i != self.num-1:
                sleep(13)            
        start_time = time.time()
        while True:               
            if exists(Template(r"tpl1549602488521.png", rgb=True, record_pos=(0.461, -0.235), resolution=(1920, 1080))):
                touch(Template(r"tpl1549248359378.png", rgb=True, record_pos=(0.462, -0.221), resolution=(1920, 1080)))
                touch(Template(r"tpl1549248959636.png", rgb=True, record_pos=(-0.455, -0.223), resolution=(1920, 1080)))

                pc_wait(Template(r"tpl1549594154582.png", rgb=True, record_pos=(0.359, -0.248), resolution=(1920, 1080)),"成功回到选场大厅")
                break
            elif exists(Template(r"tpl1549594154582.png", rgb=True, record_pos=(0.359, -0.248), resolution=(1920, 1080))):
                break
            else:
                if chaoshi(start_time) is False:
                    break
        pc_wait(Template(r"tpl1549602959161.png", rgb=True, record_pos=(0.359, -0.248), resolution=(1920, 1080)),"成功回到选场大厅",30)
    def more(self):    #语音
        if exists(Template(r"tpl1549596350571.png", rgb=True, record_pos=(0.464, -0.237), resolution=(1920, 1080))):
            touch(Template(r"tpl1549596350571.png", rgb=True, record_pos=(0.464, -0.237), resolution=(1920, 1080)))
            touch(Template(r"tpl1549596448501.png", rgb=True, record_pos=(0.426, -0.241), resolution=(1920, 1080)))
            sleep(1)
        if exists(Template(r"tpl1549523212645.png", rgb=True, record_pos=(-0.258, -0.024), resolution=(1920, 1080))):
            touch(Template(r"tpl1549523248168.png", rgb=True, record_pos=(-0.258, -0.056), resolution=(1920, 1080)))
            touch(Template(r"tpl1549523268490.png", rgb=True, record_pos=(-0.258, 0.008), resolution=(1920, 1080)))
            bug_assert(Template(r"tpl1549523303097.png", rgb=True, record_pos=(-0.258, -0.026), resolution=(1920, 1080)),"成功取消音效","无法取消音效")                
        else:
            touch(Template(r"tpl1549523350713.png", rgb=True, record_pos=(-0.258, -0.057), resolution=(1920, 1080)))
            touch(Template(r"tpl1549523350713.png", rgb=True, record_pos=(-0.258, -0.057), resolution=(1920, 1080)))
            sleep(1)
            bug_assert(Template(r"tpl1549523212645.png", rgb=True, record_pos=(-0.258, -0.024), resolution=(1920, 1080)),"成功开启音效","无法开启音效")
        touch(coordinate([60,600]),100)
    def record(self):  #游戏记录
        touch(Template(r"tpl1549602622501.png", rgb=True, record_pos=(0.299, -0.246), resolution=(1920, 1080)))
        sleep(1)
        if exists(Template(r"tpl1549437671238.png", rgb=True, record_pos=(-0.001, 0.007), resolution=(1920, 1080))):
            print("暂无游戏记录")
        else:
            bug_assert(Template(r"tpl1549602732832.png", rgb=True, record_pos=(-0.286, -0.136), resolution=(1920, 1080)),"成功打开游戏记录","无法游戏记录")
            touch(coordinate([1600,320])) #点击详情
            sleep(2)
            bug_assert(Template(r"tpl1549602825808.png", rgb=True, record_pos=(-0.009, -0.215), resolution=(1920, 1080)),"成功打开游戏记录详情页","无法打开游戏记录详情页")
            touch([70,600])
            sleep(2)
        touch([70,600])                    
    @classmethod
    def exit(cls):    #退出
        start_time = time.time()
        while True:
            if exists(Template(r"tpl1549603133390.png", rgb=True, record_pos=(0.461, -0.239), resolution=(1920, 1080))):
                touch(Template(r"tpl1549603133390.png", rgb=True, record_pos=(0.461, -0.239), resolution=(1920, 1080)))
                sleep(2)
                touch(Template(r"tpl1549603169277.png", rgb=True, record_pos=(-0.43, -0.237), resolution=(1920, 1080)))
                break                
            elif exists(Template(r"tpl1549602959161.png", rgb=True, record_pos=(0.359, -0.248), resolution=(1920, 1080))):
                break
            else:
                if chaoshi(start_time) is False:
                    break
        pc_wait(Template(r"tpl1549602959161.png", rgb=True, record_pos=(0.359, -0.248), resolution=(1920, 1080)),"成功回到选场大厅")
        touch(Template(r"tpl1549698686877.png", rgb=True, record_pos=(-0.466, -0.248), resolution=(1920, 1080)))
        pc_wait(leimu_P(self.web)[0],"成功回到游戏大厅")
        sleep(5)
    def test_chuji(self):
        if self.inroom("初级房"):
            self.more()
            self.shangzhuang()
            self.kaiwan()
            self.record()
        else:
            Except_list().add_except('--------------------------%s被禁用-----------------------------'%name) 
    def test_zhongji(self):
        if self.inroom("中级房"):
            self.shangzhuang()
            self.kaiwan()
        else:
            Except_list().add_except('--------------------------%s被禁用-----------------------------'%name)
    def test_gaoji(self):
        if self.inroom("高级房"):
            self.shangzhuang()
            self.kaiwan()
        else:
            Except_list().add_except('--------------------------%s被禁用-----------------------------'%name)
    def test_fuhao(self):
        if self.inroom("富豪房"):
            self.shangzhuang()
            self.kaiwan()
        else:
            Except_list().add_except('--------------------------%s被禁用-----------------------------'%name)
    def test_zhizun(self):
        if self.inroom("至尊房"):
            self.shangzhuang()
            self.kaiwan()
        else:
            Except_list().add_except('--------------------------%s被禁用-----------------------------'%name)
                        
class Game_benzBmw(unittest.TestCase):
    """奔驰宝马"""
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.num = number[0]  # 玩游戏的局数 
        cls.web = globalVar.get_web()
        cls.name = {"初级房":Template(r"tpl1550124059106.png", rgb=False, target_pos=3, record_pos=(0.129, 0.043), resolution=(1920, 1080)),"中级房":Template(r"tpl1550124059106.png", rgb=False, target_pos=6, record_pos=(0.129, 0.043), resolution=(1920, 1080)),"高级房":Template(r"tpl1550124059106.png", target_pos=9, record_pos=(0.129, 0.043), resolution=(1920, 1080)),"富豪房":Template(r"tpl1550124123963.png", rgb=False, target_pos=3, record_pos=(0.138, 0.031), resolution=(1920, 1080)),"至尊房":Template(r"tpl1550124123963.png", rgb=False, target_pos=9, record_pos=(0.138, 0.031), resolution=(1920, 1080))}

        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
                gb_tc(globalVar.get_web())
    @classmethod
    def ingame(cls):
        wait(leimu_P(cls.web)[1])
        list1 = leimu_P(cls.web)[1]
        list2 = dating(cls.web,"Game_benzBmw")
        result = in_youxi(list1,list2)
        if result is True:        
            return pc_wait(Template(r"tpl1550724330649.png", rgb=True, record_pos=(0.184, -0.245), resolution=(1920, 1080)),"***成功进入奔驰宝马***")
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:
            raise TargetNotFoundError("进入游戏失败")      
    def inroom(self,name):
        pc_wait(Template(r"tpl1550724330649.png", rgb=True, record_pos=(0.184, -0.245), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        if name == "富豪房":
            swipe([1400,918],[1400,200])  #划屏操作
            sleep(1)
            touch(self.name[name])
        elif name == "至尊房":
            swipe([1400,918],[1400,200])  #划屏操作
            sleep(1)
            touch(self.name[name])
        else:
            swipe([1400,408],[1400,800])  #划屏操作
            touch(self.name[name])
        result = pc_pd(Template(r"tpl1550724562728.png", rgb=True, record_pos=(-0.096, 0.064), resolution=(1920, 1080)), "进%s金额不足有充值提示"%name)
        if result is True:
            touch(Template(r"tpl1550724562728.png", rgb=True, record_pos=(-0.096, 0.064), resolution=(1920, 1080)))
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])
            pc_wait(Template(r"tpl1550724641787.png", record_pos=(0.004, 0.207), resolution=(1920, 1080)),"观战状态",30)
            touch(Template(r"tpl1549075521173.png", record_pos=(-0.451, -0.198), resolution=(2280, 1080)))#返回选房大厅
            pc_wait(Template(r"tpl1550724330649.png", rgb=True, record_pos=(0.184, -0.245), resolution=(1920, 1080)),"返回奔驰宝马选场大厅",30)
            return 1
        else:
            return pc_wait(Template(r"tpl1550056843512.png", rgb=True, record_pos=(-0.46, -0.187), resolution=(1920, 1080)),"进入奔驰宝马%s"%name,30)         
#         下注       
    def pour(self):
        if exists(Template(r"tpl1550724873518.png", rgb=True, record_pos=(0.003, 0.203), resolution=(1920, 1080))):
            pass
        else:
            wait(Template(r"tpl1548990483250.png", rgb=True, record_pos=(0.006, -0.191), resolution=(1920, 1080)),100)
            sleep(2)
            
            wait(Template(r"tpl1549442869132.png", rgb=True, record_pos=(0.095, -0.117), resolution=(2280, 1080)))
            touch(Template(r"tpl1549074382073.png", rgb=True, record_pos=(-0.195, 0.207), resolution=(2280, 1080)))# 选择1元注码
            touch(coordinate([710,415]))  # 大保时捷                
            touch(coordinate([1020,415]))  # 大宝马                
            touch(coordinate([1300,415]))  # 大奔驰   
            touch(Template(r"tpl1549088601306.png", rgb=True, record_pos=(-0.126, 0.209), resolution=(2280, 1080)))
            touch(coordinate([1570,415]))  # 大大众
            touch(Template(r"tpl1549099199433.png", rgb=True, record_pos=(-0.011, 0.208), resolution=(2280, 1080)))
            touch(coordinate([775,590]))  # 小保时捷
            touch(Template(r"tpl1549099238354.png", rgb=True, record_pos=(0.059, 0.209), resolution=(2280, 1080)))
            touch(coordinate([1020,590]))  # 小宝马
            touch(Template(r"tpl1549099267612.png", record_pos=(0.131, 0.207), resolution=(2280, 1080)))
            touch(coordinate([1300,590]))  # 小奔驰
            touch(Template(r"tpl1549099337160.png", record_pos=(0.205, 0.206), resolution=(2280, 1080)))
            touch(coordinate([1550,590]))  # 小大众
            wait(Template(r"tpl1548990483250.png", rgb=True, record_pos=(0.006, -0.191), resolution=(1920, 1080)),60)
        self.continue_pour()
        touch(Template(r"tpl1549075521173.png", record_pos=(-0.451, -0.198), resolution=(2280, 1080)))#返回选房大厅
        pc_wait(Template(r"tpl1549073080110.png", rgb=True, record_pos=(-0.303, -0.073), resolution=(2280, 1080)),"成功回到选场大厅")
   
#     续压
    def continue_pour(self):
        if exists(Template(r"tpl1550724873518.png", rgb=True, record_pos=(0.003, 0.203), resolution=(1920, 1080))):
            pass
        else:
            wait(Template(r"tpl1548990483250.png", rgb=True, record_pos=(0.006, -0.191), resolution=(1920, 1080)),60)
            sleep(2)
            wait(Template(r"tpl1549442869132.png", rgb=True, record_pos=(0.095, -0.117), resolution=(2280, 1080)))
            touch(Template(r"tpl1549099960693.png", rgb=True, record_pos=(0.407, 0.206), resolution=(2280, 1080)))

#         上庄        
    def beBanker(self):
        if exists(Template(r"tpl1550724873518.png", rgb=True, record_pos=(0.003, 0.203), resolution=(1920, 1080))):
            pass
        else:

            if exists(Template(r"tpl1549103161891.png", threshold=0.7, rgb=True, record_pos=(-0.108, -0.113), resolution=(2280, 1080))):#如果是机器人上庄，证明没有人在上庄
                wait(Template(r"tpl1548990483250.png", rgb=True, record_pos=(0.006, -0.191), resolution=(1920, 1080)),60)                                             
                sleep(8)

                touch(Template(r"tpl1549442869132.png", rgb=True, record_pos=(0.095, -0.117), resolution=(2280, 1080)))
                bug_assert(Template(r"tpl1549097742428.png", rgb=True, record_pos=(0.093, -0.113), resolution=(2280, 1080)),'玩家上庄排队')
                wait(Template(r"tpl1548990483250.png", rgb=True, record_pos=(0.006, -0.191), resolution=(1920, 1080)),60)            
                re = bug_assert_not(Template(r"tpl1549103161891.png", threshold=0.7, rgb=True, record_pos=(-0.108, -0.113), resolution=(2280, 1080)),'玩家上庄')


                if re:
                    wait(Template(r"tpl1549105678378.png", record_pos=(0.019, 0.122), resolution=(2280, 1080)),60)
                    touch(Template(r"tpl1549105678378.png", record_pos=(0.019, 0.122), resolution=(2280, 1080)))
                    touch(Template(r"tpl1549097884942.png", rgb=True, record_pos=(0.096, -0.115), resolution=(2280, 1080)))
                    re = bug_assert(Template(r"tpl1549103161891.png", rgb=True, record_pos=(-0.108, -0.113), resolution=(2280, 1080)), "玩家下庄")
            else:
                print('有人在上庄中')
            wait(Template(r"tpl1548990483250.png", rgb=True, record_pos=(0.006, -0.191), resolution=(1920, 1080)),60)
        

#         更多
    def more(self):
        touch(Template(r"tpl1549100111261.png", record_pos=(0.442, -0.204), resolution=(2280, 1080)))
        wait(Template(r"tpl1549100133751.png", record_pos=(0.023, -0.181), resolution=(2280, 1080)))
        if exists(Template(r"tpl1549442986964.png", record_pos=(-0.198, -0.018), resolution=(2280, 1080))):
            touch(Template(r"tpl1549523248168.png", rgb=True, record_pos=(-0.258, -0.056), resolution=(1920, 1080)))
            sleep(1)
            touch(Template(r"tpl1549523248168.png", rgb=True, record_pos=(-0.258, -0.056), resolution=(1920, 1080)))
            bug_assert(Template(r"tpl1549443120748.png", record_pos=(-0.198, -0.02), resolution=(2280, 1080)),'关音乐和音效')
        if exists(Template(r"tpl1549443120748.png", record_pos=(-0.198, -0.02), resolution=(2280, 1080))):
            touch(Template(r"tpl1549523350713.png", rgb=True, record_pos=(-0.258, -0.057), resolution=(1920, 1080)))
            sleep(1)
            touch(Template(r"tpl1549523350713.png", rgb=True, record_pos=(-0.258, -0.057), resolution=(1920, 1080)))
            bug_assert(Template(r"tpl1549442986964.png", record_pos=(-0.198, -0.018), resolution=(2280, 1080)),'开音乐和音效')
        touch(Template(r"tpl1549110931833.png", record_pos=(0.31, -0.175), resolution=(2280, 1080)))
        sleep(3)
#         游戏记录
    def record(self):
        wait(Template(r"tpl1549073080110.png", rgb=True, record_pos=(-0.303, -0.073), resolution=(2280, 1080)))
        touch(Template(r"tpl1549108816694.png", rgb=True, record_pos=(0.221, -0.21), resolution=(2280, 1080)))
        bug_assert(Template(r"tpl1549507472400.png", record_pos=(-0.01, -0.182), resolution=(2280, 1080)),'进入对局记录')
        touch(Template(r"tpl1549689974994.png", record_pos=(0.296, -0.099), resolution=(2160, 1080)))#点击详情
        bug_assert(Template(r"tpl1549177072698.png", record_pos=(0.042, -0.181), resolution=(2280, 1080)), "进入记录详情")

        if exists(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080))):
            touch(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080)))
        sleep(1)
        if exists(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080))):
            touch(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080)))
#         退出
    @classmethod
    def exit(cls):
        if not exists(Template(r"tpl1549073080110.png", rgb=True, record_pos=(-0.303, -0.073), resolution=(2280, 1080))):
                wait(Template(r"tpl1548990483250.png", rgb=True, record_pos=(0.006, -0.191), resolution=(1920, 1080)),60)
                touch(Template(r"tpl1549075521173.png", record_pos=(-0.451, -0.198), resolution=(2280, 1080)))#返回选房大厅

        sleep(5)
        touch(Template(r"tpl1549075554343.png", record_pos=(-0.438, -0.207), resolution=(2280, 1080)))#返回游戏大厅 
        pc_wait(leimu_P(cls.web)[1],'奔驰宝马退回游戏大厅')    
    def test_chuji(self):
        if not exists(Template(r"tpl1550724330649.png", rgb=True, record_pos=(0.184, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
                gb_tc(globalVar.get_web())
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.beBanker()
            self.pour()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))
    def test_zhongji(self):
        if not exists(Template(r"tpl1550724330649.png", rgb=True, record_pos=(0.184, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
                gb_tc(globalVar.get_web())
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.more
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))        
    def test_gaoji(self):
        if not exists(Template(r"tpl1550724330649.png", rgb=True, record_pos=(0.184, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
                gb_tc(globalVar.get_web())
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))
    def test_fuhao(self):
        if not exists(Template(r"tpl1550724330649.png", rgb=True, record_pos=(0.184, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
                gb_tc(globalVar.get_web())
            self.ingame()
        result = self.inroom("富豪房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("富豪房"))
    def test_zhizun(self):
        if not exists(Template(r"tpl1550724330649.png", rgb=True, record_pos=(0.184, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
                gb_tc(globalVar.get_web())
            self.ingame()
        result = self.inroom("至尊房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("至尊房"))
            
class Game_birdBeast(unittest.TestCase):
    """飞禽走兽"""
    @classmethod        
    def setUpClass(cls):
        """前置条件"""
        cls.num = number[0]  # 玩游戏的局数 
        cls.web = globalVar.get_web()
        cls.name = {"初级房":Template(r"tpl1550123831256.png", rgb=False, target_pos=3, record_pos=(0.124, 0.061), resolution=(1920, 1080)),"中级房":Template(r"tpl1550123831256.png", rgb=False, target_pos=6, record_pos=(0.124, 0.061), resolution=(1920, 1080)),"高级房":Template(r"tpl1550123831256.png", rgb=False, target_pos=9, record_pos=(0.124, 0.061), resolution=(1920, 1080)),"富豪房":Template(r"tpl1550123918733.png", target_pos=3, record_pos=(0.128, -0.004), resolution=(1920, 1080)),"至尊房":Template(r"tpl1550123918733.png", target_pos=9, record_pos=(0.128, -0.004), resolution=(1920, 1080))}   #进入房间

        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
                gb_tc(globalVar.get_web())
    @classmethod
    def ingame(cls):
        wait(leimu_P(cls.web)[1])
        list1 = leimu_P(cls.web)[1]
        list2 = dating(cls.web,"Game_birdBeast")
        result = in_youxi(list1,list2)
        if result is True:
            return pc_wait(Template(r"tpl1550726137911.png", rgb=True, record_pos=(0.191, -0.245), resolution=(1920, 1080)),"***成功进入飞禽走兽***")
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:
            raise TargetNotFoundError("进入游戏失败") 
    def inroom(self,name):
        pc_wait(Template(r"tpl1550726965739.png", record_pos=(0.183, -0.244), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        if name == "富豪房":
            swipe([1400,918],[1400,200])  #划屏操作
            sleep(1)
            touch(self.name[name])
        elif name == "至尊房":
            swipe([1400,918],[1400,200])  #划屏操作
            sleep(1)
            touch(self.name[name])
        else:
            swipe([1400,408],[1400,800])  #划屏操作
            touch(self.name[name])
        sleep(2)
        result = pc_pd(Template(r"tpl1550726293585.png", threshold=0.8, rgb=True, record_pos=(-0.092, 0.09), resolution=(1920, 1080)), "进入%s金额不足有充值提示"%name)     
        if result is True:
            touch(Template(r"tpl1550726293585.png", threshold=0.8, rgb=True, record_pos=(-0.092, 0.09), resolution=(1920, 1080)))
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])
            pc_wait(Template(r"tpl1550726364660.png", record_pos=(0.002, 0.206), resolution=(1920, 1080)),"观战状态",30)
            touch(Template(r"tpl1549109382343.png", rgb=True, record_pos=(-0.451, -0.201), resolution=(2280, 1080)))#返回选房大厅
            pc_wait(Template(r"tpl1550726137911.png", rgb=True, record_pos=(0.191, -0.245), resolution=(1920, 1080)),"返回飞禽走兽选场大厅",30)
            return 1
        else:
            
            return pc_wait(Template(r"tpl1550059704107.png", rgb=True, record_pos=(-0.466, -0.193), resolution=(1920, 1080)),'进入飞禽走兽房间%s'%name,30)                    
#         下注
    def pour(self):
        if exists(Template(r"tpl1550726493920.png", rgb=True, record_pos=(-0.005, 0.206), resolution=(1920, 1080))):
            pass
        else:
            wait(Template(r"tpl1550225399204.png", rgb=True, record_pos=(-0.099, 0.005), resolution=(1920, 1080)),80)
            sleep(9)
            touch(Template(r"tpl1549074382073.png", rgb=True, record_pos=(-0.195, 0.207), resolution=(2280, 1080))) # 选择1元注码
            touch(coordinate([1150,680]))#大鲨鱼
            touch(Template(r"tpl1549088601306.png", rgb=True, record_pos=(-0.126, 0.209), resolution=(2280, 1080)))                
            touch(coordinate([670,500])) # 选择孔雀
            touch(coordinate([860,500])) # 选择鸽子
            touch(Template(r"tpl1549099199433.png", rgb=True, record_pos=(-0.011, 0.208), resolution=(2280, 1080)))
            touch(coordinate([1060,500]))  # 选择飞禽
            touch(coordinate([1255,500]))  # 选择走兽
            touch(Template(r"tpl1549099238354.png", rgb=True, record_pos=(0.059, 0.209), resolution=(2280, 1080)))
            touch(coordinate([1450,500]))  # 熊猫
            touch(coordinate([1640,500]))  # 猴子
            touch(Template(r"tpl1549099267612.png", record_pos=(0.131, 0.207), resolution=(2280, 1080)))
            touch(coordinate([670,680]))  # 燕子
            touch(coordinate([860,680]))  # 老鹰
            touch(Template(r"tpl1549099337160.png", record_pos=(0.205, 0.206), resolution=(2280, 1080)))
            touch(coordinate([1450,680]))  # 兔子  
            touch(coordinate([1640,680]))  # 狮子  
            self.continue_pour()
        
#         续压
    def continue_pour(self):
        wait(Template(r"tpl1550225399204.png", rgb=True, record_pos=(-0.099, 0.005), resolution=(1920, 1080)),80)           
        sleep(9)
        touch(Template(r"tpl1549107536350.png", rgb=True, record_pos=(0.389, 0.201), resolution=(2280, 1080)))
        wait(Template(r"tpl1550225399204.png", rgb=True, record_pos=(-0.099, 0.005), resolution=(1920, 1080)),80)            
        sleep(8)
        touch(Template(r"tpl1549109382343.png", rgb=True, record_pos=(-0.451, -0.201), resolution=(2280, 1080)))#返回选房大厅
        pc_wait(Template(r"tpl1550726137911.png", rgb=True, record_pos=(0.191, -0.245), resolution=(1920, 1080)),"回到选场大厅",30)
#         上庄
    def beBanker(self):
        pass
#         更多
    def more(self):
        touch(Template(r"tpl1550225621771.png", rgb=True, record_pos=(0.455, -0.24), resolution=(1920, 1080)))
        sleep(2)
        if exists(Template(r"tpl1550204223511.png", threshold=0.9, rgb=True, record_pos=(-0.289, -0.025), resolution=(1920, 1080))):
            touch(Template(r"tpl1550204245623.png", rgb=True, target_pos=9, record_pos=(-0.302, -0.11), resolution=(1920, 1080)))

            touch(Template(r"tpl1550204265060.png", rgb=True, target_pos=9, record_pos=(-0.31, -0.078), resolution=(1920, 1080)))
            bug_assert(Template(r"tpl1550204313554.png", threshold=0.9, rgb=True, record_pos=(-0.275, -0.024), resolution=(1920, 1080)),"成功取消音效","无法取消音效")                
        else:
            touch(Template(r"tpl1550204345495.png", rgb=True, target_pos=9, record_pos=(-0.304, -0.11), resolution=(1920, 1080)))
            touch(Template(r"tpl1550204369522.png", rgb=True, target_pos=9, record_pos=(-0.304, -0.027), resolution=(1920, 1080)))
            sleep(1)
            bug_assert(Template(r"tpl1549523212645.png", rgb=True, record_pos=(-0.258, -0.024), resolution=(1920, 1080)),"成功开启音效","无法开启音效")
#         touch(coordinate([60,600]),100)
        touch(Template(r"tpl1550225683363.png", rgb=True, target_pos=6, record_pos=(0.17, -0.211), resolution=(1920, 1080)))    
        sleep(3)
#          游戏记录   
    def record(self):
        
        wait(Template(r"tpl1549076839024.png", record_pos=(-0.327, -0.037), resolution=(2280, 1080)))    
        touch(Template(r"tpl1549179934150.png", record_pos=(0.236, -0.207), resolution=(2280, 1080)))
        pc_wait(Template(r"tpl1549865133113.png", rgb=True, record_pos=(-0.024, -0.186), resolution=(1920, 1080)),'进入对局记录')
        touch(Template(r"tpl1549865364810.png", rgb=True, record_pos=(0.334, -0.111), resolution=(1920, 1080)))#点击详情
        pc_wait(Template(r"tpl1549866167622.png", rgb=True, record_pos=(-0.149, -0.186), resolution=(1920, 1080)), "进入记录详情")

        if exists(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080))):
            touch(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080)))
        sleep(1)
        if exists(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080))):
            touch(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080)))     
#         退出
    @classmethod
    def exit(cls):
        if not exists(Template(r"tpl1549076839024.png", record_pos=(-0.327, -0.037), resolution=(2280, 1080))):
            wait(Template(r"tpl1550225399204.png", rgb=True, record_pos=(-0.099, 0.005), resolution=(1920, 1080)),80)            
            sleep(8)
            touch(Template(r"tpl1549109382343.png", rgb=True, record_pos=(-0.451, -0.201), resolution=(2280, 1080)))#返回选房大厅
            sleep(2)

        sleep(5)  
        touch(Template(r"tpl1549180040853.png", record_pos=(-0.441, -0.206), resolution=(2280, 1080)))
        pc_wait(leimu_P(cls.web)[1],'飞禽走兽退回游戏大厅')
        sleep(6)   
    def test_chuji(self):
        if not exists(Template(r"tpl1550726137911.png", rgb=True, record_pos=(0.191, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
                gb_tc(globalVar.get_web())
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.beBanker()
            self.pour()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))
    def test_zhongji(self):
        if not exists(Template(r"tpl1550726137911.png", rgb=True, record_pos=(0.191, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
                gb_tc(globalVar.get_web())
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.more
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))        
    def test_gaoji(self):
        if not exists(Template(r"tpl1550726137911.png", rgb=True, record_pos=(0.191, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
                gb_tc(globalVar.get_web())
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))
    def test_fuhao(self):
        if not exists(Template(r"tpl1550726137911.png", rgb=True, record_pos=(0.191, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
                gb_tc(globalVar.get_web())
            self.ingame()
        result = self.inroom("富豪房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("富豪房"))
    def test_zhizun(self):
        if not exists(Template(r"tpl1550726137911.png", rgb=True, record_pos=(0.191, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
                gb_tc(globalVar.get_web())
            self.ingame()
        result = self.inroom("至尊房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("至尊房"))

class Game_shake(unittest.TestCase):
    """摇一摇"""
    @classmethod    
    def setUpClass(cls):
        """前置条件"""
        cls.num = number[0]  # 玩游戏的局数 
        cls.web = globalVar.get_web()
        cls.name = {"初级房":Template(r"tpl1550123123288.png", rgb=True, target_pos=3, record_pos=(0.139, 0.044), resolution=(1920, 1080)),"中级房":Template(r"tpl1550123123288.png", rgb=True, target_pos=6, record_pos=(0.139, 0.044), resolution=(1920, 1080)),"高级房":Template(r"tpl1550123123288.png", rgb=True, target_pos=9, record_pos=(0.139, 0.044), resolution=(1920, 1080)),"富豪房":Template(r"tpl1550123241482.png", rgb=True, target_pos=3, record_pos=(0.134, 0.029), resolution=(1920, 1080)),"至尊房":Template(r"tpl1550123241482.png", rgb=True, target_pos=9, record_pos=(0.134, 0.029), resolution=(1920, 1080))}

        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError        
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
                gb_tc(globalVar.get_web())
    @classmethod
    def ingame(cls):
        wait(leimu_P(cls.web)[1])
        list1 = leimu_P(cls.web)[1]
        list2 = dating(cls.web,"Game_shake")
        result = in_youxi(list1,list2)
        if result is True:
            return pc_wait(Template(r"tpl1550727696224.png", rgb=True, record_pos=(0.191, -0.247), resolution=(1920, 1080)),"***成功进入摇一摇***")
        elif result == 1:
            raise ControlOrAgentNotSetError('游戏在界面未展示出来')
        else:
            raise TargetNotFoundError("进入游戏失败")
    def inroom(self,name):
        pc_wait(Template(r"tpl1550727696224.png", rgb=True, record_pos=(0.191, -0.247), resolution=(1920, 1080)),'马上进房间玩游戏了',30)           
        if name == "富豪房":
            swipe([1400,918],[1400,200])  #划屏操作
            sleep(1)
            touch(self.name[name])
        elif name == "至尊房":
            swipe([1400,918],[1400,200])  #划屏操作
            sleep(1)
            touch(self.name[name])
        else:
            swipe([1400,408],[1400,800])  #划屏操作
            touch(self.name[name])
        sleep(1)
        result = pc_pd(Template(r"tpl1550727197344.png", record_pos=(-0.098, 0.062), resolution=(1920, 1080)), "进%s金额不足有充值提示"%name)    
        if result is True:
            touch(Template(r"tpl1550727197344.png", record_pos=(-0.098, 0.062), resolution=(1920, 1080)))
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])
            pc_wait(Template(r"tpl1550727245342.png", record_pos=(0.003, 0.206), resolution=(1920, 1080)),"观战状态",30)
            touch(Template(r"tpl1550227140636.png", rgb=True, record_pos=(-0.456, -0.245), resolution=(1920, 1080)))  #返回选房大厅
            pc_wait(Template(r"tpl1550727696224.png", rgb=True, record_pos=(0.191, -0.247), resolution=(1920, 1080)),"返回摇一摇选场大厅",30)
            return 1
        else:
            return pc_wait(Template(r"tpl1550122815861.png", rgb=True, record_pos=(0.453, -0.204), resolution=(1920, 1080)),'进入摇一摇%s'%name,30)                                
    def pour(self):
#         wait(Template(r"tpl1549185247114.png", record_pos=(0.019, -0.001), resolution=(2280, 1080)),120)
        if exists(Template(r"tpl1550727457327.png", record_pos=(-0.002, 0.21), resolution=(1920, 1080))):
            pass
        else:
            pc_wait(Template(r"tpl1550226970779.png", rgb=True, record_pos=(0.029, 0.102), resolution=(1920, 1080)),"开奖了")
            sleep(7)      
            touch(Template(r"tpl1549074382073.png", rgb=True, record_pos=(-0.195, 0.207), resolution=(2280, 1080))) # 选择1元注码
            touch(coordinate([390,640]))#点数
            touch(coordinate([515,640]))
            touch(coordinate([630,640]))
            touch(coordinate([755,640]))
            touch(coordinate([872,640]))
            touch(coordinate([988,640]))
            touch(coordinate([1110,640]))
            touch(coordinate([1240,640]))
            touch(coordinate([1350,640]))
            touch(coordinate([1472,640]))
            touch(coordinate([1590,640]))
            touch(coordinate([1720,640]))
            touch(coordinate([1840,640]))
            touch(coordinate([1945,640]))
            pc_wait(Template(r"tpl1550226970779.png", rgb=True, record_pos=(0.029, 0.102), resolution=(1920, 1080)),"开奖了")
            sleep(7) 
            touch(Template(r"tpl1549088601306.png", rgb=True, record_pos=(-0.126, 0.209), resolution=(2280, 1080)))                
            touch(coordinate([820,320]))#豹子
            touch(coordinate([960,320]))
            touch(coordinate([1100,320]))
            touch(coordinate([1250,320]))
            touch(coordinate([1390,320]))
            touch(coordinate([1540,320]))
            touch(Template(r"tpl1549099199433.png", rgb=True, record_pos=(-0.011, 0.208), resolution=(2280, 1080)))
            touch(coordinate([475,830]))#子数
            touch(coordinate([750,830]))
            touch(coordinate([1030,830]))
            touch(coordinate([1330,830]))
            touch(coordinate([1580,830]))
            touch(coordinate([1850,830]))
            pc_wait(Template(r"tpl1550226970779.png", rgb=True, record_pos=(0.029, 0.102), resolution=(1920, 1080)),"开奖了")
            sleep(7) 
            touch(Template(r"tpl1549099238354.png", rgb=True, record_pos=(0.059, 0.209), resolution=(2280, 1080)))
            touch(coordinate([1180,480]))  # 任意豹子
            touch(Template(r"tpl1549099267612.png", record_pos=(0.131, 0.207), resolution=(2280, 1080)))
            touch(coordinate([560,280])) # 单
            touch(coordinate([1820,280])) # 双
            touch(Template(r"tpl1549099337160.png", record_pos=(0.205, 0.206), resolution=(2280, 1080)))
            touch(coordinate([560,480]))  # 小
            touch(coordinate([1820,480]))  # 大
            self.continue_pour()
    def continue_pour(self):
#         wait(Template(r"tpl1549185247114.png", record_pos=(0.019, -0.001), resolution=(2280, 1080)),120)
#         wait(Template(r"tpl1549522608831.png", record_pos=(0.06, -0.037), resolution=(2280, 1080)))  
        pc_wait(Template(r"tpl1550226970779.png", rgb=True, record_pos=(0.029, 0.102), resolution=(1920, 1080)),"开奖了")
        sleep(8)
        touch(Template(r"tpl1549182593505.png", record_pos=(0.388, 0.199), resolution=(2280, 1080)))
        pc_wait(Template(r"tpl1550226970779.png", rgb=True, record_pos=(0.029, 0.102), resolution=(1920, 1080)),"开奖了")
        sleep(8)
        touch(Template(r"tpl1550227140636.png", rgb=True, record_pos=(-0.456, -0.245), resolution=(1920, 1080)))  #返回选房大厅
        pc_wait(Template(r"tpl1550727696224.png", rgb=True, record_pos=(0.191, -0.247), resolution=(1920, 1080)),"回到选场大厅",30)
    def beBanker(self):
        pass
    def more(self):
        touch(Template(r"tpl1549452203829.png", rgb=True, record_pos=(0.461, -0.207), resolution=(2280, 1080)))
        wait(Template(r"tpl1549182621248.png", record_pos=(0.021, -0.181), resolution=(2280, 1080)))

        if exists(Template(r"tpl1549442986964.png", record_pos=(-0.198, -0.018), resolution=(2280, 1080))):
            touch(Template(r"tpl1549523248168.png", rgb=True, record_pos=(-0.258, -0.056), resolution=(1920, 1080)))
            sleep(1)
            touch(Template(r"tpl1549523268490.png", rgb=True, record_pos=(-0.258, 0.008), resolution=(1920, 1080)))

            bug_assert(Template(r"tpl1549443120748.png", record_pos=(-0.198, -0.02), resolution=(2280, 1080)),'关音乐和音效')
        if exists(Template(r"tpl1549443120748.png", record_pos=(-0.198, -0.02), resolution=(2280, 1080))):
            touch(Template(r"tpl1549523350713.png", rgb=True, record_pos=(-0.258, -0.057), resolution=(1920, 1080)))
            sleep(1)
            touch(Template(r"tpl1549523350713.png", rgb=True, record_pos=(-0.258, -0.057), resolution=(1920, 1080)))
            bug_assert(Template(r"tpl1549442986964.png", record_pos=(-0.198, -0.018), resolution=(2280, 1080)),'开音乐和音效')
        touch(Template(r"tpl1549110931833.png", record_pos=(0.31, -0.175), resolution=(2280, 1080)))    
        sleep(3)
    def record(self):
        
        pc_wait(Template(r"tpl1549180680774.png", record_pos=(-0.311, -0.051), resolution=(2280, 1080)),'回到选场大厅')    
        touch(Template(r"tpl1549850291529.png", record_pos=(0.285, -0.219), resolution=(2160, 1080)))
        pc_wait(Template(r"tpl1549865133113.png", rgb=True, record_pos=(-0.024, -0.186), resolution=(1920, 1080)),'进入对局记录')
        touch(Template(r"tpl1549865364810.png", rgb=True, record_pos=(0.334, -0.111), resolution=(1920, 1080)))#点击详情
        pc_wait(Template(r"tpl1549866167622.png", rgb=True, record_pos=(-0.149, -0.186), resolution=(1920, 1080)), "进入记录详情")

        if exists(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080))):
            touch(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080)))
        sleep(1)
        if exists(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080))):
            touch(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080)))     
    @classmethod
    def exit(self):
        if not exists(Template(r"tpl1549180680774.png", record_pos=(-0.311, -0.051), resolution=(2280, 1080))):
#             wait(Template(r"tpl1549185247114.png", record_pos=(0.019, -0.001), resolution=(2280, 1080)),120)
#             wait(Template(r"tpl1549522608831.png", record_pos=(0.06, -0.037), resolution=(2280, 1080)))  
            pc_wait(Template(r"tpl1550226970779.png", rgb=True, record_pos=(0.029, 0.102), resolution=(1920, 1080)),"开奖了")
            sleep(8)
            touch(Template(r"tpl1550227140636.png", rgb=True, record_pos=(-0.456, -0.245), resolution=(1920, 1080)))  #返回选房大厅
        sleep(5)   
        touch(Template(r"tpl1550227230275.png", rgb=True, record_pos=(-0.453, -0.246), resolution=(1920, 1080)))
        pc_wait(leimu_P(cls.web)[2],'摇一摇退回游戏大厅',30)
        sleep(5)           
    def test_chuji(self):
        if not exists(Template(r"tpl1550727696224.png", rgb=True, record_pos=(0.191, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
                gb_tc(globalVar.get_web())
            self.ingame()
        result = self.inroom("初级房")
        if result is True:
            self.pour()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("初级房"))
    def test_zhongji(self):
        if not exists(Template(r"tpl1550727696224.png", rgb=True, record_pos=(0.191, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
                gb_tc(globalVar.get_web())
            self.ingame()
        result = self.inroom("中级房")
        if result is True:
            self.more
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("中级房"))        
    def test_gaoji(self):
        if not exists(Template(r"tpl1550727696224.png", rgb=True, record_pos=(0.191, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
                gb_tc(globalVar.get_web())
            self.ingame()
        result = self.inroom("高级房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("高级房"))
    def test_fuhao(self):
        if not exists(Template(r"tpl1550727696224.png", rgb=True, record_pos=(0.191, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
                gb_tc(globalVar.get_web())
            self.ingame()
        result = self.inroom("富豪房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("富豪房"))
    def test_zhizun(self):
        if not exists(Template(r"tpl1550727696224.png", rgb=True, record_pos=(0.191, -0.247), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
                gb_tc(globalVar.get_web())
            self.ingame()
        result = self.inroom("至尊房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("至尊房"))

class Game_hundredCattle(unittest.TestCase):
    """百人牛牛"""
    @classmethod
    def setUpClass(cls):
        """前置条件"""
        cls.web = globalVar.get_web()
        cls.num = number[0]  # 玩游戏的局数 
        cls.name4 = {"4倍初级房":Template(r"tpl1551782802921.png", rgb=False, target_pos=3, record_pos=(0.153, -0.036), resolution=(1920, 1080)),"4倍中级房":             Template(r"tpl1551782802921.png", rgb=False, target_pos=9, record_pos=(0.153, -0.036), resolution=(1920, 1080)),"4倍高级房":Template(r"tpl1551782973986.png", target_pos=3, record_pos=(0.155, -0.005), resolution=(1920, 1080)),
        "4倍富豪房":Template(r"tpl1551782973986.png", target_pos=9, record_pos=(0.155, -0.005), resolution=(1920, 1080)),"4倍至尊房":Template(r"tpl1551783077756.png", rgb=False, target_pos=9, record_pos=(0.152, -0.032), resolution=(1920, 1080))}
        cls.name10 = {"10倍初级房":Template(r"tpl1551782802921.png", rgb=False, target_pos=3, record_pos=(0.153, -0.036), resolution=(1920, 1080)),"10倍中级房":             Template(r"tpl1551782802921.png", rgb=False, target_pos=9, record_pos=(0.153, -0.036), resolution=(1920, 1080)),"10倍高级房":Template(r"tpl1551782973986.png", target_pos=3, record_pos=(0.155, -0.005), resolution=(1920, 1080)),
        "10倍富豪房":Template(r"tpl1551782973986.png", target_pos=9, record_pos=(0.155, -0.005), resolution=(1920, 1080)),"10倍至尊房":Template(r"tpl1551783077756.png", rgb=False, target_pos=9, record_pos=(0.152, -0.032), resolution=(1920, 1080))}       
        try:
            cls.ingame()
        except Exception:
            login(globalVar.get_web())
            raise TargetNotFoundError
    @classmethod
    def tearDownClass(cls):
        """后置操作"""
        try:
            cls.exit()
        except TargetNotFoundError:
            if not login(globalVar.get_web()):
                cls.exit()
    @classmethod
    def ingame(cls):
        wait(leimu_P(cls.web)[2])
        list1 = leimu_P(cls.web)[0]
        list2 = dating(cls.web,"Game_hundredCattle")
        result = in_youxi(list1,list2)
        if result is True:
            sleep(5)
            return pc_wait(Template(r"tpl1550127299111.png", rgb=True, record_pos=(0.177, -0.245), resolution=(1920, 1080)),"***成功进入百人牛牛***",30)
        elif result.isdigit:
            raise StatusError('游戏状态处于非正常')
        else:
            raise TargetNotFoundError("进入游戏失败") 
#         进入房间
    def inroom(self,name):
        pc_wait(Template(r"tpl1550127299111.png", rgb=True, record_pos=(0.177, -0.245), resolution=(1920, 1080)),'马上进房间玩游戏了',30)
        if name in  self.name4.keys():
            if name =="4倍高级房":
                swipe([1400,1000],[1400,360])  #划屏操作
                touch(self.name4[name])
            elif name =="4倍富豪房":
                swipe([1400,1000],[1400,360])  #划屏操作
                touch(self.name4[name])
            elif name == "4倍至尊房":
                swipe([1400,1000],[1400,360])  #划屏操作
                sleep(1)
                swipe([1400,1000],[1400,360])  #划屏操作
                touch(self.name4[name])
            else:
                touch(self.name4[name])
        else:
            touch(Template(r"tpl1550129616798.png", record_pos=(-0.189, -0.026), resolution=(1920, 1080)))
            sleep(5)
            if name =="10倍高级房":
                swipe([1400,1000],[1400,360])  #划屏操作
                touch(self.name10[name])
            elif name =="10倍富豪房":
                swipe([1400,1000],[1400,360])  #划屏操作
                touch(self.name10[name])
            elif name == "10倍至尊房":
                swipe([1400,1000],[1400,360])  #划屏操作
                sleep(1)
                swipe([1400,1000],[1400,360])  #划屏操作
                touch(self.name10[name])
            else:
                touch(self.name10[name])                
        sleep(2)
        result = pc_pd(Template(r"tpl1550810777471.png", rgb=True, record_pos=(-0.109, 0.06), resolution=(1920, 1080)), "进%s金额不足有充值提示"%name)
        if result is True:
            touch(Template(r"tpl1550810777471.png", rgb=True, record_pos=(-0.109, 0.06), resolution=(1920, 1080)))
            pc_wait(money(self.web)[0],"成功拉起充值界面",30)
            if exists(money(self.web)[1]):
                touch(money(self.web)[1])
            touch(Template(r"tpl1550810814338.png", rgb=True, record_pos=(0.09, 0.058), resolution=(1920, 1080)))
            wait(Template(r"tpl1549185247114.png", record_pos=(0.019, -0.001), resolution=(2280, 1080)),120)
            wait(Template(r"tpl1549522608831.png", record_pos=(0.06, -0.037), resolution=(2280, 1080)),60)      
            sleep(1)
            touch(Template(r"tpl1549250990410.png", record_pos=(-0.424, -0.204), resolution=(2280, 1080)))
            return 1
        else:
            return pc_wait(Template(r"tpl1550127236849.png", rgb=True, record_pos=(0.401, -0.242), resolution=(1920, 1080)),'进入百人牛牛房间%s'%name,30)
#         下注    
    def pour(self):
        if exists(Template(r"tpl1550811336679.png", rgb=True, record_pos=(-0.166, 0.255), resolution=(1920, 1080))):
            pass
        else:
            wait(Template(r"tpl1549185247114.png", record_pos=(0.019, -0.001), resolution=(2280, 1080)),60)
            wait(Template(r"tpl1549522608831.png", record_pos=(0.06, -0.037), resolution=(2280, 1080)),60)      
            sleep(1)

            touch(Template(r"tpl1549074382073.png", rgb=True, record_pos=(-0.195, 0.207), resolution=(2280, 1080)))# 选择1元注码
            touch(coordinate([660,490]))  # 天               
            touch(Template(r"tpl1549088601306.png", rgb=True, record_pos=(-0.126, 0.209), resolution=(2280, 1080)))
            touch(coordinate([1000,490]))  # 地
            touch(Template(r"tpl1549099199433.png", rgb=True, record_pos=(-0.011, 0.208), resolution=(2280, 1080)))
            touch(coordinate([1350,490]))  # 玄
            touch(Template(r"tpl1549099238354.png", rgb=True, record_pos=(0.059, 0.209), resolution=(2280, 1080)))
            touch(coordinate([1680,490]))  # 黄
            touch(Template(r"tpl1549099267612.png", record_pos=(0.131, 0.207), resolution=(2280, 1080)))
            touch(coordinate([1300,490]))  # 地
            touch(Template(r"tpl1549099337160.png", record_pos=(0.205, 0.206), resolution=(2280, 1080)))
            touch(coordinate([1680,490]))  # 玄
        self.continue_pour()
#         续压
    def continue_pour(self):
        if exists(Template(r"tpl1550730338669.png", rgb=True, record_pos=(-0.166, 0.252), resolution=(1920, 1080))):
            pass
        else:
            wait(Template(r"tpl1549185247114.png", record_pos=(0.019, -0.001), resolution=(2280, 1080)),120)
            wait(Template(r"tpl1549522608831.png", record_pos=(0.06, -0.037), resolution=(2280, 1080)),60)      
            sleep(3)           
            touch(Template(r"tpl1549257891005.png", record_pos=(0.355, 0.202), resolution=(2280, 1080)))
            wait(Template(r"tpl1549185247114.png", record_pos=(0.019, -0.001), resolution=(2280, 1080)),120)
        wait(Template(r"tpl1549522608831.png", record_pos=(0.06, -0.037), resolution=(2280, 1080)),60)      
        sleep(1)
        touch(Template(r"tpl1549250990410.png", record_pos=(-0.424, -0.204), resolution=(2280, 1080)))#返回选房大厅
        pc_wait(Template(r"tpl1550127299111.png", rgb=True, record_pos=(0.177, -0.245), resolution=(1920, 1080)),"返回百人牛牛选场大厅")
#         历史
    def history(self):
        wait(Template(r"tpl1549185247114.png", record_pos=(0.019, -0.001), resolution=(2280, 1080)),60)
        wait(Template(r"tpl1549522608831.png", record_pos=(0.06, -0.037), resolution=(2280, 1080)),60)

        touch(Template(r"tpl1549591840169.png", rgb=True, record_pos=(-0.384, -0.215), resolution=(2160, 1080)))
        if exists(Template(r"tpl1549591933948.png", rgb=True, record_pos=(-0.4, -0.218), resolution=(2160, 1080))):
            touch(Template(r"tpl1549591933948.png", rgb=True, record_pos=(-0.4, -0.218), resolution=(2160, 1080)))

            bug_assert(Template(r"tpl1549592032679.png", rgb=True, record_pos=(-0.401, -0.218), resolution=(2160, 1080)),'关闭历史弹窗')
        if exists(Template(r"tpl1549592032679.png", rgb=True, record_pos=(-0.401, -0.218), resolution=(2160, 1080))):
            touch(Template(r"tpl1549592032679.png", rgb=True, record_pos=(-0.401, -0.218), resolution=(2160, 1080)))
            bug_assert(Template(r"tpl1549591933948.png", rgb=True, record_pos=(-0.4, -0.218), resolution=(2160, 1080)),'打开历史弹窗')

        touch(Template(r"tpl1549592139138.png", record_pos=(0.4, -0.218), resolution=(2160, 1080)))
#         更多
    def more(self):
        wait(Template(r"tpl1549185247114.png", record_pos=(0.019, -0.001), resolution=(2280, 1080)),60)
        wait(Template(r"tpl1549522608831.png", record_pos=(0.06, -0.037), resolution=(2280, 1080)),60)
        touch(Template(r"tpl1549249026873.png", record_pos=(0.395, -0.206), resolution=(2280, 1080)))
        wait(Template(r"tpl1549257924787.png", record_pos=(0.024, -0.18), resolution=(2280, 1080)))
        sleep(1)
        if exists(Template(r"tpl1550205953707.png", threshold=0.9, rgb=True, record_pos=(-0.258, -0.023), resolution=(1920, 1080))):
            touch(Template(r"tpl1550205364445.png", rgb=True, target_pos=9, record_pos=(-0.306, -0.109), resolution=(1920, 1080)))
            touch(Template(r"tpl1550205398007.png", rgb=True, target_pos=9, record_pos=(-0.31, -0.027), resolution=(1920, 1080)))
            
            bug_assert(Template(r"tpl1549443120748.png", rgb=True, record_pos=(-0.198, -0.02), resolution=(2280, 1080)),"成功取消音效","无法取消音效")                
        else:
            touch(Template(r"tpl1550205427271.png", rgb=True, target_pos=9, record_pos=(-0.305, -0.11), resolution=(1920, 1080)))
            touch(Template(r"tpl1550205447849.png", rgb=True, target_pos=9, record_pos=(-0.307, -0.029), resolution=(1920, 1080)))
            sleep(1)
            bug_assert(Template(r"tpl1550205953707.png", threshold=0.9, rgb=True, record_pos=(-0.258, -0.023), resolution=(1920, 1080)),"成功开启音效","无法开启音效")

        touch(Template(r"tpl1549110931833.png", record_pos=(0.31, -0.175), resolution=(2280, 1080)))    
        sleep(3)
#         记录
    def record(self):
        wait(Template(r"tpl1549250604726.png", record_pos=(-0.332, -0.043), resolution=(2280, 1080)))    
        touch(Template(r"tpl1549179934150.png", record_pos=(0.236, -0.207), resolution=(2280, 1080)))
        bug_assert(Template(r"tpl1549865133113.png", rgb=True, record_pos=(-0.024, -0.186), resolution=(1920, 1080)),'进入对局记录')
        touch(Template(r"tpl1549865364810.png", rgb=True, record_pos=(0.334, -0.111), resolution=(1920, 1080)))#点击详情
        bug_assert(Template(r"tpl1549866167622.png", rgb=True, record_pos=(-0.149, -0.186), resolution=(1920, 1080)), "进入记录详情")

        if exists(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080))):
            touch(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080)))
        sleep(1)
        if exists(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080))):
            touch(Template(r"tpl1549109042295.png", record_pos=(0.304, -0.181), resolution=(2280, 1080)))     
    @classmethod
    def exit(cls):
        if not exists(Template(r"tpl1549250604726.png", record_pos=(-0.332, -0.043), resolution=(2280, 1080))):
            wait(Template(r"tpl1549185247114.png", record_pos=(0.019, -0.001), resolution=(2280, 1080)),120)
            wait(Template(r"tpl1549522608831.png", record_pos=(0.06, -0.037), resolution=(2280, 1080)),60)      
            sleep(1)

            touch(Template(r"tpl1549250990410.png", record_pos=(-0.424, -0.204), resolution=(2280, 1080)))#返回选房大厅
        sleep(5)  
        touch(Template(r"tpl1549180040853.png", record_pos=(-0.441, -0.206), resolution=(2280, 1080)))
        
        pc_wait(leimu_P(cls.web)[2],'百人牛牛退回游戏大厅')
        sleep(5)         
    def test_4chuji(self):
        if not exists(Template(r"tpl1550127299111.png", rgb=True, record_pos=(0.177, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("4倍初级房")
        if result is True:
            self.pour()
            self.record()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("4倍初级房"))
    def test_4zhongji(self):
        if not exists(Template(r"tpl1550127299111.png", rgb=True, record_pos=(0.177, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("4倍中级房")
        if result is True:     
            self.more()
            self.history()
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("4倍中级房")) 
    def test_4gaoji(self):
        if not exists(Template(r"tpl1550127299111.png", rgb=True, record_pos=(0.177, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("4倍高级房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("4倍高级房"))
    def test_4fuhao(self):
        if not exists(Template(r"tpl1550127299111.png", rgb=True, record_pos=(0.177, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("4倍富豪房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("4倍富豪房"))
    def test_4zhizun(self):
        if not exists(Template(r"tpl1550127299111.png", rgb=True, record_pos=(0.177, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("4倍至尊房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("4倍至尊房"))
    def test_10chuji(self):
        if not exists(Template(r"tpl1550127299111.png", rgb=True, record_pos=(0.177, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("10倍初级房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("10倍初级房"))
    def test_10zhongji(self):
        if not exists(Template(r"tpl1550127299111.png", rgb=True, record_pos=(0.177, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("10倍中级房")
        if result is True:     
            self.more()
            self.history()
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("10倍中级房"))
    def test_10gaoji(self):
        if not exists(Template(r"tpl1550127299111.png", rgb=True, record_pos=(0.177, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("10倍高级房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("10倍高级房"))
    def test_10fuhao(self):
        if not exists(Template(r"tpl1550127299111.png", rgb=True, record_pos=(0.177, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("10倍富豪房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("10倍富豪房"))
    def test_10zhizun(self):
        if not exists(Template(r"tpl1550127299111.png", rgb=True, record_pos=(0.177, -0.245), resolution=(1920, 1080))):
            if not login(globalVar.get_web()):
                self.exit()
            self.ingame()
        result = self.inroom("10倍至尊房")
        if result is True:
            self.pour()
        elif result == 1:
            pass
        else:
            Except_list().add_except('--------------------------{}被禁用-----------------------------'.format("10倍至尊房"))


     
